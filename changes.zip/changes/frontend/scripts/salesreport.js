let allSalesData = [];
let activeSalesChargeNames = [];
let activeSalesChargeTypes = {}; // description -> 'required' | 'marginal'

document.addEventListener('DOMContentLoaded', async () => {
    function updateDateTime() {
        const now = new Date();
        const timeElement = document.getElementById('systemTime');
        const dateElement = document.getElementById('systemDate');
        if (timeElement) timeElement.textContent = now.toLocaleTimeString('en-US', { hour12: false });
        if (dateElement) dateElement.textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    }
    updateDateTime();
    setInterval(updateDateTime, 1000);

    setupSearchAndOverlay();
    setupDateAndActionControls();
    await loadSalesData();
});

const apiBase = (typeof Utils !== 'undefined' && Utils.getApiBaseUrl)
    ? Utils.getApiBaseUrl()
    : ((window.CONFIG && window.CONFIG.API_BASE_URL) ? window.CONFIG.API_BASE_URL : '');

async function loadSalesData(startDate = '', endDate = '') {
    try {
        let queryParams = '';
        if (startDate || endDate) {
            const p = new URLSearchParams();
            if (startDate) p.append('startDate', startDate);
            if (endDate)   p.append('endDate', endDate);
            queryParams = '?' + p.toString();
        }
        let response;
        try {
            response = await fetch(`${apiBase}/api/sales-report${queryParams}`);
            if (!response.ok && apiBase) response = await fetch(`/api/sales-report${queryParams}`);
        } catch (e) {
            response = await fetch(`/api/sales-report${queryParams}`);
        }
        const result = await response.json();
        if (result.success) {
            allSalesData = result.data || [];
            renderTable(allSalesData);
        } else {
            const tbody = document.getElementById('tableBody');
            if (tbody) tbody.innerHTML = '<tr><td colspan="12" style="text-align:center;color:red;">Error loading data</td></tr>';
        }
    } catch (error) {
        console.error('Failed to fetch sales data:', error);
        const tbody = document.getElementById('tableBody');
        if (tbody) tbody.innerHTML = '<tr><td colspan="12" style="text-align:center;color:red;">Failed to fetch data from server</td></tr>';
    }
}

function formatCurrency(amount) {
    const num = parseFloat(amount) || 0;
    return num.toLocaleString('en-US', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
}

function renderTable(data) {
    const tableHeader = document.getElementById('tableHeader');
    const tableBody   = document.getElementById('tableBody');
    const tableFooter = document.getElementById('tableFooter');
    const overallEl   = document.getElementById('overallSalesTotal');

    if (!tableHeader || !tableBody) return;

    // Collect all unique charge names + their types across all rows
    const chargeNamesSet = new Set();
    activeSalesChargeTypes = {};
    allSalesData.forEach(inv => {
        if (inv.charges) {
            Object.keys(inv.charges).forEach(name => {
                chargeNamesSet.add(name);
                activeSalesChargeTypes[name] = inv.chargeTypes?.[name] || 'required';
            });
        }
    });
    activeSalesChargeNames = Array.from(chargeNamesSet).sort();

    // Build header — fixed cols + dynamic charge cols + total
    let headerHTML = `
        <th>Invoice NO</th>
        <th>Job Card</th>
        <th>Customer</th>
        <th>Shipper</th>
        <th>Agent</th>
        <th>Driver</th>
        <th>Responsible Person</th>
        <th>Cost Center</th>
        <th>CC Number</th>
    `;
    activeSalesChargeNames.forEach(name => {
        const isMarginal = activeSalesChargeTypes[name] === 'marginal';
        const badge = isMarginal
            ? `<span style="font-size:9px;background:#fef3c7;color:#92400e;padding:1px 5px;border-radius:3px;margin-left:4px;">Marginal</span>`
            : `<span style="font-size:9px;background:#e0f2fe;color:#0369a1;padding:1px 5px;border-radius:3px;margin-left:4px;">Required</span>`;
        headerHTML += `<th>${name}${badge}</th>`;
    });
    headerHTML += `<th class="total-col">Total Amount</th>`;
    tableHeader.innerHTML = headerHTML;

    const invoiceCountEl = document.getElementById('invoiceCount');
    if (invoiceCountEl) invoiceCountEl.textContent = data.length;

    if (data.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="${9 + activeSalesChargeNames.length + 1}" style="text-align:center;padding:30px;color:#64748b;">No finalized invoices found</td></tr>`;
        if (tableFooter) tableFooter.innerHTML = '';
        if (overallEl) overallEl.textContent = 'KWD 0.000';
        return;
    }

    let grandTotal = 0;
    const chargeTotals = {};
    activeSalesChargeNames.forEach(name => chargeTotals[name] = 0);

    // Find max amount per charge column for green highlight scaling
    const chargeMax = {};
    activeSalesChargeNames.forEach(name => {
        chargeMax[name] = Math.max(...data.map(inv => parseFloat(inv.charges?.[name]) || 0));
    });

    let bodyHTML = '';
    data.forEach(inv => {
        const invTotal = parseFloat(inv.total) || 0;
        grandTotal += invTotal;

        bodyHTML += `<tr onclick="toggleRowHighlight(this)">
            <td><strong>${inv.invoice_no || 'N/A'}</strong></td>
            <td>${inv.job_no || 'N/A'}</td>
            <td>${inv.customer_name || 'N/A'}</td>
            <td>${inv.shipper_name || '--'}</td>
            <td>${inv.agent_name || '--'}</td>
            <td>${inv.driver_name || '--'}</td>
            <td>${inv.responsible_person || '--'}</td>
            <td>${inv.cost_center || '--'}</td>
            <td>${inv.cost_center_number || '--'}</td>`;

        activeSalesChargeNames.forEach(name => {
            const amount = parseFloat(inv.charges?.[name]) || 0;
            chargeTotals[name] += amount;
            const isMarginal = activeSalesChargeTypes[name] === 'marginal';

            let cellStyle = 'text-align:right;';
            if (amount > 0) {
                if (isMarginal) {
                    // Marginal: green highlight scaled by amount
                    const max = chargeMax[name] || 1;
                    const intensity = Math.round(40 + (amount / max) * 180);
                    cellStyle += `background:rgba(22,163,74,${(amount / max * 0.35).toFixed(2)});color:#14532d;font-weight:600;`;
                } else {
                    cellStyle += 'color:#1e40af;font-weight:500;';
                }
            }

            bodyHTML += `<td style="${cellStyle}">${amount > 0 ? formatCurrency(amount) : '-'}</td>`;
        });

        bodyHTML += `<td class="total-col">${formatCurrency(invTotal)}</td></tr>`;
    });

    tableBody.innerHTML = bodyHTML;

    if (overallEl) overallEl.textContent = `KWD ${formatCurrency(grandTotal)}`;

    // Footer totals row
    if (tableFooter) {
        let footerHTML = `<tr class="grand-total-row">
            <td style="font-weight:700;">TOTAL SALES</td>
            <td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td>`;

        activeSalesChargeNames.forEach(name => {
            const sum = chargeTotals[name] || 0;
            footerHTML += `<td style="text-align:right;font-weight:700;">${sum > 0 ? formatCurrency(sum) : '-'}</td>`;
        });

        footerHTML += `<td class="total-col-grand">KWD ${formatCurrency(grandTotal)}</td></tr>`;
        tableFooter.innerHTML = footerHTML;
    }
}

function toggleRowHighlight(rowEl) {
    if (rowEl) rowEl.classList.toggle('row-highlight');
}

function setupSearchAndOverlay() {
    const searchInput  = document.getElementById('entitySearch');
    const searchOverlay = document.getElementById('searchOverlay');

    if (searchInput && searchOverlay) {
        searchInput.addEventListener('focus', () => searchOverlay.classList.add('active'));
        searchOverlay.addEventListener('click', () => {
            searchOverlay.classList.remove('active');
            searchInput.blur();
        });
        searchInput.addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase().trim();
            if (!q) { renderTable(allSalesData); return; }
            const filtered = allSalesData.filter(inv =>
                (inv.invoice_no      || '').toLowerCase().includes(q) ||
                (inv.job_no          || '').toLowerCase().includes(q) ||
                (inv.customer_name   || '').toLowerCase().includes(q) ||
                (inv.shipper_name    || '').toLowerCase().includes(q) ||
                (inv.agent_name      || '').toLowerCase().includes(q) ||
                (inv.driver_name     || '').toLowerCase().includes(q) ||
                (inv.responsible_person || '').toLowerCase().includes(q) ||
                (inv.cost_center     || '').toLowerCase().includes(q) ||
                (inv.cost_center_number || '').toLowerCase().includes(q)
            );
            renderTable(filtered);
        });
    }
}

function setupDateAndActionControls() {
    const btnToggle    = document.getElementById('btnToggleFilter');
    const filterPanel  = document.getElementById('dateFilterPanel');
    const fromDateEl   = document.getElementById('fromDate');
    const toDateEl     = document.getElementById('toDate');
    const btnApply     = document.getElementById('btnApplyDateFilter');
    const btnReset     = document.getElementById('btnResetDateFilter');
    const btnExcel     = document.getElementById('btnExportExcel');
    const btnMail      = document.getElementById('btnDirectSendMail');

    if (btnToggle && filterPanel) {
        btnToggle.addEventListener('click', () => filterPanel.classList.toggle('active'));
    }
    if (btnApply) {
        btnApply.addEventListener('click', () => loadSalesData(fromDateEl?.value || '', toDateEl?.value || ''));
    }
    if (btnReset) {
        btnReset.addEventListener('click', () => {
            if (fromDateEl) fromDateEl.value = '';
            if (toDateEl)   toDateEl.value   = '';
            loadSalesData('', '');
        });
    }
    if (btnExcel) {
        btnExcel.addEventListener('click', () => {
            if (typeof XLSX === 'undefined') { alert('Excel library loading...'); return; }
            const table = document.getElementById('salesReportTable');
            const wb = XLSX.utils.table_to_book(table, { sheet: 'Sales Report' });
            XLSX.writeFile(wb, `Al_Eid_Sales_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
        });
    }
    if (btnMail) {
        btnMail.addEventListener('click', async () => {
            if (typeof XLSX === 'undefined') { alert('Excel library loading... try again.'); return; }
            const origHtml = btnMail.innerHTML;
            btnMail.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mailing Admin...';
            btnMail.disabled = true;
            try {
                const table = document.getElementById('salesReportTable');
                const wb = XLSX.utils.table_to_book(table, { sheet: 'Sales Report' });
                const excelBase64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });

                const startDate = fromDateEl?.value || '';
                const endDate   = toDateEl?.value   || '';
                const customMessage = (startDate || endDate)
                    ? `Filtered: ${startDate || 'Beginning'} to ${endDate || 'Today'}`
                    : '';

                let response;
                try {
                    response = await fetch(`${apiBase}/api/sales-report/send-email`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ excelBase64, customMessage })
                    });
                } catch (e) {
                    response = await fetch('/api/sales-report/send-email', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ excelBase64, customMessage })
                    });
                }

                const res = await response.json();
                if (res.success) {
                    alert(`✅ Sales Report emailed to Admin (${res.adminEmail})!`);
                } else {
                    alert('⚠️ Email failed: ' + (res.message || 'Unknown error'));
                }
            } catch (err) {
                alert('Error sending email: ' + err.message);
            } finally {
                btnMail.innerHTML = origHtml;
                btnMail.disabled = false;
            }
        });
    }
}
