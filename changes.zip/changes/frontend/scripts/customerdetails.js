let allInvoicesData = [];
let pieChartInstance = null;
let lineChartInstance = null;
let dailyLineChartInstance = null;
let barChartInstance = null;
let currentGrandTotalSales = 0;

document.addEventListener('DOMContentLoaded', async () => {
    // Handle time and date updating
    function updateDateTime() {
        const now = new Date();
        const timeElement = document.getElementById('systemTime');
        const dateElement = document.getElementById('systemDate');
        
        if (timeElement) {
            timeElement.textContent = now.toLocaleTimeString('en-US', { hour12: false });
        }
        if (dateElement) {
            dateElement.textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        }
    }
    
    updateDateTime();
    setInterval(updateDateTime, 1000);

    const customerSelect = document.getElementById('customerSelect');
    if (customerSelect) {
        customerSelect.addEventListener('change', (e) => {
            loadCustomerAnalytics(e.target.value);
        });
    }

    const tableSearch = document.getElementById('tableSearch');
    const searchOverlay = document.getElementById('searchOverlay');
    const searchWrap = document.querySelector('.search-box-wrap');

    function showOverlay() {
        if (searchOverlay) searchOverlay.classList.add('active');
        if (searchWrap) searchWrap.classList.add('focused');
    }

    function hideOverlay() {
        if (searchOverlay) searchOverlay.classList.remove('active');
        if (searchWrap) searchWrap.classList.remove('focused');
    }

    if (tableSearch) {
        tableSearch.addEventListener('focus', showOverlay);
        tableSearch.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            if (!query) {
                renderInvoicesTable(allInvoicesData);
                return;
            }
            const filtered = allInvoicesData.filter(inv => {
                const invNo = (inv.invoice_no || '').toLowerCase();
                const jobNo = (inv.job_no || '').toLowerCase();
                const custName = (inv.customer_name || '').toLowerCase();
                const shipper = (inv.shipper_name || '').toLowerCase();
                return invNo.includes(query) || jobNo.includes(query) || custName.includes(query) || shipper.includes(query);
            });
            renderInvoicesTable(filtered);
        });
    }

    if (searchOverlay) {
        searchOverlay.addEventListener('click', () => {
            hideOverlay();
            if (tableSearch) tableSearch.blur();
        });
    }

    await loadCustomerAnalytics('');
});

const apiBase = (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) 
    ? Utils.getApiBaseUrl() 
    : ((window.CONFIG && window.CONFIG.API_BASE_URL) ? window.CONFIG.API_BASE_URL : '');

function formatCurrency(amount) {
    const num = parseFloat(amount) || 0;
    return num.toLocaleString('en-US', {
        minimumFractionDigits: 3,
        maximumFractionDigits: 3
    });
}

async function loadCustomerAnalytics(customerId = '') {
    try {
        let endpoint = `${apiBase}/api/customer-details`;
        if (customerId) endpoint += `?customerId=${encodeURIComponent(customerId)}`;

        let response;
        try {
            response = await fetch(endpoint);
            if (!response.ok && apiBase) {
                response = await fetch(`/api/customer-details${customerId ? `?customerId=${encodeURIComponent(customerId)}` : ''}`);
            }
        } catch(e) {
            response = await fetch(`/api/customer-details${customerId ? `?customerId=${encodeURIComponent(customerId)}` : ''}`);
        }

        const result = await response.json();
        if (!result.success) {
            alert('Failed to load customer analytics');
            return;
        }

        currentGrandTotalSales = result.grandTotalSales || 0;
        allInvoicesData = result.invoices || [];

        // 1. Populate Customer Dropdown Selector (if empty)
        populateCustomerSelect(result.customersList, customerId);

        // 2. Update KPI Cards
        updateKPICards(result, customerId);

        // 3. Render Visual Charts
        renderPieChart(result.customerShareSummary, customerId);
        renderLineChart(result.monthlyTrend);
        renderDailyLineChart(result.dailyTrend);
        renderTopChargesBarChart(result.chargeBreakdown);

        // 4. Render Table
        renderInvoicesTable(allInvoicesData);

    } catch (error) {
        console.error('Error loading customer analytics:', error);
    }
}

function populateCustomerSelect(customersList, currentSelectedId) {
    const select = document.getElementById('customerSelect');
    if (!select || select.options.length > 1) return;

    select.innerHTML = '<option value="">-- All Customers --</option>';
    (customersList || []).forEach(cust => {
        const opt = document.createElement('option');
        opt.value = cust.id;
        opt.textContent = cust.company ? `${cust.name} (${cust.company})` : cust.name;
        if (String(cust.id) === String(currentSelectedId)) opt.selected = true;
        select.appendChild(opt);
    });
}

function updateKPICards(result, selectedCustomerId) {
    const invoices = result.invoices || [];
    const totalBilled = invoices.reduce((acc, inv) => acc + (parseFloat(inv.total) || 0), 0);
    const invoiceCount = invoices.length;
    
    // Unique Job Cards count
    const uniqueJobCards = new Set(invoices.map(inv => inv.job_card_id)).size;

    // Sales Share %
    let sharePercent = 0;
    if (result.grandTotalSales > 0) {
        sharePercent = ((totalBilled / result.grandTotalSales) * 100).toFixed(2);
    }

    document.getElementById('kpiTotalBilled').textContent = `KWD ${formatCurrency(totalBilled)}`;
    document.getElementById('kpiSharePercent').textContent = `${sharePercent} %`;
    document.getElementById('kpiInvoiceCount').textContent = invoiceCount;
    document.getElementById('kpiJobCardCount').textContent = uniqueJobCards;
}

function renderPieChart(customerShareSummary = [], selectedCustomerId = '') {
    const ctx = document.getElementById('customerSharePieChart');
    if (!ctx) return;

    if (pieChartInstance) pieChartInstance.destroy();

    // Prepare Pie Data
    let labels = [];
    let dataValues = [];
    let backgroundColors = [
        '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899',
        '#06b6d4', '#84cc16', '#6366f1', '#14b8a6', '#f43f5e'
    ];

    if (selectedCustomerId) {
        // Highlight selected customer vs others
        const selected = customerShareSummary.find(c => String(c.customer_id) === String(selectedCustomerId));
        const selectedTotal = selected ? selected.total_spent : 0;
        const othersTotal = currentGrandTotalSales - selectedTotal;

        labels = [selected ? selected.customer_name : 'Selected Customer', 'Other Customers'];
        dataValues = [selectedTotal, Math.max(0, othersTotal)];
        backgroundColors = ['#10b981', '#cbd5e1'];
    } else {
        // Top 8 Customers + Others
        const top8 = customerShareSummary.slice(0, 8);
        labels = top8.map(c => c.customer_name);
        dataValues = top8.map(c => c.total_spent);

        const top8Sum = top8.reduce((acc, c) => acc + c.total_spent, 0);
        const remaining = currentGrandTotalSales - top8Sum;

        if (remaining > 0) {
            labels.push('Others');
            dataValues.push(remaining);
        }
    }

    pieChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: dataValues,
                backgroundColor: backgroundColors,
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { boxWidth: 14, font: { size: 12 } } },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const val = context.parsed || 0;
                            const pct = currentGrandTotalSales > 0 ? ((val / currentGrandTotalSales) * 100).toFixed(2) : 0;
                            return ` ${context.label}: KWD ${formatCurrency(val)} (${pct}%)`;
                        }
                    }
                }
            }
        }
    });
}

function renderLineChart(monthlyTrend = []) {
    const ctx = document.getElementById('monthlyTrendLineChart');
    if (!ctx) return;

    if (lineChartInstance) lineChartInstance.destroy();

    const labels = (monthlyTrend || []).map(m => m.month);
    const totals = (monthlyTrend || []).map(m => m.monthly_total);

    lineChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels.length > 0 ? labels : ['No Data'],
            datasets: [{
                label: 'Monthly Billed Sales (KWD)',
                data: totals.length > 0 ? totals : [0],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                fill: true,
                tension: 0.3,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: '#2563eb'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(val) { return 'KWD ' + formatCurrency(val); }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return ` Sales: KWD ${formatCurrency(context.parsed.y)}`;
                        }
                    }
                }
            }
        }
    });
}

function renderDailyLineChart(dailyTrend = []) {
    const ctx = document.getElementById('dailyOrderLineChart');
    if (!ctx) return;

    if (dailyLineChartInstance) dailyLineChartInstance.destroy();

    const labels = (dailyTrend || []).map(d => d.order_date);
    const totals = (dailyTrend || []).map(d => d.daily_total);
    const counts = (dailyTrend || []).map(d => d.order_count);

    dailyLineChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels.length > 0 ? labels : ['No Orders'],
            datasets: [{
                label: 'Daily Order Amount (KWD)',
                data: totals.length > 0 ? totals : [0],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                fill: true,
                tension: 0.2,
                pointRadius: 5,
                pointHoverRadius: 7,
                pointBackgroundColor: '#10b981'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(val) { return 'KWD ' + formatCurrency(val); }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const index = context.dataIndex;
                            const count = counts[index] || 0;
                            return [
                                ` Billed: KWD ${formatCurrency(context.parsed.y)}`,
                                ` Orders / Invoices: ${count}`
                            ];
                        }
                    }
                }
            }
        }
    });
}

function renderTopChargesBarChart(chargeBreakdown = []) {
    const ctx = document.getElementById('topChargesBarChart');
    if (!ctx) return;

    if (barChartInstance) barChartInstance.destroy();

    const labels = (chargeBreakdown || []).map(c => c.charge_name);
    const totals = (chargeBreakdown || []).map(c => c.total_amount);

    barChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.length > 0 ? labels : ['No Charges'],
            datasets: [{
                label: 'Service Charge Expense (KWD)',
                data: totals.length > 0 ? totals : [0],
                backgroundColor: [
                    '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b',
                    '#06b6d4', '#10b981', '#6366f1', '#f43f5e'
                ],
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(val) { return 'KWD ' + formatCurrency(val); }
                    }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return ` Total Spent: KWD ${formatCurrency(context.parsed.x)}`;
                        }
                    }
                }
            }
        }
    });
}

function renderInvoicesTable(data) {
    const tbody = document.getElementById('tableBody');
    const tfoot = document.getElementById('tableFooter');
    if (!tbody) return;

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No invoice details found</td></tr>';
        if (tfoot) tfoot.innerHTML = '';
        return;
    }

    let grandTotal = 0;
    let bodyHtml = '';

    data.forEach(inv => {
        const amt = parseFloat(inv.total) || 0;
        grandTotal += amt;

        const dateStr = inv.invoice_date ? new Date(inv.invoice_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : 'N/A';

        bodyHtml += `<tr>
            <td><strong>${inv.invoice_no || 'N/A'}</strong></td>
            <td>${inv.job_no || 'N/A'}</td>
            <td>${inv.customer_name || 'N/A'}</td>
            <td>${inv.customer_company || '-'}</td>
            <td>${inv.shipper_name || 'N/A'}</td>
            <td>${dateStr}</td>
            <td class="total-col">${formatCurrency(amt)}</td>
        </tr>`;
    });

    tbody.innerHTML = bodyHtml;

    if (tfoot) {
        tfoot.innerHTML = `
            <tr>
                <td style="font-weight: 700;">TOTAL ASSOCIATED SALES</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td class="total-col-grand">KWD ${formatCurrency(grandTotal)}</td>
            </tr>
        `;
    }
}
