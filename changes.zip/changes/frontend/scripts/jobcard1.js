
let lookupData = {};

async function loadLookupData() {
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/lookup/all`);
        if (!response.ok) throw new Error('Failed to load lookup data');
        const result = await response.json();

        if (result.success) {
            lookupData = result.data;
            populateDropdowns();
            populateMinistryApprovals();
            console.log('✅ Lookup data loaded successfully');
        }
    } catch (error) {
        console.error('❌ Failed to load lookup data:', error);
    }
}

function populateDropdowns() {
    // Populate Shipment Types
    populateSelect('shipmentType', lookupData.shipmentTypes, 'Select Type');

    // Populate Transport Modes
    populateSelect('transportMode', lookupData.transportModes, 'Select Mode');

    // Populate Cargo Types
    populateSelect('cargoType', lookupData.cargoTypes, 'Select Cargo Type');

    // Populate Service Modes
    populateSelect('serviceMode', lookupData.serviceModes, 'Select Service Mode');

    // Populate Incoterms
    populateSelect('incoterms', lookupData.incoterms, 'Select Incoterm');

    // Populate CC Regimes
    populateSelect('ccRegime', lookupData.ccRegimes, 'Select CC Regime');

    // Populate Responsible Persons
    populateSelect('responsiblePerson', lookupData.responsiblePersons, 'Select Person');
}

function populateSelect(elementId, data, placeholder) {
    const select = document.getElementById(elementId);
    if (!select) return;

    // Clear existing options (keep first option if it's a placeholder)
    while (select.options.length > 0) {
        select.remove(0);
    }

    // Add placeholder
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = placeholder;
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    select.appendChild(placeholderOption);

    // Add data options
    data.forEach(item => {
        const option = document.createElement('option');
        option.value = item.code; // Use code as value
        option.textContent = item.name;
        option.dataset.id = item.id; // Store the actual ID
        select.appendChild(option);
    });
}

function populateMinistryApprovals() {
    const container = document.getElementById('ministryDropdown');
    if (!container) return;

    container.innerHTML = '';

    lookupData.ministryApprovals.forEach(approval => {
        const label = document.createElement('label');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.value = approval.code;
        checkbox.dataset.id = approval.id;
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(' ' + approval.name));
        container.appendChild(label);
    });
}

// Job Card JavaScript with Enhanced Dropdown Functionality
document.addEventListener('DOMContentLoaded', function () {
    // Initialize the job card system
    initJobCardSystem();

    // Update system time
    updateSystemTime();
    setInterval(updateSystemTime, 1000);

    // Update stats from database
    updateStats();

    // Start periodic job number refresh every 3 seconds (changed from 10 seconds)
    startJobNumberRefresh();
});


// Add this function to start periodic refresh
function startJobNumberRefresh() {
    // Fetch immediately on load
    fetchNextJobNumber();

    // Then fetch every 3 seconds (changed from 10 seconds)
    setInterval(fetchNextJobNumber, 4000);

    console.log('Job number refresh interval started: 3 seconds');
}

function setupEntityDropdown(inputField, endpoint, entityName) {
    // Create wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'entity-dropdown-wrapper';
    wrapper.style.position = 'relative';
    wrapper.style.width = '100%';
    inputField.parentNode.insertBefore(wrapper, inputField);
    
    // Create select element
    const select = document.createElement('select');
    select.className = 'form-control entity-select';
    select.id = inputField.id + '-select';
    select.style.cssText = `
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 14px;
        font-family: 'Inter', sans-serif;
        background: white;
        cursor: pointer;
        appearance: auto;
        -webkit-appearance: auto;
        -moz-appearance: auto;
        transition: border-color 0.2s, box-shadow 0.2s;
    `;
    
    // Add placeholder option
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = `Select ${entityName}...`;
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    select.appendChild(placeholderOption);
    
    // Hide original input
    inputField.style.display = 'none';
    inputField.removeAttribute('required');
    
    // Insert select before original input
    wrapper.appendChild(select);
    wrapper.appendChild(inputField);
    
    // Load data
    async function loadData() {
        try {
            // Show loading
            select.innerHTML = '';
            const loadingOpt = document.createElement('option');
            loadingOpt.value = '';
            loadingOpt.textContent = 'Loading...';
            loadingOpt.disabled = true;
            select.appendChild(loadingOpt);
            
            // Fetch all items
            const url = `${Utils.getApiBaseUrl()}/api/${endpoint}`;
            const response = await fetch(url);
            const result = await response.json();
            
            // Clear select
            select.innerHTML = '';
            
            // Add placeholder
            const placeholderOpt = document.createElement('option');
            placeholderOpt.value = '';
            placeholderOpt.textContent = `Select ${entityName}...`;
            placeholderOpt.disabled = true;
            placeholderOpt.selected = true;
            select.appendChild(placeholderOpt);
            
            let items = [];
            if (result.success) {
                items = result.data || [];
            } else if (Array.isArray(result)) {
                items = result;
            }
            
            if (items.length > 0) {
                items.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    let label = item.name || item.company || 'Unnamed';
                    if (item.company && item.name !== item.company) {
                        label += ` (${item.company})`;
                    }
                    if (item.email) label += ` - ${item.email}`;
                    option.textContent = label;
                    option.dataset.name = item.name || item.company || '';
                    option.dataset.company = item.company || '';
                    option.dataset.email = item.email || '';
                    option.dataset.phone = item.phone || '';
                    option.dataset.reference_number = item.reference_number || '';
                    option.dataset.address = item.address || '';
                    select.appendChild(option);
                });
            } else {
                const noOpt = document.createElement('option');
                noOpt.value = '';
                noOpt.textContent = `No ${entityName}s found`;
                noOpt.disabled = true;
                select.appendChild(noOpt);
            }
            
            // Set selected value if input has value
            if (inputField.value) {
                for (let i = 0; i < select.options.length; i++) {
                    if (select.options[i].dataset.name === inputField.value) {
                        select.value = select.options[i].value;
                        break;
                    }
                }
            }
            
        } catch (error) {
            console.error(`Error loading ${endpoint}:`, error);
            select.innerHTML = '';
            const errorOpt = document.createElement('option');
            errorOpt.value = '';
            errorOpt.textContent = 'Error loading data';
            errorOpt.disabled = true;
            select.appendChild(errorOpt);
        }
    }
    
    // Handle select change
    select.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption && selectedOption.value) {
            inputField.value = selectedOption.dataset.name || selectedOption.textContent;
            inputField.dataset.id = selectedOption.value;
            inputField.dataset.company = selectedOption.dataset.company || '';
            inputField.dataset.email = selectedOption.dataset.email || '';
            inputField.dataset.phone = selectedOption.dataset.phone || '';
            inputField.dataset.reference_number = selectedOption.dataset.reference_number || '';
            inputField.dataset.address = selectedOption.dataset.address || '';
            
            // Auto-fill related fields
            autoFillRelatedFields(inputField, selectedOption.dataset);
        } else {
            inputField.value = '';
            inputField.dataset.id = '';
        }
        inputField.dispatchEvent(new Event('change', { bubbles: true }));
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
    });
    
    // Load initial data
    loadData();
    
    // Return refresh function
    return {
        refresh: loadData,
        select: select,
        input: inputField
    };
}

// Auto-fill related fields when selecting an entity
function autoFillRelatedFields(inputField, data) {
    if (inputField.id === 'customerName') {
        const refNo = document.getElementById('customerRefNo');
        const address = document.getElementById('customerAddress');
        const email = document.getElementById('email');
        const phone = document.getElementById('phone');
        if (refNo) refNo.value = data.reference_number || '';
        if (address) address.value = data.address || '';
        if (email) email.value = data.email || '';
        if (phone) phone.value = data.phone || '';
    }
    
    if (inputField.id === 'shipperName') {
        const refNo = document.getElementById('shipperRef');
        if (refNo) refNo.value = data.reference_number || '';
    }
    
    if (inputField.id === 'contactPerson') {
        const contactDetails = document.getElementById('contactDetails');
        const contactEmail = document.getElementById('contactEmail');
        if (contactDetails) contactDetails.value = data.phone || '';
        if (contactEmail) contactEmail.value = data.email || '';
    }
}



function setupStandardDropdownWithAdd(inputField, endpoint, displayField, placeholder) {
    // Create wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'standard-dropdown-wrapper';
    wrapper.style.position = 'relative';
    wrapper.style.width = '100%';
    inputField.parentNode.insertBefore(wrapper, inputField);
    
    // Create select element
    const select = document.createElement('select');
    select.className = 'form-control standard-select';
    select.id = inputField.id + '-select';
    select.style.cssText = `
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 14px;
        font-family: 'Inter', sans-serif;
        background: white;
        cursor: pointer;
        appearance: auto;
        -webkit-appearance: auto;
        -moz-appearance: auto;
        transition: border-color 0.2s, box-shadow 0.2s;
    `;
    
    // Add placeholder option
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = placeholder || `Select ${displayField}...`;
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    select.appendChild(placeholderOption);
    
    // Hide original input
    inputField.style.display = 'none';
    inputField.removeAttribute('required');
    
    // Insert select before original input
    wrapper.appendChild(select);
    wrapper.appendChild(inputField);
    
    // Load data
    async function loadData() {
        try {
            // Show loading
            select.innerHTML = '';
            const loadingOpt = document.createElement('option');
            loadingOpt.value = '';
            loadingOpt.textContent = 'Loading...';
            loadingOpt.disabled = true;
            select.appendChild(loadingOpt);
            
            const url = `${Utils.getApiBaseUrl()}/api/${endpoint}/all`;
            const response = await fetch(url);
            const result = await response.json();
            
            // Clear select
            select.innerHTML = '';
            
            // Add placeholder
            const placeholderOpt = document.createElement('option');
            placeholderOpt.value = '';
            placeholderOpt.textContent = placeholder || `Select ${displayField}...`;
            placeholderOpt.disabled = true;
            placeholderOpt.selected = true;
            select.appendChild(placeholderOpt);
            
            if (result.success && result.data && result.data.length > 0) {
                result.data.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    let label = item.name;
                    if (item.code) label += ` (${item.code})`;
                    if (item.country) label += ` - ${item.country}`;
                    if (item.city) label += `, ${item.city}`;
                    if (item.type) label += ` [${item.type}]`;
                    option.textContent = label;
                    option.dataset.name = item.name;
                    option.dataset.code = item.code || '';
                    option.dataset.country = item.country || '';
                    option.dataset.city = item.city || '';
                    option.dataset.type = item.type || '';
                    select.appendChild(option);
                });
            } else {
                const noOpt = document.createElement('option');
                noOpt.value = '';
                noOpt.textContent = `No ${displayField}s found`;
                noOpt.disabled = true;
                select.appendChild(noOpt);
            }
            
            // Set selected value if input has value
            if (inputField.value) {
                for (let i = 0; i < select.options.length; i++) {
                    if (select.options[i].dataset.name === inputField.value) {
                        select.value = select.options[i].value;
                        break;
                    }
                }
            }
            
        } catch (error) {
            console.error(`Error loading ${endpoint}:`, error);
            select.innerHTML = '';
            const errorOpt = document.createElement('option');
            errorOpt.value = '';
            errorOpt.textContent = 'Error loading data';
            errorOpt.disabled = true;
            select.appendChild(errorOpt);
        }
    }
    
    // Handle select change
    select.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption && selectedOption.value) {
            inputField.value = selectedOption.dataset.name || selectedOption.textContent;
            inputField.dataset.id = selectedOption.value;
            inputField.dataset.code = selectedOption.dataset.code || '';
            inputField.dataset.country = selectedOption.dataset.country || '';
            inputField.dataset.city = selectedOption.dataset.city || '';
            inputField.dataset.type = selectedOption.dataset.type || '';
        } else {
            inputField.value = '';
            inputField.dataset.id = '';
        }
        inputField.dispatchEvent(new Event('change', { bubbles: true }));
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
    });
    // ✅ ADD AUTO-REFRESH: Reload data when dropdown is clicked
    select.addEventListener('mousedown', function() {
        loadData();
    });
    // Load initial data
    loadData();
    
    // Return refresh function
    return {
        refresh: loadData,
        select: select,
        input: inputField
    };
}

function initJobCardSystem() {
    // Load lookup data first
    loadLookupData();

    // Generate job number
    generateJobNumber();

    // Initialize date fields
    initializeDates();

    // Setup enhanced auto-suggestions
    setupEnhancedAutocomplete();

    // Initialize location fields
    setupLocationFields();

    // Setup billing document fields
    setupBillingDocumentFields();

    // Setup form submission
    const jobCardForm = document.getElementById('jobCardForm');
    if (jobCardForm) {
        jobCardForm.addEventListener('submit', handleJobCardSubmit);
    }

    // Setup real-time preview
    setupRealTimePreview();

    // Setup edit button functionality
    setupEditButtons();

    // Add enhanced CSS styles
    addEnhancedStyles();

    // Add event listeners for mode changes
    setupModeTypeListeners();
    setupModalCloseButtons();

    // Shipping Line / Airline
    const shippingLineField = document.getElementById('shippingLine');
    if (shippingLineField) {
        setupStandardDropdownWithAdd(shippingLineField, 'shipping-lines', 'Shipping Line/Airline');
    }
    
    // Port of Loading (POL)
    const polField = document.getElementById('pol');
    if (polField) {
        setupStandardDropdownWithAdd(polField, 'ports', 'Port', 'Select Port of Loading');
    }
    
    // Port of Destination (POD)
    const podField = document.getElementById('pod');
    if (podField) {
        setupStandardDropdownWithAdd(podField, 'ports', 'Port', 'Select Port of Destination');
    }

     const transporterField = document.getElementById('transporter');
    if (transporterField) {
        // Use the same function as Shipping Line and Ports
        setupStandardDropdownWithAdd(transporterField, 'transporters', 'Transporter', 'Select Transporter...');
    }

    // Initialize cleanup array
    window.locationCleanups = [];
}


function setupModalCloseButtons() {
    // Close modal when clicking on overlay
    const modals = document.querySelectorAll('.modal-overlay');
    modals.forEach(modal => {
        modal.addEventListener('click', function (e) {
            if (e.target === this) {
                this.classList.remove('active');
                document.body.style.overflow = 'auto';
            }
        });
    });
}

// Add this function to format date-time strings
function formatDateTime(dateTimeString) {
    if (!dateTimeString || dateTimeString === 'Not Set') return 'Not Set';

    try {
        const date = new Date(dateTimeString);

        // If it's a valid date, format it
        if (!isNaN(date.getTime())) {
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            }) + ' ' + date.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
        } else {
            // Try to parse as just time if it's not a full datetime
            return dateTimeString;
        }
    } catch (e) {
        console.log('Error formatting datetime:', e, dateTimeString);
        return dateTimeString;
    }
}

function setupModeTypeListeners() {
    const modeSelect = document.getElementById('transportMode');
    const typeSelect = document.getElementById('shipmentType');

    if (modeSelect) {
        modeSelect.addEventListener('change', function () {
            setupLocationFields();
            setupBillingDocumentFields();
            
            // If mode is SJ, hide shipment type dropdown or auto-set it
            if (this.value === 'SJ' || this.value === 'SERVICE') {
                // Hide shipment type or set it to SJ
                if (typeSelect) {
                    typeSelect.value = 'SJ';
                    typeSelect.disabled = true;
                }
            } else {
                if (typeSelect) {
                    typeSelect.disabled = false;
                }
            }
            
            if (modeSelect.value && typeSelect.value) {
                fetchNextJobNumber();
            }
        });
    }

    if (typeSelect) {
        typeSelect.addEventListener('change', function () {
            if (typeSelect.value && modeSelect.value) {
                fetchNextJobNumber();
            }
        });
    }
}


function setupBillingDocumentFields() {
    const modeSelect = document.getElementById('transportMode');

    if (!modeSelect) return;

    // Show/hide MAWB/HAWB fields based on mode
    const mawbGroup = document.getElementById('mawb')?.closest('.form-group');
    const hawbGroup = document.getElementById('hawb')?.closest('.form-group');
    const shippingLineGroup = document.getElementById('shippingLine')?.closest('.form-group');

    if (mawbGroup) {
        mawbGroup.style.display = (modeSelect.value === 'AIR' || modeSelect.value === 'SEA') ? 'block' : 'block';
    }
    if (hawbGroup) {
        hawbGroup.style.display = (modeSelect.value === 'AIR' || modeSelect.value === 'SEA') ? 'block' : 'block';
    }
    if (shippingLineGroup) {
        shippingLineGroup.style.display = 'block';
    }
}

// Update fetchNextJobNumber to only fill if empty
async function fetchNextJobNumber() {
    try {
        const modeSelect = document.getElementById('transportMode');
        const typeSelect = document.getElementById('shipmentType');
        const jobNoField = document.getElementById('jobNo');

        // Get raw values from dropdown
        let mode = modeSelect ? modeSelect.value : 'ROA';
        let type = typeSelect ? typeSelect.value : 'I';

        // Mode mapping
        const modeMap = {
            'ROAD': 'ROA',
            'ROA': 'ROA',
            'AIR': 'AIR',
            'SEA': 'SEA',
            'MUL': 'MUL',
            'SJ': 'SJ',           // ← ADD SJ
            'SERVICE': 'SJ',      // ← ADD SJ alias
            'SERVICE JOB': 'SJ'   // ← ADD SJ alias
        };
        
        // Type mapping
        const typeMap = {
            'IMPORT': 'I',
            'EXPORT': 'E',
            'DOMESTIC': 'D',
            'SJ': 'SJ',
            'SERVICE': 'SJ',
            'I': 'I',
            'E': 'E',
            'D': 'D'
        };

        // Convert values
        mode = modeMap[mode] || 'ROA';
        type = typeMap[type] || 'I';

        console.log('Fetching job number with mode:', mode, 'type:', type);

        if (!mode || !type) {
            console.log('Mode or Type not selected, skipping job number fetch');
            return;
        }

        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/next-number?mode=${mode}&type=${type}`);
        const data = await response.json();

        if (jobNoField && data.nextJobNumber) {
            const currentValue = jobNoField.value;
            const isTemporary = !currentValue ||
                currentValue.includes('JC-') ||
                currentValue === jobNoField.dataset.previewNumber ||
                jobNoField.dataset.manuallyEdited !== 'true';

            if (isTemporary) {
                jobNoField.value = data.nextJobNumber;
                jobNoField.dataset.previewNumber = data.nextJobNumber;
                jobNoField.readOnly = false;
                jobNoField.classList.remove('auto-filled');

                if (!jobNoField.nextElementSibling ||
                    !jobNoField.nextElementSibling.classList.contains('field-hint')) {
                    const hint = document.createElement('small');
                    hint.className = 'field-hint';
                    hint.style.display = 'block';
                    hint.style.marginTop = '5px';
                    hint.style.color = '#6b7280';
                    hint.style.fontSize = '12px';
                    hint.textContent = 'Auto-generated. You can edit if needed.';
                    jobNoField.parentNode.appendChild(hint);

                    jobNoField.addEventListener('input', () => {
                        jobNoField.dataset.manuallyEdited = 'true';
                    }, { once: true });
                }
            }
            return data.nextJobNumber;
        }
    } catch (error) {
        console.error('Error fetching next job number:', error);
    }
}


// Add this helper function to check if job number already exists
async function checkJobNumberExists(jobNumber) {
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/check-number?jobNo=${encodeURIComponent(jobNumber)}`);
        const data = await response.json();
        return data.exists || false;
    } catch (error) {
        console.error('Error checking job number:', error);
        return false;
    }
}



function generateJobNumber() {
    const jobNoField = document.getElementById('jobNo');
    const modeSelect = document.getElementById('transportMode');
    const typeSelect = document.getElementById('shipmentType');

    if (jobNoField) {
        const isNewForm = !jobNoField.value ||
            jobNoField.value.trim() === '' ||
            jobNoField.value.includes('JC-') ||
            jobNoField.value === jobNoField.dataset.previewNumber;

        if (isNewForm && modeSelect && typeSelect && modeSelect.value && typeSelect.value) {
            fetchNextJobNumber();
        }
    }
}



function initializeDates() {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Set current date as default for operation date
    const operationDateField = document.getElementById('operationDate');
    if (operationDateField && !operationDateField.value) {
        operationDateField.value = todayStr;
    }

    // Set current date for declaration date
    const declarationDateField = document.getElementById('declarationDate');
    if (declarationDateField && !declarationDateField.value) {
        declarationDateField.value = todayStr;
    }

    // Set ATD to current time
    const atdField = document.getElementById('atd');
    if (atdField && !atdField.value) {
        const nowStr = now.toISOString().slice(0, 16);
        atdField.value = nowStr;
    }
}

// Enhanced autocomplete setup with proper dropdown positioning
function setupEnhancedAutocomplete() {
    // Customer - with dropdown + "Add New"
    const customerField = document.getElementById('customerName');
    if (customerField) {
        setupEntityDropdown(customerField, 'customers', 'Customer');
    }

    // Consignee - with dropdown + "Add New"
    const consigneeField = document.getElementById('consigneeName');
    if (consigneeField) {
        setupEntityDropdown(consigneeField, 'consignees', 'Consignee');
    }

    // Shipper - with dropdown + "Add New"
    const shipperField = document.getElementById('shipperName');
    if (shipperField) {
        setupEntityDropdown(shipperField, 'shippers', 'Shipper');
    }

    // Agent - with dropdown + "Add New"
    const agentField = document.getElementById('agent');
    if (agentField) {
        setupEntityDropdown(agentField, 'agents', 'Agent');
    }

    // Driver - with dropdown + "Add New"
    const driverField = document.getElementById('driverName');
    if (driverField) {
        setupEntityDropdown(driverField, 'drivers', 'Driver');
    }

    // Contact Person - with dropdown + "Add New"
    const contactField = document.getElementById('contactPerson');
    if (contactField) {
        setupEntityDropdown(contactField, 'contact_persons', 'Contact Person');
    }

    // Port of Arrival - Simple dropdown
    const portField = document.getElementById('portArrival');
    if (portField) {
        createPortDropdown(portField);
    }

    // Cost Center - Simple dropdown
    const costCenterField = document.getElementById('costCenter');
    if (costCenterField) {
        createCostCenterDropdown(costCenterField);
    }
}

function setupEntityDropdown(inputField, endpoint, entityName) {
    let dropdown = null;

    // Create wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'entity-dropdown-wrapper';
    wrapper.style.position = 'relative';
    inputField.parentNode.insertBefore(wrapper, inputField);
    wrapper.appendChild(inputField);

    // Add dropdown icon
    const icon = document.createElement('span');
    icon.className = 'dropdown-icon';
    icon.innerHTML = '▼';
    icon.style.cssText = `
        position: absolute; right: 12px; top: 50%; 
        transform: translateY(-50%); cursor: pointer;
        color: #6b7280; font-size: 12px;
    `;
    wrapper.appendChild(icon);

    // Input events
    inputField.addEventListener('focus', function () {
        fetchAndShowDropdown(this.value, endpoint, entityName);
    });

    inputField.addEventListener('input', function () {
        fetchAndShowDropdown(this.value, endpoint, entityName);
    });

    // Click outside to close
    document.addEventListener('click', function (e) {
        if (!wrapper.contains(e.target)) {
            if (dropdown) {
                dropdown.remove();
                dropdown = null;
            }
        }
    });

    async function fetchAndShowDropdown(searchTerm, endpoint, entityName) {
        // Remove existing dropdown
        if (dropdown) {
            dropdown.remove();
            dropdown = null;
        }

        try {
            // Direct request to specific endpoint
            const url = `${Utils.getApiBaseUrl()}/api/${endpoint}/search?q=${encodeURIComponent(searchTerm || '')}`;
            const response = await fetch(url);
            const items = await response.json();

            // Create dropdown
            dropdown = document.createElement('div');
            dropdown.className = 'entity-dropdown';
            dropdown.style.cssText = `
                position: absolute; top: 100%; left: 0; right: 0;
                background: white; border: 1px solid #d1d5db;
                border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,0.12);
                max-height: 250px; overflow-y: auto; z-index: 1000;
                margin-top: 4px;
            `;

            // Add "Create New" option FIRST
            const createNew = document.createElement('div');
            createNew.className = 'dropdown-item create-new';
            createNew.style.cssText = `
                padding: 12px 16px; cursor: pointer; 
                border-bottom: 2px dashed #d1d5db;
                background: #f0fdf4; color: #16a34a;
                font-weight: 600; display: flex; align-items: center; gap: 8px;
            `;
            createNew.innerHTML = `<span style="font-size:18px;">➕</span> Create New ${entityName}`;
            createNew.addEventListener('click', function (e) {
                e.stopPropagation();
                showCreateEntityModal(inputField, endpoint, entityName);
                if (dropdown) {
                    dropdown.remove();
                    dropdown = null;
                }
            });
            dropdown.appendChild(createNew);

            // If no items, show message
            if (!items || items.length === 0) {
                const noResult = document.createElement('div');
                noResult.className = 'dropdown-item';
                noResult.style.cssText = 'padding: 12px 16px; color: #9ca3af; font-style: italic;';
                noResult.textContent = `No ${entityName}s found. Click "Create New" to add.`;
                dropdown.appendChild(noResult);
            } else {
                // Add items
                items.forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'dropdown-item';
                    div.style.cssText = `
                        padding: 10px 16px; cursor: pointer; 
                        border-bottom: 1px solid #f3f4f6;
                        transition: background 0.15s;
                    `;
                    div.innerHTML = `
                        <div style="font-weight: 500; color: #111827;">${item.name || item.company || 'Unnamed'}</div>
                        ${item.company ? `<div style="font-size: 12px; color: #6b7280;">${item.company}</div>` : ''}
                        ${item.email ? `<div style="font-size: 11px; color: #9ca3af;">${item.email}</div>` : ''}
                    `;
                    div.addEventListener('mouseenter', function () {
                        this.style.background = '#f3f4f6';
                    });
                    div.addEventListener('mouseleave', function () {
                        this.style.background = 'transparent';
                    });
                    div.addEventListener('click', function (e) {
                        e.stopPropagation();
                        selectEntity(item, inputField, endpoint);
                        if (dropdown) {
                            dropdown.remove();
                            dropdown = null;
                        }
                    });
                    dropdown.appendChild(div);
                });
            }

            // Position dropdown
            const rect = wrapper.getBoundingClientRect();
            dropdown.style.width = rect.width + 'px';
            wrapper.appendChild(dropdown);

        } catch (error) {
            console.error(`Error fetching ${endpoint}:`, error);
        }
    }
}

function selectEntity(item, inputField, endpoint) {
    // Set the main field value
    inputField.value = item.name || item.company || '';

    // Auto-fill related fields based on which field we're filling
    if (inputField.id === 'customerName') {
        const refNo = document.getElementById('customerRefNo');
        const address = document.getElementById('customerAddress');
        const email = document.getElementById('email');
        const phone = document.getElementById('phone');

        if (refNo) refNo.value = item.reference_number || '';
        if (address) address.value = item.address || '';
        if (email) email.value = item.email || '';
        if (phone) phone.value = item.phone || '';
    }

    if (inputField.id === 'shipperName') {
        const refNo = document.getElementById('shipperRef');
        if (refNo) refNo.value = item.reference_number || '';
    }

    if (inputField.id === 'contactPerson') {
        const contactDetails = document.getElementById('contactDetails');
        const contactEmail = document.getElementById('contactEmail');

        if (contactDetails) contactDetails.value = item.phone || '';
        if (contactEmail) contactEmail.value = item.email || '';
    }

    // Trigger input event for preview
    inputField.dispatchEvent(new Event('input', { bubbles: true }));
}

function showCreateEntityModal(inputField, endpoint, entityName) {
    // Create modal
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = `
        position: fixed; inset: 0; background: rgba(0,0,0,0.5);
        display: flex; align-items: center; justify-content: center;
        z-index: 9999; animation: fadeIn 0.2s ease;
    `;

    const modal = document.createElement('div');
    modal.style.cssText = `
        background: white; border-radius: 16px; padding: 32px;
        max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        animation: slideUp 0.3s ease;
    `;

    modal.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
            <h3 style="margin: 0; font-size: 20px; color: #111827;">Create New ${entityName}</h3>
            <button onclick="this.closest('.modal-overlay').remove()" 
                    style="background: none; border: none; font-size: 24px; cursor: pointer; color: #9ca3af;">
                ✕
            </button>
        </div>
        <form id="createEntityForm">
            <div style="margin-bottom: 16px;">
                <label style="display: block; font-weight: 500; margin-bottom: 6px; color: #374151;">
                    Name <span style="color: #ef4444;">*</span>
                </label>
                <input type="text" id="newEntityName" required
                       style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px;">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display: block; font-weight: 500; margin-bottom: 6px; color: #374151;">
                    Company
                </label>
                <input type="text" id="newEntityCompany"
                       style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px;">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display: block; font-weight: 500; margin-bottom: 6px; color: #374151;">
                    Email
                </label>
                <input type="email" id="newEntityEmail"
                       style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px;">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display: block; font-weight: 500; margin-bottom: 6px; color: #374151;">
                    Phone
                </label>
                <input type="text" id="newEntityPhone"
                       style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px;">
            </div>
            <div style="margin-bottom: 24px;">
                <label style="display: block; font-weight: 500; margin-bottom: 6px; color: #374151;">
                    Address
                </label>
                <textarea id="newEntityAddress" rows="2"
                          style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; resize: vertical;"></textarea>
            </div>
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <button type="button" onclick="this.closest('.modal-overlay').remove()"
                        style="padding: 10px 24px; border: 1px solid #d1d5db; border-radius: 8px; background: white; cursor: pointer;">
                    Cancel
                </button>
                <button type="submit"
                        style="padding: 10px 24px; border: none; border-radius: 8px; background: #2563eb; color: white; cursor: pointer; font-weight: 500;">
                    Create ${entityName}
                </button>
            </div>
        </form>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Handle form submission
    const form = modal.querySelector('#createEntityForm');
    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const name = document.getElementById('newEntityName').value.trim();
        if (!name) {
            showNotification('Please enter a name.', 'error');
            return;
        }

        const data = {
            name: name,
            company: document.getElementById('newEntityCompany').value.trim(),
            email: document.getElementById('newEntityEmail').value.trim(),
            phone: document.getElementById('newEntityPhone').value.trim(),
            address: document.getElementById('newEntityAddress').value.trim()
        };

        try {
            // Direct request to specific endpoint
            const response = await fetch(`${Utils.getApiBaseUrl()}/api/${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                // Set the field value
                inputField.value = name;

                // Auto-fill related fields
                if (inputField.id === 'customerName') {
                    const refNo = document.getElementById('customerRefNo');
                    const address = document.getElementById('customerAddress');
                    const email = document.getElementById('email');
                    const phone = document.getElementById('phone');

                    if (refNo) refNo.value = result.data?.reference_number || '';
                    if (address) address.value = data.address || '';
                    if (email) email.value = data.email || '';
                    if (phone) phone.value = data.phone || '';
                }

                if (inputField.id === 'shipperName') {
                    const refNo = document.getElementById('shipperRef');
                    if (refNo) refNo.value = result.data?.reference_number || '';
                }

                if (inputField.id === 'contactPerson') {
                    const contactDetails = document.getElementById('contactDetails');
                    const contactEmail = document.getElementById('contactEmail');

                    if (contactDetails) contactDetails.value = data.phone || '';
                    if (contactEmail) contactEmail.value = data.email || '';
                }

                // Trigger input event
                inputField.dispatchEvent(new Event('input', { bubbles: true }));

                overlay.remove();
                showNotification(`${entityName} created successfully!`, 'success');
            } else {
                showNotification(result.message || 'Failed to create.', 'error');
            }
        } catch (error) {
            console.error('Create error:', error);
            showNotification('Error creating entity.', 'error');
        }
    });

    // Focus on name field
    setTimeout(() => {
        const nameField = document.getElementById('newEntityName');
        if (nameField) nameField.focus();
    }, 100);
}

function setupCreateNewHandlers() {
    // Add CSS animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .entity-dropdown .dropdown-item:hover { background: #f3f4f6 !important; }
        .entity-dropdown .create-new:hover { background: #dcfce7 !important; }
    `;
    document.head.appendChild(style);
}

// Update both createPortDropdown and createCostCenterDropdown functions
function createPortDropdown(inputField) {
    // Check if dropdown already exists and remove it
    const existingSelect = document.getElementById(inputField.id + '-select');
    const existingWrapper = inputField.nextElementSibling;

    if (existingSelect) {
        existingSelect.remove();
    }
    if (existingWrapper && existingWrapper.classList.contains('dropdown-wrapper')) {
        existingWrapper.remove();
    }

    // First, remove the required attribute from the hidden input
    // We'll make the select element required instead
    inputField.removeAttribute('required');

    // Hide the original input field
    inputField.style.display = 'none';

    // Create a simple select dropdown
    const select = document.createElement('select');
    select.className = 'form-control normal-dropdown';
    select.name = inputField.name + '-dropdown'; // Use different name to avoid conflict
    select.id = inputField.id + '-select';
    select.required = true; // Make select required instead

    // Add placeholder option
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = 'Select Port of Arrival';
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    select.appendChild(placeholderOption);

    // Add port options
    const ports = [
        "Jebel Ali Port, UAE",
        "Khalifa Port, UAE",
        "Hamad Port, Qatar",
        "Kuwait Port, Kuwait",
        "Shuwaikh Port, Kuwait",
        "King Abdulaziz Port, Saudi Arabia",
        "Jeddah Islamic Port, Saudi Arabia",
        "Port of Salalah, Oman",
        "Port of Bahrain, Bahrain",
        "Port of Singapore, Singapore",
        "Port Klang, Malaysia",
        "Port of Colombo, Sri Lanka",
        "Port of Karachi, Pakistan",
        "Nhava Sheva Port, India",
        "Chittagong Port, Bangladesh",
        "Port of Hong Kong, China",
        "Port of Shanghai, China",
        "Port of Busan, South Korea",
        "Port of Tokyo, Japan",
        "Port of Rotterdam, Netherlands",
        "Port of Hamburg, Germany",
        "Port of Antwerp, Belgium",
        "Port of Felixstowe, UK",
        "Port of Le Havre, France"
    ];

    // Add options to dropdown
    ports.forEach(port => {
        const option = document.createElement('option');
        option.value = port;
        option.textContent = port;
        select.appendChild(option);
    });

    // Set initial value if exists
    if (inputField.value) {
        select.value = inputField.value;
    }

    // Insert dropdown after input field
    const wrapper = document.createElement('div');
    wrapper.className = 'dropdown-wrapper';
    inputField.parentNode.insertBefore(wrapper, inputField.nextSibling);
    wrapper.appendChild(select);

    // Update hidden input when dropdown changes
    select.addEventListener('change', function () {
        inputField.value = this.value;
        // Trigger input event for preview
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
    });

    // Also trigger change on the select for validation
    select.addEventListener('change', function () {
        // Trigger validation check
        this.reportValidity();
    });

    // Set focusable tabindex
    select.tabIndex = inputField.tabIndex;
}

function createCostCenterDropdown(inputField) {
    // Check if dropdown already exists and remove it
    const existingSelect = document.getElementById(inputField.id + '-select');
    const existingWrapper = inputField.nextElementSibling;

    if (existingSelect) {
        existingSelect.remove();
    }
    if (existingWrapper && existingWrapper.classList.contains('dropdown-wrapper')) {
        existingWrapper.remove();
    }

    // First, remove the required attribute from the hidden input
    // We'll make the select element required instead
    inputField.removeAttribute('required');

    // Hide the original input field
    inputField.style.display = 'none';

    // Create a simple select dropdown
    const select = document.createElement('select');
    select.className = 'form-control normal-dropdown';
    select.name = inputField.name + '-dropdown'; // Use different name to avoid conflict
    select.id = inputField.id + '-select';
    select.required = true; // Make select required instead

    // Add placeholder option
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = 'Select Cost Center';
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    select.appendChild(placeholderOption);

    // Add cost center options
    const costCenters = [
        "UAE - Abu Dhabi",
        "UAE - Dubai",
        "UAE - Sharjah",
        "UAE - Ajman",
        "UAE - Umm Al-Quwain",
        "UAE - Ras Al Khaimah",
        "UAE - Fujairah",
        "Saudi Arabia - Riyadh",
        "Saudi Arabia - Jeddah",
        "Saudi Arabia - Dammam",
        "Saudi Arabia - Khobar",
        "Kuwait - Kuwait City",
        "Kuwait - Ahmadi",
        "Kuwait - Hawalli",
        "Qatar - Doha",
        "Qatar - Al Rayyan",
        "Bahrain - Manama",
        "Oman - Muscat",
        "Oman - Salalah",
        "International - UK",
        "International - USA",
        "International - Europe",
        "International - Asia Pacific",
        "Head Office - Kuwait"
    ];

    // Add options to dropdown
    costCenters.forEach(center => {
        const option = document.createElement('option');
        option.value = center;
        option.textContent = center;
        select.appendChild(option);
    });

    // Set initial value if exists
    if (inputField.value) {
        select.value = inputField.value;
    }

    // Insert dropdown after input field
    const wrapper = document.createElement('div');
    wrapper.className = 'dropdown-wrapper';
    inputField.parentNode.insertBefore(wrapper, inputField.nextSibling);
    wrapper.appendChild(select);

    // Update hidden input when dropdown changes
    select.addEventListener('change', function () {
        inputField.value = this.value;
        // Trigger input event for preview
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
    });

    // Also trigger change on the select for validation
    select.addEventListener('change', function () {
        // Trigger validation check
        this.reportValidity();
    });

    // Set focusable tabindex
    select.tabIndex = inputField.tabIndex;
}

function setupEnhancedCustomerAutocomplete(inputField) {
    let timeout;
    let dropdown = null;
    let selectedIndex = -1;
    let currentSuggestions = [];

    function showDropdown(suggestions) {
        removeDropdown();

        if (!suggestions || suggestions.length === 0) return;

        dropdown = document.createElement('div');
        dropdown.className = 'autocomplete-dropdown enhanced-dropdown';
        dropdown.style.width = inputField.offsetWidth + 'px';
        dropdown.style.position = 'absolute';
        dropdown.style.zIndex = '1000';

        // Create search header
        const searchHeader = document.createElement('div');
        searchHeader.className = 'dropdown-search-header';
        searchHeader.innerHTML = `
            <i class="fas fa-search"></i>
            <input type="text" class="dropdown-search-input" placeholder="Search customers...">
        `;
        dropdown.appendChild(searchHeader);

        // Create suggestions container
        const suggestionsContainer = document.createElement('div');
        suggestionsContainer.className = 'dropdown-suggestions';

        suggestions.forEach((customer, index) => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.dataset.index = index;
            item.innerHTML = `
                <div class="item-main">
                    <strong>${customer.name}</strong>
                    <span class="item-badge">${customer.company || 'No Company'}</span>
                </div>
                <div class="item-details">
                    <small><i class="fas fa-envelope"></i> ${customer.email || 'No email'}</small>
                    <small><i class="fas fa-phone"></i> ${customer.phone || 'No phone'}</small>
                </div>
            `;

            item.addEventListener('click', () => {
                selectCustomer(customer, inputField);
                removeDropdown();
            });

            item.addEventListener('mouseenter', () => {
                highlightItem(index);
            });

            suggestionsContainer.appendChild(item);
        });

        dropdown.appendChild(suggestionsContainer);

        // Position dropdown below input field
        positionDropdown(dropdown, inputField);

        document.body.appendChild(dropdown);

        // Setup search in dropdown
        const searchInput = dropdown.querySelector('.dropdown-search-input');
        if (searchInput) {
            searchInput.focus();
            searchInput.addEventListener('input', function (e) {
                filterDropdownSuggestions(e.target.value);
                selectedIndex = -1;
                highlightVisibleItem(-1);
            });
            searchInput.addEventListener('keydown', handleDropdownNavigation);
        }

        // Handle click outside
        document.addEventListener('click', handleClickOutside);
    }

    function filterDropdownSuggestions(searchTerm) {
        const items = dropdown.querySelectorAll('.autocomplete-item');
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(searchTerm.toLowerCase()) ? '' : 'none';
        });
    }

    function highlightItem(index) {
        const items = dropdown.querySelectorAll('.autocomplete-item');
        items.forEach((item, i) => {
            item.classList.toggle('highlighted', i === index);
        });
        selectedIndex = index;
    }

    function highlightVisibleItem(index) {
        if (!dropdown) return;

        const items = Array.from(
            dropdown.querySelectorAll('.autocomplete-item')
        ).filter(el => el.style.display !== 'none');

        items.forEach((item, i) => {
            item.classList.toggle('highlighted', i === index);
        });
    }

    function handleDropdownNavigation(e) {
        if (!dropdown) return;

        const items = Array.from(
            dropdown.querySelectorAll('.autocomplete-item')
        ).filter(el => el.style.display !== 'none');

        if (!items.length) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            selectedIndex = (selectedIndex + 1) % items.length;
            highlightVisibleItem(selectedIndex);
            items[selectedIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            selectedIndex = (selectedIndex - 1 + items.length) % items.length;
            highlightVisibleItem(selectedIndex);
            items[selectedIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter' && selectedIndex >= 0) {
            e.preventDefault();
            items[selectedIndex].click();
        } else if (e.key === 'Escape') {
            removeDropdown();
        }
    }

    function handleClickOutside(e) {
        if (dropdown && !dropdown.contains(e.target) && e.target !== inputField) {
            removeDropdown();
        }
    }

    function selectCustomer(customer, inputField) {
        // Fill customer details
        inputField.value = customer.name;

        // Auto-fill other customer fields
        const customerRefNo = document.getElementById('customerRefNo');
        const customerAddress = document.getElementById('customerAddress');
        const email = document.getElementById('email');
        const phone = document.getElementById('phone');

        if (customerRefNo) customerRefNo.value = customer.reference_number || '';
        if (customerAddress) {
            customerAddress.value = customer.address || '';
            markAutoFilled(customerAddress);
        }
        if (email) {
            email.value = customer.email || '';
            markAutoFilled(email);
        }
        if (phone) {
            phone.value = customer.phone || '';
            markAutoFilled(phone);
        }
    }

    inputField.addEventListener('input', function (e) {
        clearTimeout(timeout);
        const query = e.target.value.trim();

        if (query.length < 2) {
            removeDropdown();
            return;
        }

        timeout = setTimeout(async () => {
            try {
                const response = await fetch(`${Utils.getApiBaseUrl()}/api/customers/search?q=${encodeURIComponent(query)}`);
                if (response.ok) {
                    const customers = await response.json();
                    showDropdown(customers);
                }
            } catch (error) {
                console.error('Error fetching customers:', error);
            }
        }, 300);
    });

    inputField.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' && dropdown) {
            e.preventDefault();
            const items = Array.from(
                dropdown.querySelectorAll('.autocomplete-item')
            ).filter(el => el.style.display !== 'none');
            if (!items.length) return;
            selectedIndex = 0;
            highlightVisibleItem(selectedIndex);
            items[0].scrollIntoView({ block: 'nearest' });
        }
    });
}

function setupEnhancedShipperAutocomplete(inputField) {
    let timeout;
    let dropdown;
    let currentSuggestions = [];

    inputField.addEventListener('input', function (e) {
        clearTimeout(timeout);
        const query = e.target.value.trim();

        if (query.length < 2) {
            removeDropdown();
            return;
        }

        timeout = setTimeout(async () => {
            try {
                const response = await fetch(`${Utils.getApiBaseUrl()}/api/shippers/search?q=${encodeURIComponent(query)}`);
                if (response.ok) {
                    const shippers = await response.json();
                    currentSuggestions = shippers;
                    showEnhancedShipperDropdown(shippers, inputField);
                }
            } catch (error) {
                console.error('Error fetching shippers:', error);
            }
        }, 300);
    });

    function showEnhancedShipperDropdown(shippers, inputField) {
        removeDropdown();

        if (shippers.length === 0) return;

        dropdown = document.createElement('div');
        dropdown.className = 'autocomplete-dropdown enhanced-dropdown shipper-dropdown';
        dropdown.style.width = inputField.offsetWidth + 'px';
        dropdown.style.position = 'absolute';
        dropdown.style.zIndex = '1000';

        // Position dropdown
        positionDropdown(dropdown, inputField);

        shippers.forEach((shipper, index) => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.dataset.index = index;
            item.innerHTML = `
                <div class="item-main">
                    <strong>${shipper.name}</strong>
                    <span class="item-badge">${shipper.country || 'Unknown'}</span>
                </div>
                <div class="item-details">
                    <small><i class="fas fa-file-contract"></i> Ref: ${shipper.reference_number || 'No ref'}</small>
                    <small><i class="fas fa-building"></i> ${shipper.company || 'No company'}</small>
                </div>
            `;
            item.addEventListener('click', () => {
                selectEnhancedShipper(shipper, inputField);
                removeDropdown();
            });
            dropdown.appendChild(item);
        });

        document.body.appendChild(dropdown);

        // Handle click outside
        document.addEventListener('click', function (e) {
            if (dropdown && !dropdown.contains(e.target) && e.target !== inputField) {
                removeDropdown();
            }
        });
    }

    function selectEnhancedShipper(shipper, inputField) {
        inputField.value = shipper.name;

        // Auto-fill shipper reference number and make it read-only
        const shipperRefNoField = document.getElementById('shipperRefNo');
        if (shipperRefNoField) {
            shipperRefNoField.value = shipper.reference_number || '';
            shipperRefNoField.classList.add('auto-filled');
            shipperRefNoField.readOnly = true;

            // Add edit button
            addEditButton(shipperRefNoField);
        }
    }
}

// Enhanced requester autocomplete
function setupEnhancedRequesterAutocomplete(inputField) {
    let timeout;
    let dropdown;

    inputField.addEventListener('input', function (e) {
        clearTimeout(timeout);
        const query = e.target.value.trim();

        if (query.length < 2) {
            removeDropdown();
            return;
        }

        timeout = setTimeout(async () => {
            try {
                const response = await fetch(`${Utils.getApiBaseUrl()}/api/requesters/search?q=${encodeURIComponent(query)}`);
                if (response.ok) {
                    const requesters = await response.json();
                    showEnhancedRequesterDropdown(requesters, inputField);
                }
            } catch (error) {
                console.error('Error fetching requesters:', error);
            }
        }, 300);
    });

    function showEnhancedRequesterDropdown(requesters, inputField) {
        removeDropdown();

        if (requesters.length === 0) return;

        dropdown = document.createElement('div');
        dropdown.className = 'autocomplete-dropdown enhanced-dropdown';
        dropdown.style.width = inputField.offsetWidth + 'px';
        dropdown.style.position = 'absolute';
        dropdown.style.zIndex = '1000';

        // Position dropdown
        positionDropdown(dropdown, inputField);

        requesters.forEach(requester => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.innerHTML = `
                <div class="item-main">
                    <strong>${requester.name}</strong>
                    <span class="item-badge">${requester.department || 'No Dept'}</span>
                </div>
                <div class="item-details">
                    <small><i class="fas fa-building"></i> ${requester.company || 'No company'}</small>
                </div>
            `;
            item.addEventListener('click', () => {
                inputField.value = requester.name;
                removeDropdown();
            });
            dropdown.appendChild(item);
        });

        document.body.appendChild(dropdown);

        // Handle click outside
        document.addEventListener('click', function (e) {
            if (dropdown && !dropdown.contains(e.target) && e.target !== inputField) {
                removeDropdown();
            }
        });
    }
}

function removeDropdown() {
    const existing = document.querySelector('.autocomplete-dropdown');
    if (existing) {
        existing.remove();
    }
}

function positionDropdown(dropdown, inputField) {
    const rect = inputField.getBoundingClientRect();
    dropdown.style.top = (rect.bottom + window.scrollY + 2) + 'px';
    dropdown.style.left = (rect.left + window.scrollX) + 'px';
    dropdown.style.width = inputField.offsetWidth + 'px';
}

// Function to get billing document data
// Function to get billing document data
function getBillingDocumentData() {
    const mode = document.getElementById('modeOfTravel')?.value || '';
    const billingData = {};

    // Only include fields that have values
    switch (mode) {
        case 'AIR':
            const habw = document.getElementById('habw')?.value?.trim();
            const mabw = document.getElementById('mabw')?.value?.trim();
            if (habw) billingData.habw = habw;
            if (mabw) billingData.mabw = mabw;
            break;

        case 'SEA':
            const hbl = document.getElementById('hbl')?.value?.trim();
            const mbl = document.getElementById('mbl')?.value?.trim();
            if (hbl) billingData.hbl = hbl;
            if (mbl) billingData.mbl = mbl;
            break;

        case 'ROA':
            const roadWaybill = document.getElementById('roadWaybill')?.value?.trim();
            if (roadWaybill) billingData.roadWaybill = roadWaybill;
            break;

        case 'MUL':
            const multimodalRef = document.getElementById('multimodalRef')?.value?.trim();
            if (multimodalRef) billingData.multimodalRef = multimodalRef;
            break;
    }

    return billingData;
}




function markAutoFilled(field) {
    if (field) {
        field.classList.add('auto-filled');
        field.readOnly = true;

        // Add edit button
        addEditButton(field);
    }
}

function addEditButton(field) {
    // Remove existing edit button if any
    const existingBtn = field.parentNode.querySelector('.edit-auto-filled');
    if (existingBtn) existingBtn.remove();

    // Only add edit button if field is not job number (job number should be permanent after save)
    if (field.id === 'jobNo') {
        return;
    }

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'edit-auto-filled';
    editBtn.innerHTML = '<i class="fas fa-edit"></i>';
    editBtn.title = 'Edit this field';
    editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        field.classList.remove('auto-filled');
        field.readOnly = false;
        field.focus();
        editBtn.remove();
    });

    field.parentNode.style.position = 'relative';
    field.parentNode.appendChild(editBtn);
}

function setupEditButtons() {
    // Add edit buttons to auto-filled fields
    const autoFillableFields = [
        'customerAddress',
        'email',
        'phone',
        'shipperRefNo'
    ];

    autoFillableFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('focus', function () {
                if (this.classList.contains('auto-filled')) {
                    this.classList.remove('auto-filled');
                    this.readOnly = false;
                    const editBtn = this.parentNode.querySelector('.edit-auto-filled');
                    if (editBtn) editBtn.remove();
                }
            });
        }
    });
}

function setupRealTimePreview() {
    // Don't auto-update modal preview constantly
    // We'll update it when modal opens
}

function updatePreview() {
    const previewDiv = document.getElementById('jobCardPreview');
    if (!previewDiv) return;

    // Get values directly from the form fields
    const formData = {
        jobNo: document.getElementById('jobNo')?.value || 'Not Set',
        operationDate: document.getElementById('operationDate')?.value || 'Not Set',
        transportMode: document.getElementById('transportMode')?.value || 'Not Set',
        shipmentType: document.getElementById('shipmentType')?.value || 'Not Set',
        cargoType: document.getElementById('cargoType')?.value || 'Not Set',
        serviceMode: document.getElementById('serviceMode')?.value || 'Not Set',
        incoterms: document.getElementById('incoterms')?.value || 'Not Set',
        ccRegime: document.getElementById('ccRegime')?.value || 'Not Set',
        responsiblePerson: document.getElementById('responsiblePerson')?.value || 'Not Set',
        mawb: document.getElementById('mawb')?.value || 'Not Set',
        hawb: document.getElementById('hawb')?.value || 'Not Set',
        shippingLine: document.getElementById('shippingLine')?.value || 'Not Set',
        costCenter: document.getElementById('costCenter')?.value || 'Not Set',
        costCenterNumber: document.getElementById('costCenterNumber')?.value || 'Not Set',
        noOfPackages: document.getElementById('noOfPackages')?.value || '0',
        packagesUnit: document.getElementById('packagesUnit')?.value || 'pcs',
        grossWeight: document.getElementById('grossWeight')?.value || '0',
        grossWeightUnit: document.getElementById('grossWeightUnit')?.value || 'kg',
        nettWeight: document.getElementById('nettWeight')?.value || '0',
        nettWeightUnit: document.getElementById('nettWeightUnit')?.value || 'kg',
        chargeableWeight: document.getElementById('chargeableWeight')?.value || '0',
        chargeableWeightUnit: document.getElementById('chargeableWeightUnit')?.value || 'kg',
        volume: document.getElementById('volume')?.value || 'Not Set',
        shipperRef: document.getElementById('shipperRef')?.value || 'Not Set',
        customerName: document.getElementById('customerName')?.value || 'Not Set',
        consigneeName: document.getElementById('consigneeName')?.value || 'Not Set',
        shipperName: document.getElementById('shipperName')?.value || 'Not Set',
        agent: document.getElementById('agent')?.value || 'Not Set',
        pol: document.getElementById('pol')?.value || 'Not Set',
        pod: document.getElementById('pod')?.value || 'Not Set',
        atd: document.getElementById('atd')?.value || 'Not Set',
        ata: document.getElementById('ata')?.value || 'Not Set',
        transitTime: document.getElementById('transitTime')?.value || 'Not Set',
        driverName: document.getElementById('driverName')?.value || 'Not Set',
        vehicleNumber: document.getElementById('vehicleNumber')?.value || 'Not Set',
        deliveryLocation: document.getElementById('deliveryLocation')?.value || 'Not Set',
        customsLocation: document.getElementById('customsLocation')?.value || 'Not Set',
        contactPerson: document.getElementById('contactPerson')?.value || 'Not Set',
        contactDetails: document.getElementById('contactDetails')?.value || 'Not Set',
        contactEmail: document.getElementById('contactEmail')?.value || 'Not Set',
        declarationNumber: document.getElementById('declarationNumber')?.value || 'Not Set',
        declarationDate: document.getElementById('declarationDate')?.value || 'Not Set',
        bayanNumber: document.getElementById('bayanNumber')?.value || '',
        bayanDate: document.getElementById('bayanDate')?.value || '',
        clearanceDate: document.getElementById('clearanceDate')?.value || 'Not Set',
        deliveryDate: document.getElementById('deliveryDate')?.value || 'Not Set',
        ccNumber: document.getElementById('ccNumber')?.value || 'Not Set',
        requestorName: document.getElementById('requestorName')?.value || 'Not Set',
        poNumber: document.getElementById('poNumber')?.value || 'Not Set',
        deliveryStatus: document.getElementById('deliveryStatus')?.value || 'Not Set',
        commercialInvoiceNo: document.getElementById('commercialInvoiceNo')?.value || 'Not Set',
        deliveryNote: document.getElementById('deliveryNote')?.value || 'Not Set',
        masterRemarks: document.getElementById('masterRemarks')?.value || 'Not Set',
        attestedDocs: document.getElementById('attestedDocs')?.value || 'Not Set',
        depositCategory: document.getElementById('depositCategory')?.value || 'Not Set',
        depositAmount: document.getElementById('depositAmount')?.value || '0',
        depositCurrency: document.getElementById('depositCurrency')?.value || 'KD',
        depositAppliedDate: document.getElementById('depositAppliedDate')?.value || 'Not Set',
        customsDepositReleaseNo: document.getElementById('customsDepositReleaseNo')?.value || 'Not Set',
        depositRefundLastDate: document.getElementById('depositRefundLastDate')?.value || 'Not Set',
        clearanceRemarks: document.getElementById('clearanceRemarks')?.value || 'Not Set',
        bankGuaranteeNumber: document.getElementById('bankGuaranteeNumber')?.value || 'Not Set',
        issuanceBank: document.getElementById('issuanceBank')?.value || 'Not Set',
        bgAmount: document.getElementById('bgAmount')?.value || '0',
        tiBayanExpiryDate: document.getElementById('tiBayanExpiryDate')?.value || 'Not Set',
        tiFileStatus: document.getElementById('tiFileStatus')?.value || 'OPEN',
        tiPartNumber: document.getElementById('tiPartNumber')?.value || 'Not Set',
        partialReExport: document.getElementById('partialReExport')?.value || 'NO',
        partialReExportPn: document.getElementById('partialReExportPn')?.value || 'Not Set',
        tiRemarks: document.getElementById('tiRemarks')?.value || 'Not Set',
        tePartNumber: document.getElementById('tePartNumber')?.value || 'Not Set',
        teBayanExpiryDate: document.getElementById('teBayanExpiryDate')?.value || 'Not Set',
        teFileStatus: document.getElementById('teFileStatus')?.value || 'OPEN',
        teRemarks: document.getElementById('teRemarks')?.value || 'Not Set'
    };

    // Format display values
    const shipmentTypeMap = { 'I': 'Import', 'E': 'Export', 'D': 'Domestic' };
    const transportModeMap = { 'ROA': 'Road', 'AIR': 'Air', 'SEA': 'Sea', 'MUL': 'Multimodal' };

    let shipmentTypeDisplay = shipmentTypeMap[formData.shipmentType] || formData.shipmentType;
    let modeDisplay = transportModeMap[formData.transportMode] || formData.transportMode;

    // Get location data
    let departureLocation = formData.pol || 'Not Set';
    let arrivalLocation = formData.pod || 'Not Set';

    // Check if all fields are empty
    const allEmpty = Object.values(formData).every(value =>
        value === 'Not Set' || value === '0' || value === '' ||
        value === 'Not Provided' || value === null || value === undefined || value === 'pcs' || value === 'kg' || value === 'lbs' || value === 'KD'
    );

    if (allEmpty) {
        previewDiv.innerHTML = `
            <div class="preview-placeholder">
                <i class="fas fa-clipboard-list"></i>
                <p>Fill the form to see preview</p>
            </div>
        `;
        return;
    }

    previewDiv.innerHTML = `
        <div class="preview-content">
            <div class="preview-card">
                <div class="preview-section">
                    <h4>REFERENCE DETAILS</h4>
                    <div class="preview-item"><span class="preview-label">JOB NUMBER</span><span class="preview-value">${formData.jobNo}</span></div>
                    <div class="preview-item"><span class="preview-label">OPERATIONAL DATE</span><span class="preview-value">${formatDate(formData.operationDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">COST CENTER</span><span class="preview-value">${formData.costCenter}</span></div>
                    <div class="preview-item"><span class="preview-label">COST CENTER #</span><span class="preview-value">${formData.costCenterNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">TRANSPORT MODE</span><span class="preview-value">${modeDisplay}</span></div>
                    <div class="preview-item"><span class="preview-label">SHIPMENT TYPE</span><span class="preview-value">${shipmentTypeDisplay}</span></div>
                    <div class="preview-item"><span class="preview-label">CARGO TYPE</span><span class="preview-value">${formData.cargoType}</span></div>
                    <div class="preview-item"><span class="preview-label">SERVICE MODE</span><span class="preview-value">${formData.serviceMode}</span></div>
                    <div class="preview-item"><span class="preview-label">INCOTERMS</span><span class="preview-value">${formData.incoterms}</span></div>
                    <div class="preview-item"><span class="preview-label">CC REGIME</span><span class="preview-value">${formData.ccRegime}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>BILLING DOCUMENTS</h4>
                    <div class="preview-item"><span class="preview-label">MAWB / MBL</span><span class="preview-value">${formData.mawb}</span></div>
                    <div class="preview-item"><span class="preview-label">HAWB / HBL</span><span class="preview-value">${formData.hawb}</span></div>
                    <div class="preview-item"><span class="preview-label">SHIPPING LINE</span><span class="preview-value">${formData.shippingLine}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>CARGO SPECS</h4>
                    <div class="preview-item"><span class="preview-label">PACKAGES</span><span class="preview-value">${formData.noOfPackages} ${formData.packagesUnit}</span></div>
                    <div class="preview-item"><span class="preview-label">GROSS WEIGHT</span><span class="preview-value">${formData.grossWeight} ${formData.grossWeightUnit}</span></div>
                    <div class="preview-item"><span class="preview-label">NETT WEIGHT</span><span class="preview-value">${formData.nettWeight} ${formData.nettWeightUnit}</span></div>
                    <div class="preview-item"><span class="preview-label">CHARGEABLE WEIGHT</span><span class="preview-value">${formData.chargeableWeight} ${formData.chargeableWeightUnit}</span></div>
                    <div class="preview-item"><span class="preview-label">VOLUME</span><span class="preview-value">${formData.volume}</span></div>
                    <div class="preview-item"><span class="preview-label">SHIPPER REF #</span><span class="preview-value">${formData.shipperRef}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>STAKEHOLDERS</h4>
                    <div class="preview-item"><span class="preview-label">CUSTOMER</span><span class="preview-value">${formData.customerName}</span></div>
                    <div class="preview-item"><span class="preview-label">CONSIGNEE</span><span class="preview-value">${formData.consigneeName}</span></div>
                    <div class="preview-item"><span class="preview-label">SHIPPER</span><span class="preview-value">${formData.shipperName}</span></div>
                    <div class="preview-item"><span class="preview-label">AGENT</span><span class="preview-value">${formData.agent}</span></div>
                    <div class="preview-item"><span class="preview-label">RESPONSIBLE PERSON</span><span class="preview-value">${formData.responsiblePerson}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>ROUTING</h4>
                    <div class="preview-item"><span class="preview-label">PORT OF LOADING</span><span class="preview-value">${departureLocation}</span></div>
                    <div class="preview-item"><span class="preview-label">PORT OF DESTINATION</span><span class="preview-value">${arrivalLocation}</span></div>
                    <div class="preview-item"><span class="preview-label">ATD</span><span class="preview-value">${formatDateTime(formData.atd)}</span></div>
                    <div class="preview-item"><span class="preview-label">ATA</span><span class="preview-value">${formatDate(formData.ata)}</span></div>
                    <div class="preview-item"><span class="preview-label">TRANSIT TIME</span><span class="preview-value">${formData.transitTime}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>DELIVERY & CUSTOMS</h4>
                    <div class="preview-item"><span class="preview-label">DRIVER</span><span class="preview-value">${formData.driverName}</span></div>
                    <div class="preview-item"><span class="preview-label">VEHICLE #</span><span class="preview-value">${formData.vehicleNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">DELIVERY LOCATION</span><span class="preview-value">${formData.deliveryLocation}</span></div>
                    <div class="preview-item"><span class="preview-label">CUSTOMS LOCATION</span><span class="preview-value">${formData.customsLocation}</span></div>
                    <div class="preview-item"><span class="preview-label">CONTACT PERSON</span><span class="preview-value">${formData.contactPerson}</span></div>
                    <div class="preview-item"><span class="preview-label">CONTACT DETAILS</span><span class="preview-value">${formData.contactDetails}</span></div>
                    <div class="preview-item"><span class="preview-label">EMAIL</span><span class="preview-value">${formData.contactEmail}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>DECLARATION & DATES</h4>
                    <div class="preview-item"><span class="preview-label">DECLARATION #</span><span class="preview-value">${formData.declarationNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">DECLARATION DATE</span><span class="preview-value">${formatDate(formData.declarationDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">BAYAN #</span><span class="preview-value">${formData.bayanNumber || 'Not Set'}</span></div>
                    <div class="preview-item"><span class="preview-label">BAYAN DATE</span><span class="preview-value">${formatDate(formData.bayanDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">CLEARANCE DATE</span><span class="preview-value">${formatDate(formData.clearanceDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">DELIVERY DATE</span><span class="preview-value">${formatDate(formData.deliveryDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">CC NUMBER</span><span class="preview-value">${formData.ccNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">REQUESTOR</span><span class="preview-value">${formData.requestorName}</span></div>
                    <div class="preview-item"><span class="preview-label">PO NUMBER</span><span class="preview-value">${formData.poNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">STATUS</span><span class="preview-value">${formData.deliveryStatus}</span></div>
                    <div class="preview-item"><span class="preview-label">COMMERCIAL INVOICE #</span><span class="preview-value">${formData.commercialInvoiceNo}</span></div>
                    <div class="preview-item"><span class="preview-label">REMARKS</span><span class="preview-value">${formData.deliveryNote}</span></div>
                    <div class="preview-item"><span class="preview-label">MASTER REMARKS</span><span class="preview-value">${formData.masterRemarks}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>DEPOSITS</h4>
                    <div class="preview-item"><span class="preview-label">ATTESTED DOCS</span><span class="preview-value">${formData.attestedDocs}</span></div>
                    <div class="preview-item"><span class="preview-label">DEPOSIT CATEGORY</span><span class="preview-value">${formData.depositCategory}</span></div>
                    <div class="preview-item"><span class="preview-label">DEPOSIT AMOUNT</span><span class="preview-value">${formData.depositAmount} ${formData.depositCurrency}</span></div>
                    <div class="preview-item"><span class="preview-label">DEPOSIT APPLIED DATE</span><span class="preview-value">${formatDate(formData.depositAppliedDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">CUSTOMS DEPOSIT RELEASE #</span><span class="preview-value">${formData.customsDepositReleaseNo}</span></div>
                    <div class="preview-item"><span class="preview-label">DEPOSIT REFUND LAST DATE</span><span class="preview-value">${formatDate(formData.depositRefundLastDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">REMARKS</span><span class="preview-value">${formData.clearanceRemarks}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>TEMPORARY IMPORT</h4>
                    <div class="preview-item"><span class="preview-label">BANK GUARANTEE #</span><span class="preview-value">${formData.bankGuaranteeNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">ISSUANCE BANK</span><span class="preview-value">${formData.issuanceBank}</span></div>
                    <div class="preview-item"><span class="preview-label">BG AMOUNT</span><span class="preview-value">${formData.bgAmount} KWD</span></div>
                    <div class="preview-item"><span class="preview-label">BAYAN EXPIRY DATE</span><span class="preview-value">${formatDate(formData.tiBayanExpiryDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">FILE STATUS</span><span class="preview-value">${formData.tiFileStatus}</span></div>
                    <div class="preview-item"><span class="preview-label">PART NUMBER</span><span class="preview-value">${formData.tiPartNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">PARTIAL RE-EXPORT</span><span class="preview-value">${formData.partialReExport}</span></div>
                    <div class="preview-item"><span class="preview-label">PARTIAL RE-EXPORT P/N</span><span class="preview-value">${formData.partialReExportPn}</span></div>
                    <div class="preview-item"><span class="preview-label">REMARKS</span><span class="preview-value">${formData.tiRemarks}</span></div>
                </div>
            </div>
            
            <div class="preview-card">
                <div class="preview-section">
                    <h4>TEMPORARY EXPORT</h4>
                    <div class="preview-item"><span class="preview-label">PART NUMBER</span><span class="preview-value">${formData.tePartNumber}</span></div>
                    <div class="preview-item"><span class="preview-label">BAYAN EXPIRY DATE</span><span class="preview-value">${formatDate(formData.teBayanExpiryDate)}</span></div>
                    <div class="preview-item"><span class="preview-label">FILE STATUS</span><span class="preview-value">${formData.teFileStatus}</span></div>
                    <div class="preview-item"><span class="preview-label">REMARKS</span><span class="preview-value">${formData.teRemarks}</span></div>
                </div>
            </div>
        </div>
    `;
}


function formatDate(dateString) {
    if (!dateString || dateString === 'Not Set') return 'Not Set';

    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    } catch (e) {
        return dateString;
    }
}

function showPreviewModal() {
    // First validate the form
    const form = document.getElementById('jobCardForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // Update the preview
    updatePreview();

    // Show the modal
    const modal = document.getElementById('previewModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closePreviewModal() {
    const modal = document.getElementById('previewModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

function showSuccessModal(jobNumber, invoiceNumber) {
    console.log('Showing success modal with:', { jobNumber, invoiceNumber });

    // Update the modal content
    const savedJobNumber = document.getElementById('savedJobNumber');
    const generatedInvoice = document.getElementById('generatedInvoice');

    if (savedJobNumber) {
        savedJobNumber.textContent = jobNumber || 'JC-2026-0001';
    }
    if (generatedInvoice) {
        generatedInvoice.textContent = invoiceNumber || 'INV/2026/08321';
    }

    // Show the modal
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // Auto-close after 5 seconds
    setTimeout(() => {
        closeSuccessModal();
    }, 5000);
}


function closeSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';

    // Reset form for new entry
    resetForm();
}

// Update print function
function printJobCard() {
    window.print();
}
async function saveJobCard() {
    const form = document.getElementById('jobCardForm');

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const jobNoField = document.getElementById('jobNo');
    const modeSelect = document.getElementById('transportMode');
    const typeSelect = document.getElementById('shipmentType');

    // ✅ FIX: Define mode and jobNumber
    const mode = modeSelect ? modeSelect.value : '';
    const jobNumber = jobNoField ? jobNoField.value : '';

    // ✅ FIX: Validate mode
    if (!mode) {
        showNotification('Please select Mode of Travel.', 'error');
        return;
    }
    
    // ✅ FIX: For non-SJ modes, validate type
    if (mode !== 'SJ' && mode !== 'SERVICE') {
        if (!typeSelect || !typeSelect.value) {
            showNotification('Please select Shipment Type.', 'error');
            return;
        }
    }

    // Validate job number format based on mode
    let jobNoPattern;
    
    if (mode === 'SJ' || mode === 'SERVICE') {
        jobNoPattern = /^SJ-20\d{2}-\d{6}$/;
    } else {
        jobNoPattern = /^(ROA|AIR|SEA|MUL|JC)-[IED]-20\d{2}-\d{6}$/;
    }
    
    if (!jobNoPattern.test(jobNumber)) {
        let expectedFormat = mode === 'SJ' || mode === 'SERVICE' 
            ? 'SJ-2026-000001' 
            : 'AIR-E-2026-000001';
        showNotification(`Invalid job number format. Expected format: ${expectedFormat}`, 'error');
        jobNoField.focus();
        return;
    }

    // Get form data
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    const transporterInput = document.getElementById('transporter');
    const transporter = transporterInput ? transporterInput.value : '';
    const transporterId = transporterInput ? transporterInput.dataset.id : null;

    // Build payload
    // Build payload - using correct field names from HTML
    const payload = {
        jobNo: data.jobNo || '',
        operationDate: data.operationDate || '',
        transportMode: data.transportMode || '',
        shipmentType: data.shipmentType || '',
        cargoType: data.cargoType || '',
        serviceMode: data.serviceMode || '',
        incoterms: data.incoterms || '',
        ccRegime: data.ccRegime || '',
        responsiblePerson: data.responsiblePerson || '',
        mawb: data.mawb || '',
        hawb: data.hawb || '',
        shippingLine: data.shippingLine || '',
        costCenter: data.costCenter || '',
        costCenterNumber: data.costCenterNumber || '',
        noOfPackages: parseInt(data.noOfPackages) || 0,
        packagesUnit: data.packagesUnit || 'pcs',
        grossWeight: parseFloat(data.grossWeight) || 0,
        grossWeightUnit: data.grossWeightUnit || 'kg',
        nettWeight: parseFloat(data.nettWeight) || 0,
        nettWeightUnit: data.nettWeightUnit || 'kg',
        chargeableWeight: parseFloat(data.chargeableWeight) || 0,
        chargeableWeightUnit: data.chargeableWeightUnit || 'kg',
        volume: data.volume || '',
        shipperRef: data.shipperRef || '',
        customerName: data.customerName || '',
        customerRefNo: data.customerRefNo || '',
        consigneeName: data.consigneeName || '',
        consigneeRefNo: data.consigneeRefNo || '',
        shipperName: data.shipperName || '',
        shipperRefNo2: data.shipperRef || '',
        agent: data.agent || data.agentName || '',  // ✅ Correct
        agentRefNo: data.agentRefNo || '',
        pol: data.pol || '',
        pod: data.pod || '',
        atd: data.atd || '',
        ata: data.ata || '',
        transitTime: data.transitTime || '',
        driverName: data.driverName || '',
        vehicleNumber: data.vehicleNumber || '',
        deliveryLocation: data.deliveryLocation || '',
        customsLocation: data.customsLocation || '',
        contactPerson: data.contactPerson || '',
        contactDetails: data.contactDetails || '',
        contactEmail: data.contactEmail || '',
        declarationNumber: data.declarationNumber || '',
        declarationDate: data.declarationDate || '',
        bayanNumber: data.bayanNumber || '',
        bayanDate: data.bayanDate || '',
        clearanceDate: data.clearanceDate || '',
        deliveryDate: data.deliveryDate || '',
        ccNumber: data.ccNumber || '',
        requestorName: data.requestorName || '',
        poNumber: data.poNumber || '',
        deliveryStatus: data.deliveryStatus || '',
        commercialInvoiceNo: data.commercialInvoiceNo || '',
        deliveryNote: data.deliveryNote || '',
        masterRemarks: data.masterRemarks || '',
        attestedDocs: data.attestedDocs || '',
        depositCategory: data.depositCategory || '',
        depositAmount: parseFloat(data.depositAmount) || 0,
        depositCurrency: data.depositCurrency || 'KD',
        depositAppliedDate: data.depositAppliedDate || '',
        customsDepositReleaseNo: data.customsDepositReleaseNo || '',
        depositRefundLastDate: data.depositRefundLastDate || '',
        clearanceRemarks: data.clearanceRemarks || '',
        ministryApprovals: typeof getSelectedMinistryApprovals === 'function' ? getSelectedMinistryApprovals() : [],
        bankGuaranteeNumber: data.bankGuaranteeNumber || '',
        issuanceBank: data.issuanceBank || '',
        bgAmount: parseFloat(data.bgAmount) || 0,
        tiBayanExpiryDate: data.tiBayanExpiryDate || '',
        tiFileStatus: data.tiFileStatus || 'OPEN',
        tiPartNumber: data.tiPartNumber || '',
        partialReExport: data.partialReExport || 'NO',
        partialReExportPn: data.partialReExportPn || '',
        tiRemarks: data.tiRemarks || '',
        tePartNumber: data.tePartNumber || '',
        teBayanExpiryDate: data.teBayanExpiryDate || '',
        teFileStatus: data.teFileStatus || 'OPEN',
        teRemarks: data.teRemarks || '',
        status: 'draft',
        transporter: transporter || '',
        transporterId: transporterId || null,
        createdBy: document.getElementById('userName')?.textContent || 'Unknown'
    };

    // Show loading
    const submitBtn = document.querySelector('button[onclick="saveJobCard()"]') ||
        document.querySelector('.btn-success[onclick*="saveJobCard"]');
    let originalText = 'Save';
    if (submitBtn) {
        originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        submitBtn.disabled = true;
    }

    try {
        // Get API URL
        let apiBaseUrl = 'https://before-approach-rubber-liabilities.trycloudflare.com';
        try {
            if (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) {
                apiBaseUrl = Utils.getApiBaseUrl();
            }
        } catch (e) {
            console.warn('Utils not available, using fallback URL');
        }

        console.log('Sending payload:', payload);

        const response = await fetch(`${apiBaseUrl}/api/jobcards/save-draft`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        });

        const result = await response.json();
        console.log('Response from server:', result);

        if (response.ok && result.success) {
            // Get the job number - try multiple sources
            const jobNumber = result.jobNumber || result.jobNo || jobNoField.value || 'JC-2026-0001';
            const invoiceNumber = result.invoiceNumber || result.invoiceNo || 'INV/2026/08321';

            console.log('Job Number to display:', jobNumber);
            console.log('Invoice Number to display:', invoiceNumber);

            // Update the job number field if needed
            if (result.jobNumber && result.jobNumber !== jobNoField.value) {
                jobNoField.value = result.jobNumber;
            }

            // Store the ID for future reference
            window.currentJobCardId = result.id || result.jobCardId;

            // Make job number read-only after saving
            jobNoField.readOnly = true;
            jobNoField.classList.add('auto-filled');

            // Close preview modal
            closePreviewModal();

            // Show success modal with actual values
            showSuccessModal(jobNumber, invoiceNumber);

        } else {
            // Show error notification
            const errorMsg = result.message || 'Failed to save draft';
            console.error('Save failed:', errorMsg);
            showNotification('Error: ' + errorMsg, 'error');
        }

    } catch (error) {
        console.error('Save error:', error);
        showNotification('Error saving draft: ' + error.message, 'error');
    } finally {
        if (submitBtn) {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }
}


function setupEnhancedDropdownWithAdd(inputField, endpoint, displayField, placeholder) {
    let dropdown = null;
    let currentItems = [];
    let selectedIndex = -1;
    
    // Create wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'enhanced-dropdown-wrapper';
    wrapper.style.position = 'relative';
    wrapper.style.width = '100%';
    inputField.parentNode.insertBefore(wrapper, inputField);
    wrapper.appendChild(inputField);
    
    // Add dropdown icon
    const icon = document.createElement('span');
    icon.className = 'dropdown-icon';
    icon.innerHTML = '▼';
    icon.style.cssText = `
        position: absolute; right: 12px; top: 50%; 
        transform: translateY(-50%); cursor: pointer;
        color: #6b7280; font-size: 12px;
        pointer-events: none;
    `;
    wrapper.appendChild(icon);
    
    // Input events
    inputField.addEventListener('focus', function() {
        fetchAndShowDropdown(this.value);
    });
    
    inputField.addEventListener('input', function() {
        fetchAndShowDropdown(this.value);
    });
    
    // Click outside to close
    document.addEventListener('click', function(e) {
        if (!wrapper.contains(e.target)) {
            if (dropdown) {
                dropdown.remove();
                dropdown = null;
            }
        }
    });
    
    // Keyboard navigation
    inputField.addEventListener('keydown', function(e) {
        if (!dropdown) return;
        
        const items = dropdown.querySelectorAll('.dropdown-item:not(.create-new)');
        if (!items.length) return;
        
        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                selectedIndex = (selectedIndex + 1) % items.length;
                highlightItem(selectedIndex);
                items[selectedIndex]?.scrollIntoView({ block: 'nearest' });
                break;
            case 'ArrowUp':
                e.preventDefault();
                selectedIndex = (selectedIndex - 1 + items.length) % items.length;
                highlightItem(selectedIndex);
                items[selectedIndex]?.scrollIntoView({ block: 'nearest' });
                break;
            case 'Enter':
                e.preventDefault();
                if (selectedIndex >= 0 && items[selectedIndex]) {
                    items[selectedIndex].click();
                }
                break;
            case 'Escape':
                dropdown.remove();
                dropdown = null;
                break;
        }
    });
    
    function highlightItem(index) {
        const items = dropdown.querySelectorAll('.dropdown-item:not(.create-new)');
        items.forEach((item, i) => {
            item.style.background = i === index ? '#f0f7ff' : 'white';
        });
    }
    
    async function fetchAndShowDropdown(searchTerm) {
        // Remove existing dropdown
        if (dropdown) {
            dropdown.remove();
            dropdown = null;
        }
        
        try {
            const url = `${Utils.getApiBaseUrl()}/api/${endpoint}/search?q=${encodeURIComponent(searchTerm || '')}`;
            const response = await fetch(url);
            const items = await response.json();
            currentItems = items;
            
            // Create dropdown
            dropdown = document.createElement('div');
            dropdown.className = 'enhanced-entity-dropdown';
            dropdown.style.cssText = `
                position: absolute; top: calc(100% + 4px); left: 0; right: 0;
                background: white; border: 1px solid #d1d5db;
                border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,0.12);
                max-height: 250px; overflow-y: auto; z-index: 10000;
                min-width: 200px;
            `;
            
            // Add "Create New" option with inline input
            const createNew = document.createElement('div');
            createNew.className = 'dropdown-item create-new';
            createNew.style.cssText = `
                padding: 8px 12px; cursor: pointer; 
                border-bottom: 2px dashed #d1d5db;
                background: #f0fdf4; color: #16a34a;
                font-weight: 600; display: flex; align-items: center; gap: 8px;
                font-size: 13px;
                transition: background 0.2s;
            `;
            
            // Create inline add form
            const addForm = document.createElement('div');
            addForm.style.cssText = `
                display: none; padding: 8px 12px; 
                background: #f8fafc; border-bottom: 1px solid #e2e8f0;
                gap: 8px; align-items: center; flex-wrap: wrap;
            `;
            addForm.id = 'inline-add-form';
            
            const addInput = document.createElement('input');
            addInput.type = 'text';
            addInput.placeholder = `Enter new ${displayField} name...`;
            addInput.style.cssText = `
                flex: 1; padding: 6px 10px; border: 1px solid #d1d5db;
                border-radius: 4px; font-size: 13px; min-width: 120px;
            `;
            
            const addBtn = document.createElement('button');
            addBtn.textContent = 'Add';
            addBtn.style.cssText = `
                padding: 6px 14px; background: #16a34a; color: white;
                border: none; border-radius: 4px; cursor: pointer; font-size: 13px;
            `;
            addBtn.onclick = function(e) {
                e.stopPropagation();
                createNewItem(addInput.value.trim());
            };
            
            const cancelBtn = document.createElement('button');
            cancelBtn.textContent = 'Cancel';
            cancelBtn.style.cssText = `
                padding: 6px 14px; background: #e5e7eb; color: #374151;
                border: none; border-radius: 4px; cursor: pointer; font-size: 13px;
            `;
            cancelBtn.onclick = function(e) {
                e.stopPropagation();
                addForm.style.display = 'none';
                createNew.style.display = 'flex';
            };
            
            addForm.appendChild(addInput);
            addForm.appendChild(addBtn);
            addForm.appendChild(cancelBtn);
            
            createNew.innerHTML = `<span style="font-size:16px;">➕</span> Add New ${displayField}`;
            
            createNew.onclick = function(e) {
                e.stopPropagation();
                if (addForm.style.display === 'flex') {
                    addForm.style.display = 'none';
                    createNew.style.display = 'flex';
                } else {
                    createNew.style.display = 'none';
                    addForm.style.display = 'flex';
                    addInput.focus();
                }
            };
            
            dropdown.appendChild(createNew);
            dropdown.appendChild(addForm);
            
            // Handle Enter key in add input
            addInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    createNewItem(this.value.trim());
                }
                if (e.key === 'Escape') {
                    addForm.style.display = 'none';
                    createNew.style.display = 'flex';
                }
            });
            
            // Add items
            if (!items || items.length === 0) {
                const noResult = document.createElement('div');
                noResult.className = 'dropdown-item';
                noResult.style.cssText = 'padding: 10px 16px; color: #9ca3af; font-style: italic; font-size: 13px;';
                noResult.textContent = `No ${displayField}s found. Click "Add New" to create.`;
                dropdown.appendChild(noResult);
            } else {
                items.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'dropdown-item';
                    div.style.cssText = `
                        padding: 10px 16px; cursor: pointer; 
                        border-bottom: 1px solid #f3f4f6;
                        transition: background 0.15s;
                        font-size: 13px;
                    `;
                    div.innerHTML = `
                        <div style="font-weight: 500; color: #111827;">${item.name}</div>
                        ${item.code ? `<div style="font-size: 11px; color: #6b7280;">Code: ${item.code}</div>` : ''}
                        ${item.country ? `<div style="font-size: 11px; color: #6b7280;">${item.country}</div>` : ''}
                        ${item.city ? `<div style="font-size: 11px; color: #6b7280;">${item.city}</div>` : ''}
                        ${item.type ? `<div style="font-size: 11px; color: #6b7280;">${item.type}</div>` : ''}
                    `;
                    div.addEventListener('mouseenter', function() {
                        this.style.background = '#f3f4f6';
                    });
                    div.addEventListener('mouseleave', function() {
                        this.style.background = 'transparent';
                    });
                    div.addEventListener('click', function(e) {
                        e.stopPropagation();
                        selectItem(item, inputField);
                        if (dropdown) {
                            dropdown.remove();
                            dropdown = null;
                        }
                    });
                    dropdown.appendChild(div);
                });
            }
            
            // Position dropdown
            const rect = wrapper.getBoundingClientRect();
            dropdown.style.width = rect.width + 'px';
            wrapper.appendChild(dropdown);
            
        } catch (error) {
            console.error(`Error fetching ${endpoint}:`, error);
        }
    }
    
    async function createNewItem(name) {
        if (!name) {
            showNotification(`Please enter a ${displayField} name.`, 'error');
            return;
        }
        
        try {
            // Try to determine if it's a shipping line or port
            let endpointUrl = `/api/${endpoint}`;
            let payload = { name: name };
            
            // Add extra fields based on endpoint
            if (endpoint === 'shipping-lines') {
                payload.type = 'shipping';
                payload.country = '';
            } else if (endpoint === 'ports') {
                payload.type = 'seaport';
                payload.country = '';
                payload.city = '';
            }
            
            const response = await fetch(`${Utils.getApiBaseUrl()}${endpointUrl}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            
            const result = await response.json();
            
            if (result.success) {
                const newItem = result.data;
                inputField.value = newItem.name;
                inputField.dataset.id = newItem.id;
                
                // Close dropdown
                if (dropdown) {
                    dropdown.remove();
                    dropdown = null;
                }
                
                showNotification(`${displayField} created successfully!`, 'success');
                
                // Trigger change event
                inputField.dispatchEvent(new Event('change', { bubbles: true }));
                inputField.dispatchEvent(new Event('input', { bubbles: true }));
                
                // Refresh the dropdown options
                fetchAndShowDropdown('');
                
            } else {
                showNotification(result.message || 'Failed to create.', 'error');
            }
        } catch (error) {
            console.error('Create error:', error);
            showNotification('Error creating entity.', 'error');
        }
    }
    
    function selectItem(item, inputField) {
        inputField.value = item.name;
        inputField.dataset.id = item.id;
        inputField.dataset.code = item.code || '';
        inputField.dataset.country = item.country || '';
        inputField.dataset.city = item.city || '';
        inputField.dataset.type = item.type || '';
        
        // Trigger change event
        inputField.dispatchEvent(new Event('change', { bubbles: true }));
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
    }
}


function getSelectedMinistryApprovals() {
    const checkboxes = document.querySelectorAll('#ministryDropdown input[type="checkbox"]:checked');
    return Array.from(checkboxes).map(cb => cb.value);
}


function getGeneralizedLocationData() {
    // Get values from the actual form fields
    const pol = document.getElementById('pol')?.value || '';
    const pod = document.getElementById('pod')?.value || '';

    let departureLocation = pol || 'Kuwait';
    let arrivalLocation = pod || '';

    return { departureLocation, arrivalLocation };
}


async function loadJobCard(jobId) {
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/${jobId}/edit-details`);
        if (!response.ok) throw new Error('Failed to load job card');
        const result = await response.json();

        if (result.success) {
            populateForm(result.data);
            console.log('✅ Job card loaded successfully');
        }
    } catch (error) {
        console.error('❌ Failed to load job card:', error);
        showNotification('Failed to load job card', 'error');
    }
}


function populateForm(data) {
    // Map backend fields to form fields
    const fieldMap = {
        jobNo: 'jobNo',
        operationDate: 'operationDate',
        transportMode: 'transportMode',
        shipmentType: 'shipmentType',
        cargoType: 'cargoType',
        serviceMode: 'serviceMode',
        incoterms: 'incoterms',
        ccRegime: 'ccRegime',
        responsiblePerson: 'responsiblePerson',
        mawb: 'mawb',
        hawb: 'hawb',
        shippingLine: 'shippingLine',
        costCenter: 'costCenter',
        costCenterNumber: 'costCenterNumber',
        noOfPackages: 'noOfPackages',
        packagesUnit: 'packagesUnit',
        grossWeight: 'grossWeight',
        grossWeightUnit: 'grossWeightUnit',
        nettWeight: 'nettWeight',
        nettWeightUnit: 'nettWeightUnit',
        chargeableWeight: 'chargeableWeight',
        chargeableWeightUnit: 'chargeableWeightUnit',
        volume: 'volume',
        shipperRef: 'shipperRef',
        customer_name: 'customerName',
        consignee_name: 'consigneeName',
        shipper_name: 'shipperName',
        agent_name: 'agent',
        pol: 'pol',
        pod: 'pod',
        atd: 'atd',
        ata: 'ata',
        transitTime: 'transitTime',
        driverName: 'driverName',
        vehicleNumber: 'vehicleNumber',
        deliveryLocation: 'deliveryLocation',
        customsLocation: 'customsLocation',
        contactPerson: 'contactPerson',
        contactDetails: 'contactDetails',
        contactEmail: 'contactEmail',
        declarationNumber: 'declarationNumber',
        declarationDate: 'declarationDate',
        bayanNumber: 'bayanNumber',
        bayanDate: 'bayanDate',
        clearanceDate: 'clearanceDate',
        deliveryDate: 'deliveryDate',
        ccNumber: 'ccNumber',
        requestorName: 'requestorName',
        poNumber: 'poNumber',
        deliveryStatus: 'deliveryStatus',
        commercialInvoiceNo: 'commercialInvoiceNo',
        deliveryNote: 'deliveryNote',
        masterRemarks: 'masterRemarks',
        attestedDocs: 'attestedDocs',
        depositCategory: 'depositCategory',
        depositAmount: 'depositAmount',
        depositCurrency: 'depositCurrency',
        depositAppliedDate: 'depositAppliedDate',
        customsDepositReleaseNo: 'customsDepositReleaseNo',
        depositRefundLastDate: 'depositRefundLastDate',
        clearanceRemarks: 'clearanceRemarks',
        bankGuaranteeNumber: 'bankGuaranteeNumber',
        issuanceBank: 'issuanceBank',
        bgAmount: 'bgAmount',
        tiBayanExpiryDate: 'tiBayanExpiryDate',
        tiFileStatus: 'tiFileStatus',
        tiPartNumber: 'tiPartNumber',
        partialReExport: 'partialReExport',
        partialReExportPn: 'partialReExportPn',
        tiRemarks: 'tiRemarks',
        tePartNumber: 'tePartNumber',
        teBayanExpiryDate: 'teBayanExpiryDate',
        teFileStatus: 'teFileStatus',
        teRemarks: 'teRemarks'
    };

    for (const [backendField, formField] of Object.entries(fieldMap)) {
        const element = document.getElementById(formField);
        if (element && data[backendField] !== undefined && data[backendField] !== null) {
            element.value = data[backendField];
        }
    }

    // Handle ministry approvals
    if (data.ministry_approvals && Array.isArray(data.ministry_approvals)) {
        const checkboxes = document.querySelectorAll('#ministryDropdown input[type="checkbox"]');
        checkboxes.forEach(cb => {
            cb.checked = data.ministry_approvals.some(a => a.id === cb.dataset.id);
        });
    }
}

// Add this helper function to sync dropdown values
function syncDropdownValuesToForm() {
    // Sync cost center dropdown
    const costCenterSelect = document.getElementById('costCenter-select');
    const costCenterInput = document.getElementById('costCenter');
    if (costCenterSelect && costCenterInput) {
        costCenterInput.value = costCenterSelect.value;
    }
}

async function handleJobCardSubmit(event) {
    event.preventDefault();

    const form = event.target;
    syncDropdownValuesToForm();

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const jobNoField = document.getElementById('jobNo');
    const modeSelect = document.getElementById('transportMode');
    const typeSelect = document.getElementById('shipmentType');
    
    const mode = modeSelect ? modeSelect.value : '';
    const jobNumber = jobNoField ? jobNoField.value : '';  // ✅ FIX: Define jobNumber
    
    // ✅ FIX: Validate mode
    if (!mode) {
        showNotification('Please select Mode of Travel.', 'error');
        return;
    }
    
    // ✅ FIX: For non-SJ modes, validate that type is selected
    if (mode !== 'SJ' && mode !== 'SERVICE') {
        if (!typeSelect || !typeSelect.value) {
            showNotification('Please select Shipment Type.', 'error');
            return;
        }
    }

    // Validate job number format based on mode
    let jobNoPattern;
    
    if (mode === 'SJ' || mode === 'SERVICE') {
        // SJ format: SJ-2026-000001
        jobNoPattern = /^SJ-20\d{2}-\d{6}$/;
    } else {
        // Regular format
        jobNoPattern = /^(ROA|AIR|SEA|MUL|JC)-[IED]-20\d{2}-\d{6}$/;
    }
    
    if (!jobNoPattern.test(jobNumber)) {
        let expectedFormat = mode === 'SJ' || mode === 'SERVICE' 
            ? 'SJ-2026-000001' 
            : 'AIR-E-2026-000001';
        showNotification(`Invalid job number format. Expected format: ${expectedFormat}`, 'error');
        jobNoField.focus();
        return;
    }

    // Check if job number already exists (only for new entries)
    if (!window.currentJobCardId) {
        const exists = await checkJobNumberExists(jobNoField.value);
        if (exists) {
            showNotification('Job number already exists. Please use a different number.', 'error');
            jobNoField.focus();
            return;
        }
    }

    // Get generalized location data
    const { departureLocation, arrivalLocation } = getGeneralizedLocationData();

    // Create form data
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    data.arrivalLocation = arrivalLocation;

    const payload = {
        jobNo: data.jobNo || '',
        operationDate: data.operationDate || '',
        transportMode: data.transportMode || '',
        shipmentType: data.shipmentType || '',
        cargoType: data.cargoType || '',
        serviceMode: data.serviceMode || '',
        incoterms: data.incoterms || '',
        ccRegime: data.ccRegime || '',
        responsiblePerson: data.responsiblePerson || '',
        mawb: data.mawb || '',
        hawb: data.hawb || '',
        shippingLine: data.shippingLine || '',
        costCenter: data.costCenter || '',
        costCenterNumber: data.costCenterNumber || '',
        noOfPackages: parseInt(data.noOfPackages) || 0,
        packagesUnit: data.packagesUnit || 'pcs',
        grossWeight: parseFloat(data.grossWeight) || 0,
        grossWeightUnit: data.grossWeightUnit || 'kg',
        nettWeight: parseFloat(data.nettWeight) || 0,
        nettWeightUnit: data.nettWeightUnit || 'kg',
        chargeableWeight: parseFloat(data.chargeableWeight) || 0,
        chargeableWeightUnit: data.chargeableWeightUnit || 'kg',
        volume: parseFloat(data.volume) || 0,
        shipperRefNo: data.shipperRefNo || '',
        customerName: data.customerName || '',
        customerRefNo: data.customerRefNo || '',
        consigneeName: data.consigneeName || '',
        consigneeRefNo: data.consigneeRefNo || '',
        shipperName: data.shipperName || '',
        shipperRefNo2: data.shipperRefNo || '',
        agent: data.agent || data.agentName || '',
        agentRefNo: data.agentRefNo || '',
        pol: data.pol || '',
        pod: data.pod || '',
        atd: data.atd || '',
        ata: data.ata || '',
        transitTime: parseInt(data.transitTime) || 0,
        driverName: data.driverName || '',
        vehicleNumber: data.vehicleNumber || '',
        deliveryLocation: data.deliveryLocation || '',
        customsLocation: data.customsLocation || '',
        contactPerson: data.contactPerson || '',
        contactDetails: data.contactDetails || '',
        contactEmail: data.contactEmail || '',
        declarationNumber: data.declarationNumber || '',
        declarationDate: data.declarationDate || '',
        bayanNumber: data.bayanNumber || '',
        bayanDate: data.bayanDate || '',
        clearanceDate: data.clearanceDate || '',
        deliveryDate: data.deliveryDate || '',
        ccNumber: data.ccNumber || '',
        requestorName: data.requestorName || '',
        poNumber: data.poNumber || '',
        deliveryStatus: data.deliveryStatus || '',
        commercialInvoiceNo: data.commercialInvoiceNo || '',
        deliveryRemarks: data.deliveryRemarks || '',
        attestedDocsReceived: data.attestedDocsReceived === 'on',
        depositCategory: data.depositCategory || '',
        depositAmount: parseFloat(data.depositAmount) || 0,
        depositCurrency: data.depositCurrency || 'KWD',
        depositAppliedDate: data.depositAppliedDate || '',
        customsDepositReleaseNo: data.customsDepositReleaseNo || '',
        depositRefundLastDate: data.depositRefundLastDate || '',
        clearanceRemarks: data.clearanceRemarks || '',
        bankGuaranteeNumber: data.bankGuaranteeNumber || '',
        issuanceBank: data.issuanceBank || '',
        bgAmount: parseFloat(data.bgAmount) || 0,
        tiBayanExpiryDate: data.tiBayanExpiryDate || '',
        tiFileStatus: data.tiFileStatus || '',
        tiPartNumber: data.tiPartNumber || '',
        partialReExport: data.partialReExport === 'on',
        partialReExportPn: data.partialReExportPn || '',
        tiRemarks: data.tiRemarks || '',
        tePartNumber: data.tePartNumber || '',
        teBayanExpiryDate: data.teBayanExpiryDate || '',
        teFileStatus: data.teFileStatus || '',
        teRemarks: data.teRemarks || '',
        status: 'submitted',
        submittedAt: new Date().toISOString(),
        submittedBy: document.getElementById('userName')?.textContent || 'Unknown'
    };

    // Use existing draft ID or create new
    if (window.currentJobCardId) {
        data.id = window.currentJobCardId;
    }

    delete data.departureArea;
    delete data.arrivalArea;
    delete data.departurePoint;
    delete data.arrivalPoint;
    delete data.portArrival;

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    submitBtn.disabled = true;

    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/submit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            const result = await response.json();

            // Make job number permanently read-only
            jobNoField.readOnly = true;
            jobNoField.classList.add('auto-filled');

            // Remove edit button
            const editBtn = jobNoField.parentNode.querySelector('.edit-auto-filled');
            if (editBtn) editBtn.remove();

            // Show success widget
            showSuccessWidget(result.jobNumber);

            // Reset form for new entry after delay
            setTimeout(() => {
                form.reset();
                window.currentJobCardId = null;

                // Generate new job number for next entry
                generateJobNumber();
                initializeDates();
                updatePreview();
                updateStats();
            }, 3000);
        } else {
            const error = await response.json();
            showNotification('Error submitting job card: ' + (error.message || 'Unknown error'), 'error');
            throw new Error('Submission failed');
        }
    } catch (error) {
        showNotification('Error submitting job card: ' + error.message, 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}


function showErrorWidget(message = 'Submission failed') {
    // Remove existing widget
    const existing = document.querySelector('.modern-notification-widget');
    if (existing) {
        existing.remove();
    }

    // Create modern error widget
    const widget = document.createElement('div');
    widget.className = 'modern-notification-widget error';
    widget.innerHTML = `
        <div class="modern-widget-content">
            <div class="modern-widget-icon">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <div class="modern-widget-details">
                <h3>ERROR!</h3>
                <p>Thank you for your request.</p>
                <p>We are unable to continue the process.</p>
                <p>${message}</p>
                <div class="modern-widget-actions">
                    <button onclick="closeModernWidget()" class="modern-btn modern-btn-primary">
                        Try Again
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(widget);
}

function resetForm() {
    if (confirm('Are you sure you want to reset the form? All entered data will be lost.')) {
        const form = document.getElementById('jobCardForm');
        const jobNoField = document.getElementById('jobNo');
        const modeSelect = document.getElementById('transportMode');
        const typeSelect = document.getElementById('shipmentType');

        const currentJobNo = jobNoField.value;
        const currentMode = modeSelect ? modeSelect.value : '';
        const currentType = typeSelect ? typeSelect.value : '';

        form.reset();
        window.currentJobCardId = null;

        if (modeSelect) modeSelect.value = '';
        if (typeSelect) typeSelect.value = '';

        setupLocationFields();
        setupBillingDocumentFields();

        if (currentJobNo && currentMode && currentType) {
            jobNoField.value = currentJobNo;
            jobNoField.readOnly = false;
            jobNoField.classList.remove('auto-filled');
        } else {
            jobNoField.value = '';
        }

        initializeDates();
        updatePreview();
        showNotification('Form has been reset', 'info');
    }
}






async function generateInvoice() {
    const form = document.getElementById('jobCardForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Validate required fields
    const requiredFields = ['jobNo', 'customerName', 'customerRefNo', 'grossWeight', 'packages'];
    const missingFields = requiredFields.filter(field => !data[field]);

    if (missingFields.length > 0) {
        showNotification('Please fill all required fields before generating invoice.', 'error');
        return;
    }

    // First save as draft if not saved
    if (!window.currentJobCardId) {
        await saveJobCard();
        if (!window.currentJobCardId) {
            showNotification('Please save the job card first.', 'error');
            return;
        }
    }

    // Generate invoice from job card
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/generate-invoice`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                jobCardId: window.currentJobCardId,
                jobCardData: data
            })
        });

        if (response.ok) {
            const result = await response.json();

            // Store invoice data and redirect
            sessionStorage.setItem('currentJobCard', JSON.stringify(data));
            sessionStorage.setItem('invoiceData', JSON.stringify(result));

            // Redirect to invoice generator
            window.location.href = 'invoice-generator.html';
        } else {
            throw new Error('Failed to generate invoice');
        }
    } catch (error) {
        showNotification('Error generating invoice: ' + error.message, 'error');
    }
}

function showSuccessWidget(jobNumber) {
    // Remove existing widget
    const existing = document.querySelector('.modern-notification-widget');
    if (existing) {
        existing.remove();
    }

    // Create modern success widget
    const widget = document.createElement('div');
    widget.className = 'modern-notification-widget success';
    widget.innerHTML = `
        <div class="modern-widget-content">
            <div class="modern-widget-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="modern-widget-details">
                <h3>SUCCESS</h3>
                <p>Thank you for your request.</p>
                <p>We are working hard to find the best service and deals for you.</p>
                <p>Shortly you will find a confirmation in your email.</p>
                <div class="modern-widget-actions">
                    <button onclick="closeModernWidget()" class="modern-btn modern-btn-primary">
                        Continue
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(widget);

    // Auto-hide after 8 seconds
    setTimeout(() => {
        if (widget.parentNode) {
            closeModernWidget();
        }
    }, 8000);
}


function printJobCard(jobNumber) {
    // Implement print functionality
    window.print();
}

async function generateInvoiceFromSuccess(jobNumber) {
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/jobcards/${jobNumber}/invoice`);
        if (response.ok) {
            const result = await response.json();
            sessionStorage.setItem('invoiceData', JSON.stringify(result));
            window.location.href = 'invoice-generator.html';
        }
    } catch (error) {
        showNotification('Error generating invoice: ' + error.message, 'error');
    }
}

function closeModernWidget() {
    const widget = document.querySelector('.modern-notification-widget');
    if (widget) {
        widget.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (widget.parentNode) {
                widget.remove();
            }
        }, 300);
    }
}

function showNotification(message, type = 'info') {
    // Remove existing notification
    const existing = document.querySelector('.modern-notification-widget');
    if (existing) {
        existing.remove();
    }

    let title, icon, btnText;

    if (type === 'success') {
        title = 'SUCCESS';
        icon = 'fa-check-circle';
        btnText = 'Continue';
    } else if (type === 'error') {
        title = 'ERROR!';
        icon = 'fa-exclamation-circle';
        btnText = 'Try Again';
    } else {
        title = 'INFO';
        icon = 'fa-info-circle';
        btnText = 'OK';
    }

    // Create modern notification widget
    const widget = document.createElement('div');
    widget.className = `modern-notification-widget ${type}`;
    widget.innerHTML = `
        <div class="modern-widget-content">
            <div class="modern-widget-icon">
                <i class="fas ${icon}"></i>
            </div>
            <div class="modern-widget-details">
                <h3>${title}</h3>
                <p>${message}</p>
                <div class="modern-widget-actions">
                    <button onclick="closeModernWidget()" class="modern-btn modern-btn-primary">
                        ${btnText}
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(widget);

    // Auto-hide after 8 seconds for success/info, 10 seconds for error
    const autoHideTime = type === 'error' ? 10000 : 8000;
    setTimeout(() => {
        if (widget.parentNode) {
            closeModernWidget();
        }
    }, autoHideTime);
}

function updateSystemTime() {
    const now = new Date();

    const timeElement = document.getElementById('systemTime');
    if (timeElement) {
        timeElement.textContent = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    const dateElement = document.getElementById('systemDate');
    if (dateElement) {
        dateElement.textContent = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
}

async function updateStats() {
    try {
        const response = await fetch(`${Utils.getApiBaseUrl()}/api/stats/jobcards`);
        if (response.ok) {
            const stats = await response.json();

            const invoiceCount = document.getElementById('invoiceCount');
            const jobcardCount = document.getElementById('jobcardCount');

            if (invoiceCount) invoiceCount.textContent = stats.totalInvoices || '0';
            if (jobcardCount) jobcardCount.textContent = stats.totalJobCards || '0';
        }
    } catch (error) {
        console.log('Could not load stats:', error);
    }
}

// OpenStreetMap Nominatim Configuration
const OPENSTREETMAP_CONFIG = {
    baseUrl: 'https://nominatim.openstreetmap.org/search',
    format: 'json',
    limit: 10,
    // No API key needed for Nominatim (free tier)
    rateLimit: 1000, // 1 request per second max
    userAgent: 'AIEidLogistics/1.0 (your-email@domain.com)', // Required for Nominatim
    email: 'your-email@domain.com' // Optional but recommended
};

// Debounce function to prevent too many API calls
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
const PREDEFINED_LOCATIONS = [
    'Abdelli',
    'Nuwasib',
    'Shuwaikh Port, Kuwait',
    'Shuiba',
    'Doha KWT',
    'Kuwait Airport',
    'Salmi',
    'Jebel Ali Port, UAE',
    'Khalifa Port, UAE',
    'Hamad Port, Qatar',
    'King Abdulaziz Port, Saudi Arabia'
];

async function searchPlaces(query, type = '') {
    if (!query || query.length < 2) {
        // Return predefined locations when query is short
        return PREDEFINED_LOCATIONS
            .filter(loc => loc.toLowerCase().includes(query.toLowerCase()))
            .map(loc => ({ name: loc, type: 'predefined' }));
    }

    try {
        // Try OpenStreetMap first
        let searchQuery = query;
        if (type === 'airport') searchQuery += ' airport';
        else if (type === 'seaport') searchQuery += ' port';

        const params = new URLSearchParams({
            q: searchQuery,
            format: 'json',
            limit: 10,
            addressdetails: 1,
            'accept-language': 'en'
        });

        const response = await fetch(
            `https://nominatim.openstreetmap.org/search?${params.toString()}`,
            {
                headers: {
                    'User-Agent': 'AIEidLogistics/1.0',
                    'Accept': 'application/json'
                }
            }
        );

        if (!response.ok) throw new Error('API error');

        const data = await response.json();

        const results = data.map(place => {
            let name = place.address.suburb ||
                place.address.city ||
                place.address.town ||
                place.address.village ||
                place.name.split(',')[0];

            if (place.type === 'aerodrome' || place.type === 'aeroway') {
                name = name.replace('International Airport', '').trim();
            }
            if (place.type === 'port' || place.type === 'seaport') {
                name = name.replace('Port', '').trim();
            }

            return {
                name: name,
                type: place.type || place.class,
                lat: place.lat,
                lon: place.lon,
                country: place.address?.country || ''
            };
        });

        // Add predefined locations if not found in OSM
        const predefinedResults = PREDEFINED_LOCATIONS
            .filter(loc => loc.toLowerCase().includes(query.toLowerCase()))
            .filter(loc => !results.some(r => r.name.toLowerCase() === loc.toLowerCase()))
            .map(loc => ({ name: loc, type: 'predefined' }));

        return [...results, ...predefinedResults];

    } catch (error) {
        console.log('OpenStreetMap fallback, using predefined locations');
        return PREDEFINED_LOCATIONS
            .filter(loc => loc.toLowerCase().includes(query.toLowerCase()))
            .map(loc => ({ name: loc, type: 'predefined' }));
    }
}

// ============================================================
// GET LOOKUP ID HELPER
// ============================================================

function getLookupIdByCode(tableName, code) {
    if (!code || !lookupData[tableName]) return null;
    const item = lookupData[tableName].find(i => i.code === code);
    return item ? item.id : null;
}


// Create a custom autocomplete dropdown
function createCustomAutocomplete(inputElement, searchType = '') {
    let dropdown = null;
    let currentSuggestions = [];
    let selectedIndex = -1;

    // Remove existing dropdown
    function removeDropdown() {
        if (dropdown) {
            dropdown.remove();
            dropdown = null;
        }
    }

    // Show dropdown with suggestions
    function showDropdown(suggestions) {
        removeDropdown();

        if (!suggestions || suggestions.length === 0) return;

        dropdown = document.createElement('div');
        dropdown.className = 'custom-autocomplete-dropdown';
        dropdown.style.width = inputElement.offsetWidth + 'px';
        dropdown.style.position = 'absolute';
        dropdown.style.zIndex = '1000';
        dropdown.style.backgroundColor = 'white';
        dropdown.style.border = '1px solid #ddd';
        dropdown.style.borderRadius = '4px';
        dropdown.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        dropdown.style.maxHeight = '300px';
        dropdown.style.overflowY = 'auto';
        dropdown.style.marginTop = '2px';

        suggestions.forEach((place, index) => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.dataset.index = index;
            item.style.padding = '10px 15px';
            item.style.cursor = 'pointer';
            item.style.borderBottom = '1px solid #eee';
            item.style.transition = 'background-color 0.2s';

            // Truncate long place names
            let displayName = place.name;
            if (displayName.length > 100) {
                displayName = displayName.substring(0, 100) + '...';
            }

            item.innerHTML = `
                <div style="font-weight: 500; color: #333; margin-bottom: 4px;">${displayName}</div>
                <div style="font-size: 12px; color: #666;">
                    ${place.address && place.address.city ? place.address.city + ', ' : ''}
                    ${place.address && place.address.country ? place.address.country : ''}
                </div>
            `;

            item.addEventListener('click', () => {
                inputElement.value = place.name;
                inputElement.dataset.lat = place.lat;
                inputElement.dataset.lon = place.lon;
                removeDropdown();

                // Trigger change event
                inputElement.dispatchEvent(new Event('change', { bubbles: true }));
            });

            item.addEventListener('mouseenter', () => {
                highlightItem(index);
            });

            dropdown.appendChild(item);
        });

        // Position dropdown
        const rect = inputElement.getBoundingClientRect();
        dropdown.style.top = (rect.bottom + window.scrollY) + 'px';
        dropdown.style.left = (rect.left + window.scrollX) + 'px';

        document.body.appendChild(dropdown);

        // Close dropdown when clicking outside
        document.addEventListener('click', handleClickOutside);
    }

    // Highlight item
    function highlightItem(index) {
        const items = dropdown.querySelectorAll('.autocomplete-item');
        items.forEach((item, i) => {
            item.style.backgroundColor = i === index ? '#f0f7ff' : 'white';
        });
        selectedIndex = index;
    }

    // Handle click outside
    function handleClickOutside(e) {
        if (dropdown && !dropdown.contains(e.target) && e.target !== inputElement) {
            removeDropdown();
            document.removeEventListener('click', handleClickOutside);
        }
    }

    // Handle keyboard navigation
    function handleKeyDown(e) {
        if (!dropdown) return;

        const items = dropdown.querySelectorAll('.autocomplete-item');
        if (!items.length) return;

        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                selectedIndex = (selectedIndex + 1) % items.length;
                highlightItem(selectedIndex);
                items[selectedIndex].scrollIntoView({ block: 'nearest' });
                break;

            case 'ArrowUp':
                e.preventDefault();
                selectedIndex = (selectedIndex - 1 + items.length) % items.length;
                highlightItem(selectedIndex);
                items[selectedIndex].scrollIntoView({ block: 'nearest' });
                break;

            case 'Enter':
                if (selectedIndex >= 0) {
                    e.preventDefault();
                    items[selectedIndex].click();
                }
                break;

            case 'Escape':
                removeDropdown();
                break;
        }
    }

    // Search function with debounce
    const performSearch = debounce(async (query) => {
        const suggestions = await searchPlaces(query, searchType);
        currentSuggestions = suggestions;
        showDropdown(suggestions);
    }, 500); // 500ms debounce

    // Setup event listeners
    inputElement.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        selectedIndex = -1;

        if (query.length < 3) {
            removeDropdown();
            return;
        }

        performSearch(query);
    });

    inputElement.addEventListener('keydown', handleKeyDown);
    inputElement.addEventListener('focus', () => {
        if (inputElement.value.length >= 3) {
            performSearch(inputElement.value.trim());
        }
    });

    // Return cleanup function
    return () => {
        removeDropdown();
        inputElement.removeEventListener('keydown', handleKeyDown);
        document.removeEventListener('click', handleClickOutside);
    };
}

// Setup location fields based on mode
function setupLocationFields() {
    // This function is simplified since we're using pol/pod fields
    // which are already in the HTML
    const modeSelect = document.getElementById('transportMode');
    const polGroup = document.getElementById('pol')?.closest('.form-group');
    const podGroup = document.getElementById('pod')?.closest('.form-group');

    if (polGroup && podGroup) {
        // Both are always visible
        polGroup.style.display = 'block';
        podGroup.style.display = 'block';
    }
}

function addEnhancedStyles() {
    if (!document.querySelector('#enhanced-autocomplete-styles')) {
        const style = document.createElement('style');
        style.id = 'enhanced-autocomplete-styles';
        style.textContent = `
            /* GLOBAL CSS VARIABLES */
            :root {
                --bg-body: #f3f4f6;
                --bg-card: #ffffff;
                --bg-muted: #f9fafb;
                --primary: #2563eb;
                --primary-soft: rgba(37, 99, 235, 0.12);
                --primary-dark: #1d4ed8;
                --accent: #10b981;
                --accent-soft: rgba(16, 185, 129, 0.14);
                --border-subtle: #e5e7eb;
                --border-strong: #d1d5db;
                --text-main: #111827;
                --text-muted: #6b7280;
                --text-soft: #9ca3af;
                --radius-sm: 6px;
                --radius-md: 10px;
                --radius-lg: 14px;
                --shadow-soft: 0 8px 24px rgba(15, 23, 42, 0.08);
                --shadow-subtle: 0 4px 12px rgba(15, 23, 42, 0.06);
                --transition-fast: 0.18s ease-out;
                --transition-base: 0.24s ease;
            }
            
            /* Custom Autocomplete Styles */
            .custom-autocomplete-dropdown {
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
                max-height: 300px;
                overflow-y: auto;
                z-index: 9999;
                font-family: 'Inter', sans-serif;
            }
            
            .custom-autocomplete-dropdown .autocomplete-item {
                padding: 12px 16px;
                cursor: pointer;
                transition: background-color 0.2s;
                border-bottom: 1px solid #f3f4f6;
            }
            
            .custom-autocomplete-dropdown .autocomplete-item:last-child {
                border-bottom: none;
            }
            
            .custom-autocomplete-dropdown .autocomplete-item:hover {
                background-color: #f0f7ff;
            }
            
            /* Location input fields */
            .location-autocomplete-input {
                width: 100%;
                padding: 12px 15px;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Inter', sans-serif;
                transition: border-color 0.2s;
            }
            
            .location-autocomplete-input:focus {
                outline: none;
                border-color: #2563eb;
                box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            }
            
            /* CUSTOMER DROPDOWN SPECIFIC STYLES */
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item {
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                margin: 0;
                box-sizing: border-box;
                padding: 12px 15px;
                cursor: pointer;
                transition: all 0.2s;
                border-bottom: 1px solid var(--border-subtle);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted {
                background: var(--primary);
                color: white;
                border-bottom: none;
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item:hover {
                background: var(--primary-soft);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted:hover {
                background: var(--primary-dark);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item .item-main strong {
                color: var(--text-main);
                font-weight: 500;
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted .item-main strong {
                color: white;
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item .item-badge {
                background: var(--bg-muted);
                color: var(--text-muted);
                padding: 3px 10px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 500;
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted .item-badge {
                background: rgba(255, 255, 255, 0.25);
                color: rgba(255, 255, 255, 0.95);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item .item-details small {
                color: var(--text-muted);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted .item-details small {
                color: rgba(255, 255, 255, 0.85);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item .item-details i {
                color: var(--text-soft);
            }
            
            .autocomplete-dropdown.enhanced-dropdown .autocomplete-item.highlighted .item-details i {
                color: rgba(255, 255, 255, 0.8);
            }

            /* MODERN NOTIFICATION WIDGET STYLES */
            .modern-notification-widget {
                position: fixed;
                top: 20px;
                right: 20px;
                width: 380px;
                background: var(--bg-card);
                border-radius: var(--radius-lg);
                box-shadow: var(--shadow-soft);
                z-index: 9999;
                animation: slideInRight 0.4s ease;
                border-left: 5px solid transparent;
                overflow: hidden;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            }
            
            .modern-notification-widget.success {
                border-left-color: var(--accent);
                background: linear-gradient(to right, rgba(16, 185, 129, 0.05), var(--bg-card));
            }
            
            .modern-notification-widget.error {
                border-left-color: #ef4444;
                background: linear-gradient(to right, rgba(239, 68, 68, 0.05), var(--bg-card));
            }
            
            .modern-notification-widget.info {
                border-left-color: var(--primary);
                background: linear-gradient(to right, rgba(37, 99, 235, 0.05), var(--bg-card));
            }
            
            .modern-widget-content {
                padding: 25px;
                display: flex;
                gap: 20px;
                align-items: flex-start;
            }
            
            .modern-widget-icon {
                font-size: 36px;
                flex-shrink: 0;
                margin-top: 5px;
            }
            
            .modern-notification-widget.success .modern-widget-icon {
                color: var(--accent);
            }
            
            .modern-notification-widget.error .modern-widget-icon {
                color: #ef4444;
            }
            
            .modern-notification-widget.info .modern-widget-icon {
                color: var(--primary);
            }
            
            .modern-widget-details {
                flex: 1;
            }
            
            .modern-widget-details h3 {
                margin: 0 0 15px 0;
                font-size: 20px;
                font-weight: 700;
                color: var(--text-main);
            }
            
            .modern-notification-widget.success .modern-widget-details h3 {
                color: var(--accent);
            }
            
            .modern-notification-widget.error .modern-widget-details h3 {
                color: #ef4444;
            }
            
            .modern-notification-widget.info .modern-widget-details h3 {
                color: var(--primary);
            }
            
            .modern-widget-details p {
                margin: 0 0 10px 0;
                color: var(--text-muted);
                line-height: 1.5;
                font-size: 14px;
            }
            
            .modern-widget-details p:last-child {
                margin-bottom: 20px;
            }
            
            .modern-widget-actions {
                display: flex;
                gap: 12px;
                margin-top: 20px;
            }
            
            .modern-btn {
                padding: 10px 24px;
                border-radius: var(--radius-sm);
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                font-weight: 500;
                font-size: 14px;
                cursor: pointer;
                transition: var(--transition-fast);
                border: none;
                outline: none;
            }
            
            .modern-btn-primary {
                background: var(--primary);
                color: white;
            }
            
            .modern-btn-primary:hover {
                background: var(--primary-dark);
                transform: translateY(-1px);
            }
            
            .modern-btn-secondary {
                background: var(--bg-muted);
                color: var(--text-muted);
                border: 1px solid var(--border-subtle);
            }
            
            .modern-btn-secondary:hover {
                background: var(--border-subtle);
            }
            
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            /* Remove old notification styles */
            .notification,
            .success-widget {
                display: none !important;
            }
                        
            /* GENERAL DROPDOWN STYLES */
            .normal-dropdown {
                width: 100%;
                padding: 12px 15px;
                border: 1px solid var(--border-subtle);
                border-radius: var(--radius-sm);
                font-size: 14px;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                background-color: var(--bg-card);
                cursor: pointer;
                appearance: none;
                -webkit-appearance: none;
                -moz-appearance: none;
                background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-position: right 12px center;
                background-size: 16px;
                padding-right: 40px;
                color: var(--text-main);
                transition: var(--transition-fast);
                box-sizing: border-box;
            }
            
            .normal-dropdown:hover {
                border-color: var(--primary);
                box-shadow: var(--shadow-subtle);
            }
            
            .normal-dropdown:focus {
                border-color: var(--primary);
                outline: none;
                box-shadow: 0 0 0 3px var(--primary-soft);
            }
            
            .normal-dropdown option {
                padding: 10px 12px;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            }
            
            /* Autocomplete dropdown container */
            .autocomplete-dropdown.enhanced-dropdown {
                background: var(--bg-card);
                border: 1px solid var(--border-subtle);
                border-radius: var(--radius-md);
                box-shadow: var(--shadow-soft);
                max-height: 320px;
                overflow-y: auto;
                margin-top: 6px;
                padding: 0;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                animation: fadeInUp var(--transition-fast);
            }
            
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(-4px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .dropdown-search-header {
                padding: 12px;
                background: var(--bg-muted);
                border-bottom: 1px solid var(--border-subtle);
                position: sticky;
                top: 0;
                z-index: 10;
                border-radius: var(--radius-md) var(--radius-md) 0 0;
            }
            
            .dropdown-search-header input {
                width: 100%;
                padding: 10px 12px 10px 38px;
                border: 1px solid var(--border-subtle);
                border-radius: var(--radius-sm);
                font-size: 14px;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                background-color: var(--bg-card);
                color: var(--text-main);
                transition: var(--transition-fast);
                box-sizing: border-box;
            }
            
            .dropdown-search-header input:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 0 3px var(--primary-soft);
            }
            
            .dropdown-search-header i {
                position: absolute;
                left: 22px;
                top: 50%;
                transform: translateY(-50%);
                color: var(--text-muted);
                font-size: 14px;
            }
            
            /* Shipper dropdown specific styles */
            .shipper-dropdown .autocomplete-item {
                padding: 10px 15px;
                font-family: inherit;
            }
            
            .shipper-dropdown .autocomplete-item.highlighted {
                background: #007bff;
                color: white;
            }
            
            /* Requester dropdown specific styles */
            .autocomplete-dropdown.enhanced-dropdown:not(.shipper-dropdown):not(.port-dropdown):not(.cost-center-dropdown) .autocomplete-item.highlighted {
                background: #007bff;
                color: white;
            }
            
            .dropdown-region-header {
                padding: 10px 16px;
                background: var(--bg-muted);
                color: var(--text-muted);
                font-weight: 600;
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                border-bottom: 1px solid var(--border-subtle);
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            }
            
            .item-main {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 6px;
            }
            
            .item-details {
                display: flex;
                gap: 12px;
                font-size: 12px;
                flex-wrap: wrap;
            }
            
            /* Edit button for auto-filled fields */
            .edit-auto-filled {
                position: absolute;
                right: 10px;
                top: 50%;
                transform: translateY(-50%);
                background: var(--accent);
                color: white;
                border: none;
                border-radius: var(--radius-sm);
                padding: 6px 10px;
                font-size: 12px;
                cursor: pointer;
                transition: var(--transition-fast);
                z-index: 5;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                box-sizing: border-box;
            }
            
            .edit-auto-filled:hover {
                background: var(--accent-dark);
                transform: translateY(-50%) scale(1.05);
            }
            
            /* Form group needs relative positioning for edit button */
            .form-group {
                position: relative;
            }
            
            .auto-filled {
                background-color: var(--accent-soft);
                border-color: var(--accent) !important;
                padding-right: 48px !important;
            }
            
            /* Success widget */
            .success-widget {
                background: linear-gradient(135deg, var(--accent), #0da271);
                color: white;
                border-radius: var(--radius-lg);
                padding: 20px;
                margin-bottom: 25px;
                animation: slideInDown 0.5s ease;
                box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3);
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            }
            
            .success-content {
                display: flex;
                align-items: center;
                gap: 20px;
            }
            
            .success-icon {
                font-size: 48px;
                opacity: 0.9;
            }
            
            .success-details h4 {
                margin: 0 0 8px 0;
                font-size: 18px;
                font-weight: 600;
            }
            
            .success-details p {
                margin: 0 0 15px 0;
                opacity: 0.9;
                font-size: 14px;
            }
            
            .success-actions {
                display: flex;
                gap: 10px;
            }
            
            /* Notification styling */
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 16px 24px;
                border-radius: var(--radius-md);
                display: flex;
                align-items: center;
                gap: 12px;
                box-shadow: var(--shadow-soft);
                z-index: 9999;
                animation: slideIn var(--transition-base);
                font-weight: 500;
                font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            }
            
            .notification-success {
                background: var(--accent);
                color: white;
            }
            
            .notification-error {
                background: #ef4444;
                color: white;
            }
            
            .notification-info {
                background: var(--primary);
                color: white;
            }
            
            /* Animations */
            @keyframes slideInDown {
                from {
                    transform: translateY(-20px);
                    opacity: 0;
                }
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            /* Scrollbar styling for dropdown */
            .autocomplete-dropdown.enhanced-dropdown::-webkit-scrollbar,
            .custom-autocomplete-dropdown::-webkit-scrollbar {
                width: 6px;
            }
            
            .autocomplete-dropdown.enhanced-dropdown::-webkit-scrollbar-track,
            .custom-autocomplete-dropdown::-webkit-scrollbar-track {
                background: var(--bg-muted);
                border-radius: 3px;
            }
            
            .autocomplete-dropdown.enhanced-dropdown::-webkit-scrollbar-thumb,
            .custom-autocomplete-dropdown::-webkit-scrollbar-thumb {
                background: var(--border-strong);
                border-radius: 3px;
            }
            
            .autocomplete-dropdown.enhanced-dropdown::-webkit-scrollbar-thumb:hover,
            .custom-autocomplete-dropdown::-webkit-scrollbar-thumb:hover {
                background: var(--text-muted);
            }
            
            /* Ensure proper font loading */
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        `;
        document.head.appendChild(style);
    }
}


// ==============================================================
// JOB CARD 3 REDESIGN: NEW FUNCTIONS
// ==============================================================

// 1. Date Calculations
window.calculateTransitTime = function () {
    const atdInput = document.getElementById('atd');
    const ataInput = document.getElementById('ata');
    const transitTimeInput = document.getElementById('transitTime');

    if (atdInput && ataInput && atdInput.value && ataInput.value && transitTimeInput) {
        const atd = new Date(atdInput.value);
        const ata = new Date(ataInput.value);
        const diffTime = Math.abs(ata - atd);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        transitTimeInput.value = diffDays + " Day(s)";
    }
};

window.calculateDepositDates = function () {
    const declarationDateInput = document.getElementById('declarationDate');
    const depositRefundLastDate = document.getElementById('depositRefundLastDate');
    const teBayanExpiryDate = document.getElementById('teBayanExpiryDate');

    if (declarationDateInput && declarationDateInput.value) {
        const declDate = new Date(declarationDateInput.value);

        // Deposit Refund Last Date: +90 days
        if (depositRefundLastDate) {
            const refundDate = new Date(declDate);
            refundDate.setDate(refundDate.getDate() + 90);
            depositRefundLastDate.value = refundDate.toISOString().split('T')[0];
        }

        // Temporary Export Bayan Expiry Date: +364 days
        if (teBayanExpiryDate) {
            const expiryDate = new Date(declDate);
            expiryDate.setDate(expiryDate.getDate() + 364);
            teBayanExpiryDate.value = expiryDate.toISOString().split('T')[0];
        }
    }
};

// 2. Conditional Visibility
window.handleCCRegimeChange = function () {
    const ccRegime = document.getElementById('ccRegime').value;
    const blockTemporaryImport = document.getElementById('blockTemporaryImport');
    const blockTemporaryExport = document.getElementById('blockTemporaryExport');

    if (blockTemporaryImport) blockTemporaryImport.style.display = 'none';
    if (blockTemporaryExport) blockTemporaryExport.style.display = 'none';

    if (ccRegime === 'TEMPORARY IMPORT' && blockTemporaryImport) {
        blockTemporaryImport.style.display = 'block';
    } else if (ccRegime === 'TEMPORARY EXPORT' && blockTemporaryExport) {
        blockTemporaryExport.style.display = 'block';
    }
};

window.handlePartialReExport = function () {
    const partialReExport = document.getElementById('partialReExport').value;
    const group = document.getElementById('partialReExportPnGroup');
    if (group) {
        group.style.display = (partialReExport === 'YES') ? 'block' : 'none';
    }
};

// 3. Multi-select Toggle
window.toggleMultiSelect = function (dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (dropdown) {
        dropdown.classList.toggle('active');
    }
};

// Update text when checkboxes change
document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('ministryDropdown');
    const textSpan = document.getElementById('ministrySelectedText');
    if (container && textSpan) {
        container.addEventListener('change', () => {
            const checked = Array.from(container.querySelectorAll('input[type="checkbox"]:checked'))
                .map(cb => cb.value);
            if (checked.length === 0) {
                textSpan.textContent = "Select Approvals...";
            } else if (checked.length <= 2) {
                textSpan.textContent = checked.join(', ');
            } else {
                textSpan.textContent = checked.length + " Approvals Selected";
            }
        });
    }

    // Smart Search mock logic for general items
    const smartSearchInputs = document.querySelectorAll('.smart-search');
    smartSearchInputs.forEach(input => {
        const dropdown = input.nextElementSibling;
        if (!dropdown || !dropdown.classList.contains('search-dropdown')) return;

        input.addEventListener('focus', () => {
            dropdown.innerHTML = `<div class="search-item">Type to search...</div>`;
            dropdown.classList.add('active');
        });

        input.addEventListener('input', (e) => {
            const val = e.target.value;
            if (val.length < 2) {
                dropdown.innerHTML = `<div class="search-item">Type to search...</div>`;
                return;
            }
            // Mock Results
            dropdown.innerHTML = `
                <div class="search-item" onclick="selectSmartSearch('${input.id}', '${val} (Option A)')">${val} (Option A)</div>
                <div class="search-item" onclick="selectSmartSearch('${input.id}', '${val} (Option B)')">${val} (Option B)</div>
                <div class="search-item create-new" onclick="selectSmartSearch('${input.id}', '${val}')"><i class="fas fa-plus-circle"></i> Create New: ${val}</div>
            `;
        });

        // Hide dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target !== input && !dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    });


});

window.selectSmartSearch = function (inputId, text) {
    const input = document.getElementById(inputId);
    if (input) {
        input.value = text;
        const dropdown = input.nextElementSibling;
        if (dropdown) dropdown.classList.remove('active');
        // Trigger change event
        input.dispatchEvent(new Event('change'));
    }
};


