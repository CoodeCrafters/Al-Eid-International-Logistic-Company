// ============================================
// ENTITY MANAGEMENT - Unified CRUD Operations
// Supports: Customers, Shippers, Consignees, Agents, Drivers, Contacts
// ============================================

let entities = [];
let currentView = 'card';
let currentEntityType = 'customers';

// Entity type configurations
const ENTITY_CONFIGS = {
    customers: {
    label: 'Customer',
    icon: 'fa-users',
    apiEndpoint: '/api/customers',
    searchFields: ['name', 'email', 'phone', 'reference_number', 'address'],
    displayFields: ['name', 'email', 'phone', 'reference_number', 'address'],
    formFields: [
        { id: 'name', label: 'Full Name / Company Name', type: 'text', required: true, placeholder: 'Enter customer name' },
        { id: 'phone', label: 'Phone Number', type: 'text', required: true, placeholder: 'Enter phone number' },
        { id: 'email', label: 'Email Address', type: 'email', required: true, placeholder: 'Enter email address' },
        { id: 'reference_number', label: 'Customer Ref / PO Internal Number', type: 'text', required: true, placeholder: 'e.g. CUST-1001' },
        // ✅ ADD ADDRESS FIELD HERE
        { id: 'address', label: 'Address', type: 'textarea', required: false, placeholder: 'Enter customer address' }
    ],
    cardTemplate: (item) => `
        <div class="customer-header">
            <div class="customer-avatar">${getInitials(item.name)}</div>
            <div class="customer-info-top">
                <h3 class="customer-name">${item.name}</h3>
                <span class="customer-ref">${item.reference_number || 'No Ref'}</span>
            </div>
            <div class="customer-actions">
                <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
            </div>
        </div>
        <div class="customer-details">
            <div class="detail-row">
                <div class="detail-icon"><i class="fas fa-phone"></i></div>
                <div class="detail-value">${item.phone || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                <div class="detail-value">${item.email || 'N/A'}</div>
            </div>
            ${item.address ? `
            <div class="detail-row">
                <div class="detail-icon"><i class="fas fa-map-marker-alt"></i></div>
                <div class="detail-value">${item.address}</div>
            </div>` : ''}
        </div>
    `,
    tableRow: (item) => `
        <td>
            <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
            <div style="font-size: 12px; color: #7f8c8d;">Ref: ${item.reference_number || 'N/A'}</div>
            ${item.address ? `<div style="font-size: 11px; color: #6b7280;"><i class="fas fa-map-marker-alt" style="width:14px;"></i> ${item.address}</div>` : ''}
        </td>
        <td>
            <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
            <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
        </td>
        <td>${item.reference_number || 'N/A'}</td>
        <td>
            <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
            <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
            <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
        </td>
    `,
    details: (item) => `
        <div style="margin-bottom: 10px;">
            <strong>Reference Number:</strong> ${item.reference_number || 'N/A'}<br>
            <strong>Phone:</strong> ${item.phone || 'N/A'}<br>
            <strong>Email:</strong> ${item.email || 'N/A'}<br>
            <strong>Address:</strong> ${item.address || 'N/A'}
        </div>
    `
},
    
    shippers: {
        label: 'Shipper',
        icon: 'fa-truck',
        apiEndpoint: '/api/shippers',
        searchFields: ['name', 'email', 'phone', 'reference_number', 'company'],
        displayFields: ['name', 'company', 'email', 'phone', 'reference_number'],
        formFields: [
            { id: 'name', label: 'Shipper Name', type: 'text', required: true, placeholder: 'Enter shipper name' },
            { id: 'reference_number', label: 'Shipper Reference Number', type: 'text', required: true, placeholder: 'e.g. SHIP-1001' },
            { id: 'phone', label: 'Mobile Number', type: 'text', required: false, placeholder: 'Enter mobile number (optional)' },
            { id: 'email', label: 'Email Address', type: 'email', required: false, placeholder: 'Enter email (optional)' },
            { id: 'company', label: 'Company Name', type: 'text', required: false, placeholder: 'Enter company name (optional)' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.reference_number || 'No Ref'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-building"></i></div>
                    <div class="detail-value">${item.company || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">${item.company || 'No Company'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>${item.reference_number || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Company:</strong> ${item.company || 'N/A'}<br>
                <strong>Reference Number:</strong> ${item.reference_number || 'N/A'}
            </div>
        `
    },
    
    consignees: {
        label: 'Consignee',
        icon: 'fa-user-check',
        apiEndpoint: '/api/consignees',
        searchFields: ['name', 'email', 'phone', 'reference_number'],
        displayFields: ['name', 'email', 'phone', 'reference_number'],
        formFields: [
            { id: 'name', label: 'Consignee Name', type: 'text', required: true, placeholder: 'Enter consignee name' },
            { id: 'phone', label: 'Mobile Number', type: 'text', required: true, placeholder: 'Enter mobile number' },
            { id: 'email', label: 'Email Address', type: 'email', required: true, placeholder: 'Enter email address' },
            { id: 'reference_number', label: 'Reference Number', type: 'text', required: false, placeholder: 'Enter reference (optional)' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.reference_number || 'No Ref'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Ref: ${item.reference_number || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>${item.reference_number || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Reference Number:</strong> ${item.reference_number || 'N/A'}
            </div>
        `
    },
    
    agents: {
        label: 'Agent',
        icon: 'fa-handshake',
        apiEndpoint: '/api/agents',
        searchFields: ['name', 'phone', 'email'],
        displayFields: ['name', 'phone', 'email'],
        formFields: [
            { id: 'name', label: 'Agent Name', type: 'text', required: true, placeholder: 'Enter agent name' },
            { id: 'phone', label: 'Phone Number', type: 'text', required: true, placeholder: 'Enter phone number' },
            { id: 'email', label: 'Email Address', type: 'email', required: false, placeholder: 'Enter email (optional)' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">Agent</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Agent</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>N/A</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Phone:</strong> ${item.phone || 'N/A'}<br>
                <strong>Email:</strong> ${item.email || 'N/A'}
            </div>
        `
    },
    
    drivers: {
        label: 'Driver',
        icon: 'fa-user',
        apiEndpoint: '/api/drivers',
        searchFields: ['name', 'phone', 'email', 'license_number'],
        displayFields: ['name', 'phone', 'email', 'license_number'],
        formFields: [
            { id: 'name', label: 'Driver Name', type: 'text', required: true, placeholder: 'Enter driver name' },
            { id: 'phone', label: 'Mobile Number', type: 'text', required: true, placeholder: 'Enter mobile number' },
            { id: 'email', label: 'Email Address', type: 'email', required: false, placeholder: 'Enter email (optional)' },
            { id: 'license_number', label: 'License Number', type: 'text', required: false, placeholder: 'Enter license number (optional)' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.license_number || 'No License'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">License: ${item.license_number || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>${item.license_number || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Phone:</strong> ${item.phone || 'N/A'}<br>
                <strong>Email:</strong> ${item.email || 'N/A'}<br>
                <strong>License Number:</strong> ${item.license_number || 'N/A'}
            </div>
        `
    },
    
    responsible_persons: {
        label: 'Responsible Person',
        icon: 'fa-user-tie',
        apiEndpoint: '/api/responsible-persons',
        searchFields: ['name', 'code', 'email', 'phone', 'department'],
        displayFields: ['name', 'code', 'email', 'phone', 'department'],
        formFields: [
            { id: 'name', label: 'Full Name', type: 'text', required: true, placeholder: 'e.g. Ahmed Ali' },
            { id: 'code', label: 'Code (auto-generated if blank)', type: 'text', required: false, placeholder: 'e.g. RP_001' },
            { id: 'department', label: 'Department', type: 'text', required: false, placeholder: 'e.g. Operations' },
            { id: 'phone', label: 'Phone Number', type: 'text', required: false, placeholder: 'e.g. +965 12345678' },
            { id: 'email', label: 'Email Address', type: 'email', required: false, placeholder: 'e.g. ahmed@aleid.com' },
            { id: 'sort_order', label: 'Sort Order (optional)', type: 'number', required: false, placeholder: '0' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.code || 'No Code'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Deactivate" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-building"></i></div>
                    <div class="detail-value">${item.department || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-circle" style="color:${item.is_active ? '#16a34a' : '#dc2626'}; font-size:10px;"></i></div>
                    <div class="detail-value" style="color:${item.is_active ? '#16a34a' : '#dc2626'};">${item.is_active ? 'Active' : 'Inactive'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Code: ${item.code || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>${item.department || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Code:</strong> ${item.code || 'N/A'}<br>
                <strong>Department:</strong> ${item.department || 'N/A'}<br>
                <strong>Phone:</strong> ${item.phone || 'N/A'}<br>
                <strong>Email:</strong> ${item.email || 'N/A'}<br>
                <strong>Status:</strong> <span style="color:${item.is_active ? '#16a34a' : '#dc2626'};">${item.is_active ? 'Active' : 'Inactive'}</span><br>
                <strong>Sort Order:</strong> ${item.sort_order ?? 0}
            </div>
        `
    },

    contacts: {
        label: 'Contact Person',
        icon: 'fa-address-book',
        apiEndpoint: '/api/contact_persons',
        searchFields: ['name', 'email', 'phone', 'reference_number', 'company'],
        displayFields: ['name', 'email', 'phone', 'reference_number', 'company'],
        formFields: [
            { id: 'name', label: 'Contact Person Name', type: 'text', required: true, placeholder: 'Enter contact name' },
            { id: 'reference_number', label: 'Reference Number', type: 'text', required: false, placeholder: 'Enter reference (optional)' },
            { id: 'phone', label: 'Mobile Number', type: 'text', required: true, placeholder: 'Enter mobile number' },
            { id: 'email', label: 'Email Address', type: 'email', required: true, placeholder: 'Enter email address' },
            { id: 'company', label: 'Company Name', type: 'text', required: false, placeholder: 'Enter company (optional)' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(item.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.reference_number || 'No Ref'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-building"></i></div>
                    <div class="detail-value">${item.company || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${item.phone || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${item.email || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">${item.company || 'No Company'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
            </td>
            <td>${item.reference_number || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Company:</strong> ${item.company || 'N/A'}<br>
                <strong>Reference Number:</strong> ${item.reference_number || 'N/A'}
            </div>
        `
    },

    // Add this to the ENTITY_CONFIGS object in customers.js

        transporters: {
            label: 'Transporter',
            icon: 'fa-truck',
            apiEndpoint: '/api/transporters',
            searchFields: ['name', 'code', 'phone', 'email', 'contact_person'],
            displayFields: ['name', 'code', 'phone', 'email', 'contact_person', 'country'],
            formFields: [
                { id: 'name', label: 'Transporter Name', type: 'text', required: true, placeholder: 'e.g. Gulf Transport Co.' },
                { id: 'code', label: 'Code', type: 'text', required: false, placeholder: 'e.g. GTC001' },
                { id: 'phone', label: 'Phone Number', type: 'text', required: false, placeholder: 'e.g. +965 12345678' },
                { id: 'email', label: 'Email Address', type: 'email', required: false, placeholder: 'e.g. info@gulftransport.com' },
                { id: 'contact_person', label: 'Contact Person', type: 'text', required: false, placeholder: 'e.g. Ahmed Mohammed' },
                { id: 'address', label: 'Address', type: 'textarea', required: false, placeholder: 'e.g. Office 10, M Floor, Tala Mall...' },
                { id: 'country', label: 'Country', type: 'text', required: false, placeholder: 'e.g. Kuwait' }
            ],
            cardTemplate: (item) => `
                <div class="customer-header">
                    <div class="customer-avatar" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9);">
                        <i class="fas fa-truck" style="color: white; font-size: 20px;"></i>
                    </div>
                    <div class="customer-info-top">
                        <h3 class="customer-name">${item.name}</h3>
                        <span class="customer-ref">${item.code || 'No Code'}</span>
                    </div>
                    <div class="customer-actions">
                        <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                        <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <div class="customer-details">
                    ${item.contact_person ? `
                    <div class="detail-row">
                        <div class="detail-icon"><i class="fas fa-user"></i></div>
                        <div class="detail-value">${item.contact_person}</div>
                    </div>` : ''}
                    <div class="detail-row">
                        <div class="detail-icon"><i class="fas fa-phone"></i></div>
                        <div class="detail-value">${item.phone || 'N/A'}</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                        <div class="detail-value">${item.email || 'N/A'}</div>
                    </div>
                    ${item.country ? `
                    <div class="detail-row">
                        <div class="detail-icon"><i class="fas fa-globe"></i></div>
                        <div class="detail-value">${item.country}</div>
                    </div>` : ''}
                </div>
            `,
            tableRow: (item) => `
                <td>
                    <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                    <div style="font-size: 12px; color: #7f8c8d;">Code: ${item.code || 'N/A'}</div>
                    ${item.contact_person ? `<div style="font-size: 11px; color: #6b7280;"><i class="fas fa-user" style="width:14px;"></i> ${item.contact_person}</div>` : ''}
                </td>
                <td>
                    <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${item.phone || 'N/A'}</div>
                    <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${item.email || 'N/A'}</div>
                </td>
                <td>${item.country || 'N/A'}</td>
                <td>
                    <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                    <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
                </td>
            `,
            details: (item) => `
                <div style="margin-bottom: 10px;">
                    <strong>Code:</strong> ${item.code || 'N/A'}<br>
                    <strong>Contact Person:</strong> ${item.contact_person || 'N/A'}<br>
                    <strong>Phone:</strong> ${item.phone || 'N/A'}<br>
                    <strong>Email:</strong> ${item.email || 'N/A'}<br>
                    <strong>Address:</strong> ${item.address || 'N/A'}<br>
                    <strong>Country:</strong> ${item.country || 'N/A'}<br>
                    <strong>Status:</strong> <span style="color:${item.is_active !== false ? '#16a34a' : '#dc2626'};">${item.is_active !== false ? 'Active' : 'Inactive'}</span>
                </div>
            `
        },

    // Add these to the ENTITY_CONFIGS object in customers.js

    shipping_lines: {
        label: 'Shipping Line',
        icon: 'fa-ship',
        apiEndpoint: '/api/shipping-lines',
        searchFields: ['name', 'code', 'country', 'type'],
        displayFields: ['name', 'code', 'type', 'country'],
        formFields: [
            { id: 'name', label: 'Shipping Line Name', type: 'text', required: true, placeholder: 'e.g. Maersk Line' },
            { id: 'code', label: 'Code', type: 'text', required: false, placeholder: 'e.g. MAERSK' },
            { id: 'type', label: 'Type', type: 'select', required: true, options: ['shipping', 'airline'] },
            { id: 'country', label: 'Country', type: 'text', required: false, placeholder: 'e.g. Denmark' }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar" style="background: linear-gradient(135deg, #1a73e8, #0d47a1);">
                    <i class="fas ${item.type === 'airline' ? 'fa-plane' : 'fa-ship'}" style="color: white; font-size: 20px;"></i>
                </div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.code || 'No Code'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-tag"></i></div>
                    <div class="detail-value">${item.type || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-globe"></i></div>
                    <div class="detail-value">${item.country || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Code: ${item.code || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;">
                    <i class="fas ${item.type === 'airline' ? 'fa-plane' : 'fa-ship'}" style="color: #bdc3c7; width: 16px;"></i> 
                    ${item.type || 'N/A'}
                </div>
                <div><i class="fas fa-globe" style="color: #bdc3c7; width: 16px;"></i> ${item.country || 'N/A'}</div>
            </td>
            <td>${item.type || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Code:</strong> ${item.code || 'N/A'}<br>
                <strong>Type:</strong> ${item.type || 'N/A'}<br>
                <strong>Country:</strong> ${item.country || 'N/A'}<br>
                <strong>Status:</strong> <span style="color:${item.is_active ? '#16a34a' : '#dc2626'};">${item.is_active ? 'Active' : 'Inactive'}</span>
            </div>
        `
    },

    ports: {
        label: 'Port',
        icon: 'fa-anchor',
        apiEndpoint: '/api/ports',
        searchFields: ['name', 'code', 'country', 'city', 'type'],
        displayFields: ['name', 'code', 'country', 'city', 'type'],
        formFields: [
            { id: 'name', label: 'Port Name', type: 'text', required: true, placeholder: 'e.g. Jebel Ali Port' },
            { id: 'code', label: 'Port Code', type: 'text', required: false, placeholder: 'e.g. JEA' },
            { id: 'country', label: 'Country', type: 'text', required: false, placeholder: 'e.g. UAE' },
            { id: 'city', label: 'City', type: 'text', required: false, placeholder: 'e.g. Dubai' },
            { id: 'type', label: 'Port Type', type: 'select', required: true, options: ['seaport', 'airport', 'inland'] }
        ],
        cardTemplate: (item) => `
            <div class="customer-header">
                <div class="customer-avatar" style="background: linear-gradient(135deg, #0d9488, #0f766e);">
                    <i class="fas ${item.type === 'airport' ? 'fa-plane-departure' : item.type === 'inland' ? 'fa-truck' : 'fa-anchor'}" style="color: white; font-size: 20px;"></i>
                </div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${item.name}</h3>
                    <span class="customer-ref">${item.code || 'No Code'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                    <button class="action-btn" title="Delete" onclick="deleteEntity('${item.id}')" style="color: #e74c3c;"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <div class="detail-value">${item.city || 'N/A'}, ${item.country || 'N/A'}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-tag"></i></div>
                    <div class="detail-value">${item.type || 'N/A'}</div>
                </div>
            </div>
        `,
        tableRow: (item) => `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${item.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Code: ${item.code || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-map-marker-alt" style="color: #bdc3c7; width: 16px;"></i> ${item.city || 'N/A'}</div>
                <div><i class="fas fa-globe" style="color: #bdc3c7; width: 16px;"></i> ${item.country || 'N/A'}</div>
            </td>
            <td>${item.type || 'N/A'}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal('${item.id}')">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditEntityModal('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px; color: #e74c3c; border-color: #fbdada; background: #fff0f0;" onclick="deleteEntity('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `,
        details: (item) => `
            <div style="margin-bottom: 10px;">
                <strong>Code:</strong> ${item.code || 'N/A'}<br>
                <strong>City:</strong> ${item.city || 'N/A'}<br>
                <strong>Country:</strong> ${item.country || 'N/A'}<br>
                <strong>Type:</strong> ${item.type || 'N/A'}<br>
                <strong>Status:</strong> <span style="color:${item.is_active ? '#16a34a' : '#dc2626'};">${item.is_active ? 'Active' : 'Inactive'}</span>
            </div>
        `
    }
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    // Set up view toggles
    const viewBtns = document.querySelectorAll('.view-btn');
    viewBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const view = btn.dataset.view;
            switchView(view);
            viewBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // Fetch Initial Data
    fetchEntities();

    // Setup Search Enter Key
    const searchInput = document.getElementById('entitySearch');
    if (searchInput) {
        searchInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });

        searchInput.addEventListener('input', function (e) {
            if (e.target.value.trim() === '') {
                renderEntities(entities);
            }
        });
    }
});

// ============================================
// ENTITY TYPE SWITCHING
// ============================================

function switchEntityType() {
    const select = document.getElementById('entityType');
    if (!select) return;
    
    currentEntityType = select.value;
    const config = ENTITY_CONFIGS[currentEntityType];
    
    // Update UI text
    document.getElementById('entityTypeTitle').textContent = config.label;
    document.getElementById('entityTypeSubtitle').textContent = config.label.toLowerCase();
    document.getElementById('addEntityBtnText').textContent = config.label;
    document.getElementById('formEntityType').textContent = config.label;
    
    // Update table header
    const headerName = document.getElementById('tableHeaderName');
    const headerRef = document.getElementById('tableHeaderRef');
    
    if (headerName) {
        headerName.textContent = config.label + ' Info';
    }
    
    if (headerRef) {
        if (config.label === 'Agent') {
            headerRef.textContent = 'Role';
        } else if (config.label === 'Responsible Person') {
            headerRef.textContent = 'Department';
        } else if (config.label === 'Driver') {
            headerRef.textContent = 'License No.';
        } else if (config.label === 'Shipping Line') {
            headerRef.textContent = 'Type';
        } else if (config.label === 'Port') {
            headerRef.textContent = 'Type';
        } else {
            headerRef.textContent = 'Reference';
        }
    }
    
    // Fetch data for new entity type
    fetchEntities();
}



// ============================================
// FETCH ENTITIES
// ============================================

async function fetchEntities() {
    try {
        const config = ENTITY_CONFIGS[currentEntityType];
        const response = await fetch(`${Utils.getApiBaseUrl()}${config.apiEndpoint}`);
        
        if (!response.ok) throw new Error(`Failed to fetch ${config.label}s`);
        
        const data = await response.json();
        
        if (data.success) {
            entities = data.data || [];
            renderEntities(entities);
        } else {
            console.error('API Error:', data.message);
            renderEntities([]);
        }
    } catch (error) {
        console.error(`Error fetching ${currentEntityType}:`, error);
        renderEntities([]);
    }
}

// ============================================
// RENDER FUNCTIONS
// ============================================

function switchView(view) {
    currentView = view;
    const cardView = document.getElementById('entitiesCardView');
    const tableView = document.getElementById('entitiesTableView');

    if (view === 'card') {
        cardView.style.display = 'grid';
        tableView.style.display = 'none';
    } else {
        cardView.style.display = 'none';
        tableView.style.display = 'block';
    }
}

function renderEntities(data) {
    renderCardView(data);
    renderTableView(data);
}

function getInitials(name) {
    if (!name) return 'NA';
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}

function renderCardView(data) {
    const container = document.getElementById('entitiesCardView');
    if (!container) return;

    container.innerHTML = '';

    if (data.length === 0) {
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #7f8c8d;">No ' + ENTITY_CONFIGS[currentEntityType].label.toLowerCase() + 's found.</div>';
        return;
    }

    data.forEach(item => {
        const config = ENTITY_CONFIGS[currentEntityType];
        const card = document.createElement('div');
        card.className = 'customer-card';
        card.onclick = (e) => {
            if (!e.target.closest('.customer-actions')) {
                openDetailsModal(item.id);
            }
        };

        card.innerHTML = config.cardTemplate(item);
        container.appendChild(card);
    });
}

function renderTableView(data) {
    const tbody = document.getElementById('entitiesTableBody');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #7f8c8d;">No ' + ENTITY_CONFIGS[currentEntityType].label.toLowerCase() + 's found.</td></tr>';
        return;
    }

    data.forEach(item => {
        const config = ENTITY_CONFIGS[currentEntityType];
        const tr = document.createElement('tr');
        tr.innerHTML = config.tableRow(item);
        tbody.appendChild(tr);
    });
}

// ============================================
// SEARCH
// ============================================

function performSearch() {
    const searchInput = document.getElementById('entitySearch');
    if (!searchInput) return;

    const query = searchInput.value.toLowerCase();
    const loader = document.getElementById('searchLoader');

    if (loader) loader.classList.add('active');

    setTimeout(() => {
        const config = ENTITY_CONFIGS[currentEntityType];
        const filtered = entities.filter(item => {
            return config.searchFields.some(field => {
                return item[field] && item[field].toString().toLowerCase().includes(query);
            });
        });

        renderEntities(filtered);

        if (loader) loader.classList.remove('active');
    }, 600);
}

// ============================================
// MODAL FUNCTIONS
// ============================================

function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add('active');
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove('active');
}

// ============================================
// OPEN ADD/EDIT MODAL
// ============================================

function openAddEntityModal() {
    const config = ENTITY_CONFIGS[currentEntityType];
    document.getElementById('formModalTitle').innerHTML = `
        <span class="modal-title-icon"><i class="fas fa-plus"></i></span>
        Add New <span id="formEntityType">${config.label}</span>`;
    document.getElementById('entityForm').reset();
    document.getElementById('entityId').value = '';
    document.getElementById('entityTypeField').value = currentEntityType;
    renderFormFields();
    openModal('entityFormModal');
}

function openEditEntityModal(id) {
    const item = entities.find(e => e.id === id);
    if (!item) return;
    const config = ENTITY_CONFIGS[currentEntityType];
    document.getElementById('formModalTitle').innerHTML = `
        <span class="modal-title-icon"><i class="fas fa-edit"></i></span>
        Edit <span id="formEntityType">${config.label}</span>`;
    document.getElementById('entityId').value = item.id;
    document.getElementById('entityTypeField').value = currentEntityType;
    renderFormFields(item);
    openModal('entityFormModal');
}

// ============================================
// RENDER DYNAMIC FORM FIELDS
// ============================================

function renderFormFields(item = null) {
    const container = document.getElementById('formFieldsContainer');
    const config = ENTITY_CONFIGS[currentEntityType];

    const iconMap = {
        name: 'fa-user', code: 'fa-hashtag', email: 'fa-envelope',
        phone: 'fa-phone', department: 'fa-building', sort_order: 'fa-sort-numeric-up',
        reference_number: 'fa-barcode', company: 'fa-building', address: 'fa-map-marker-alt',
        license_number: 'fa-id-card', country: 'fa-globe', city: 'fa-city',
        type: 'fa-tag'
    };

    let html = '';

    config.formFields.forEach(field => {
        const value = item ? (item[field.id] !== undefined && item[field.id] !== null ? item[field.id] : '') : '';
        const requiredAttr = field.required ? 'required' : '';
        const requiredBadge = field.required
            ? `<span class="modal-required-badge">Required</span>` : '';
        const icon = iconMap[field.id] || 'fa-pen';

        let inputEl;
        
        if (field.type === 'select') {
            // Render select dropdown
            const options = field.options.map(opt => 
                `<option value="${opt}" ${value === opt ? 'selected' : ''}>${opt.charAt(0).toUpperCase() + opt.slice(1)}</option>`
            ).join('');
            
            inputEl = `
                <div class="modal-input-wrap">
                    <i class="fas ${icon} input-icon"></i>
                    <select id="field_${field.id}" name="${field.id}" class="modal-input" ${requiredAttr}>
                        <option value="">Select ${field.label}...</option>
                        ${options}
                    </select>
                </div>
            `;
        } else if (field.type === 'textarea') {
            inputEl = `
                <div class="modal-input-wrap textarea-wrap">
                    <i class="fas ${icon} input-icon"></i>
                    <textarea id="field_${field.id}" name="${field.id}"
                        class="modal-textarea" placeholder="${field.placeholder}"
                        ${requiredAttr}>${value}</textarea>
                </div>
            `;
        } else {
            inputEl = `
                <div class="modal-input-wrap">
                    <i class="fas ${icon} input-icon"></i>
                    <input type="${field.type}" id="field_${field.id}" name="${field.id}"
                        class="modal-input" placeholder="${field.placeholder}"
                        ${requiredAttr} value="${value}" />
                </div>
            `;
        }

        html += `
            <div class="modal-field-row">
                <label class="modal-field-label" for="field_${field.id}">
                    <i class="fas ${icon}"></i>
                    ${field.label}
                    ${requiredBadge}
                </label>
                ${inputEl}
            </div>`;
    });

    container.innerHTML = html;
}

// ============================================
// SAVE ENTITY
// ============================================

async function saveEntity() {
    const id = document.getElementById('entityId').value;
    const entityType = document.getElementById('entityTypeField').value;
    const config = ENTITY_CONFIGS[entityType];
    
    // Build payload from form fields
    const payload = {};
    let isValid = true;
    
    config.formFields.forEach(field => {
        const input = document.getElementById(`field_${field.id}`);
        if (input) {
            let value = input.value.trim();
            
            // For select fields, keep the value as is (not trimmed for empty)
            if (field.type === 'select') {
                value = input.value; // Keep empty string if "Select..." option
            }
            
            payload[field.id] = value;
            
            if (field.required && !value) {
                isValid = false;
                input.style.borderColor = '#ef4444';
            } else {
                input.style.borderColor = '';
            }
        }
    });
    
    if (!isValid) {
        alert('Please fill in all required fields.');
        return;
    }
    
    try {
        let response;
        let url;
        let method;
        
        if (id) {
            url = `${Utils.getApiBaseUrl()}${config.apiEndpoint}/${id}`;
            method = 'PUT';
        } else {
            url = `${Utils.getApiBaseUrl()}${config.apiEndpoint}`;
            method = 'POST';
        }
        
        response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(id ? `${config.label} updated successfully!` : `${config.label} added successfully!`);
            closeModal('entityFormModal');
            fetchEntities();
        } else {
            alert('Error: ' + (data.message || 'Unknown error occurred'));
        }
    } catch (error) {
        console.error('Save entity error:', error);
        alert('An error occurred while saving: ' + error.message);
    }
}



// ============================================
// DELETE ENTITY
// ============================================

async function deleteEntity(id) {
    if (!confirm('Are you sure you want to delete this ' + ENTITY_CONFIGS[currentEntityType].label.toLowerCase() + '?')) return;
    
    try {
        const config = ENTITY_CONFIGS[currentEntityType];
        const response = await fetch(`${Utils.getApiBaseUrl()}${config.apiEndpoint}/${id}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`${config.label} deleted successfully!`);
            fetchEntities();
        } else {
            alert('Error: ' + (data.message || 'Failed to delete'));
        }
    } catch (error) {
        console.error('Delete entity error:', error);
        alert('An error occurred while deleting: ' + error.message);
    }
}

// ============================================
// DETAILS MODAL
// ============================================

function openDetailsModal(id) {
    const item = entities.find(e => e.id === id);
    if (!item) return;

    const config = ENTITY_CONFIGS[currentEntityType];

    const nameEl = document.getElementById('detName');
    const contactEl = document.getElementById('detContact');
    const refEl = document.getElementById('detRef');
    const avatarEl = document.getElementById('detAvatar');

    if (nameEl) nameEl.innerText = item.name || 'N/A';
    if (contactEl) contactEl.innerText = [item.email, item.phone].filter(Boolean).join('  •  ') || 'No contact info';
    if (refEl) refEl.innerText = item.reference_number ? 'Ref: ' + item.reference_number : item.code ? 'Code: ' + item.code : '';
    if (avatarEl) avatarEl.innerText = getInitials(item.name);

    // Render details as styled rows
    const rawHtml = config.details(item);
    const detailsEl = document.getElementById('detAdditionalInfo');
    if (detailsEl) {
        // Parse the raw HTML into styled key-value rows
        const tmp = document.createElement('div');
        tmp.innerHTML = rawHtml;
        const text = tmp.innerText || tmp.textContent || '';
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

        detailsEl.innerHTML = lines.map(line => {
            const colonIdx = line.indexOf(':');
            if (colonIdx > -1) {
                const key = line.substring(0, colonIdx).trim();
                const val = line.substring(colonIdx + 1).trim() || '—';
                return `
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:9px 14px;background:#f8fafc;border-radius:8px;border:1px solid #f1f5f9;">
                        <span style="font-size:12px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.4px;">${key}</span>
                        <span style="font-size:13px;font-weight:500;color:#111827;text-align:right;max-width:65%;">${val}</span>
                    </div>`;
            }
            return `<div style="padding:8px 14px;font-size:13px;color:#374151;">${line}</div>`;
        }).join('');
    }

    openModal('entityDetailsModal');
}