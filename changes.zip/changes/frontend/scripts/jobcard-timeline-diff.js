let jobId = null;
let historyId = null;
let oldData = null;
let newData = null;

// Ensure apiBaseUrl is correctly defined
let apiBaseUrl = 'http://localhost:5000';
if (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) {
    apiBaseUrl = Utils.getApiBaseUrl();
}

document.addEventListener('DOMContentLoaded', async () => {
    // Parse URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    jobId = urlParams.get('jobId');
    historyId = urlParams.get('historyId');

    if (!jobId || !historyId) {
        alert('Missing required parameters for Diff view.');
        window.location.href = 'jobcard-list.html';
        return;
    }

    try {
        await Promise.all([
            fetchHistoricalData(historyId),
            fetchCurrentData(jobId)
        ]);

        // Attempt to render diff. If Monaco isn't ready yet, it will be called by the onload callback.
        if (window.monacoReady) {
            initializeMonacoDiff();
        }
    } catch (error) {
        console.error('Error loading diff data:', error);
        alert('Failed to load version comparison data.');
        document.getElementById('diffLoading').innerHTML = '<p class="text-danger">Failed to load data.</p>';
    }
});

async function fetchHistoricalData(histId) {
    const response = await fetch(`${apiBaseUrl}/api/jobcards/history/single/${histId}`);
    const result = await response.json();
    if (result.success && result.data) {
        oldData = result.data;
        document.getElementById('oldVersionInfo').textContent = `Version saved at: ${new Date(oldData.version_timestamp).toLocaleString()}`;
    } else {
        throw new Error('Failed to fetch historical data');
    }
}

async function fetchCurrentData(jId) {
    // Fetch raw database row to perfectly match the history schema
    const response = await fetch(`${apiBaseUrl}/api/jobcards/${jId}`);
    const result = await response.json();
    if (result.success && result.data) {
        newData = result.data;
        document.getElementById('newVersionInfo').textContent = `Current Active State`;
    } else {
        throw new Error('Failed to fetch current data');
    }
}

window.initializeMonacoDiff = function() {
    // Only initialize if data has been fetched
    if (!oldData || !newData) return;

    const diffLoading = document.getElementById('diffLoading');
    const monacoContainer = document.getElementById('monacoDiffContainer');

    // Clean up payloads by removing metadata fields we don't care about comparing
    const ignoreFields = ['history_id', 'job_card_id', 'action', 'version_timestamp', 'updated_at', 'created_at'];
    const cleanOld = { ...oldData };
    const cleanNew = { ...newData };
    
    ignoreFields.forEach(f => {
        delete cleanOld[f];
        delete cleanNew[f];
    });

    // Convert JSON to formatted strings
    const oldJsonString = JSON.stringify(cleanOld, null, 2);
    const newJsonString = JSON.stringify(cleanNew, null, 2);

    diffLoading.classList.add('d-none');
    monacoContainer.classList.remove('d-none');

    // Initialize Monaco Diff Editor
    const diffEditor = window.monaco.editor.createDiffEditor(monacoContainer, {
        theme: 'vs-light', // or 'vs-dark'
        originalEditable: false,
        readOnly: true,
        renderSideBySide: true, // true for 2 columns, false for unified
        scrollBeyondLastLine: false,
        automaticLayout: true,
        fontSize: 14,
        minimap: { enabled: false }
    });

    const originalModel = window.monaco.editor.createModel(oldJsonString, 'json');
    const modifiedModel = window.monaco.editor.createModel(newJsonString, 'json');

    diffEditor.setModel({
        original: originalModel,
        modified: modifiedModel
    });
};

function restoreVersion() {
    const modal = new bootstrap.Modal(document.getElementById('restoreConfirmModal'));
    modal.show();

    document.getElementById('confirmRestoreBtn').onclick = async () => {
        modal.hide();
        try {
            const response = await fetch(`${apiBaseUrl}/api/jobcards/${jobId}/restore/${historyId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response.json();
            
            if (result.success) {
                alert('Job card successfully restored to historical version!');
                window.location.href = 'jobcard-list.html';
            } else {
                alert('Restore failed: ' + result.message);
            }
        } catch (error) {
            console.error('Error restoring:', error);
            alert('Failed to process restore request.');
        }
    };
}
