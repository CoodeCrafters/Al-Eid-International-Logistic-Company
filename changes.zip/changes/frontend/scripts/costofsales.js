let allCostSalesData = [];
let activeChargeNames = [];

document.addEventListener('DOMContentLoaded', async () => {
    // Handle time and date updating
    function updateDateTime() {
        const now = new Date();
        const timeElement = document.getElementById('systemTime');
        const dateElement = document.getElementById('systemDate');
        
        if (timeElement) {
            timeElement.textContent = now.toLocaleTimeString('en-US', { hour12: false });
        }
        if (dateElement) {
            dateElement.textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        }
    }
    
    // Initial call and interval
    updateDateTime();
    setInterval(updateDateTime, 1000);

    // Setup Search & Overlay Listeners
    setupSearchAndOverlay();

    // Setup Date Filter & Action Controls
    setupDateAndActionControls();

    // Fetch initial data
    await loadCostOfSalesData();
});

const apiBase = (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) 
    ? Utils.getApiBaseUrl() 
    : ((window.CONFIG && window.CONFIG.API_BASE_URL) ? window.CONFIG.API_BASE_URL : '');

async function loadCostOfSalesData(startDate = '', endDate = '') {
    try {
        let queryParams = '';
        if (startDate || endDate) {
            const params = new URLSearchParams();
            if (startDate) params.append('startDate', startDate);
            if (endDate) params.append('endDate', endDate);
            queryParams = '?' + params.toString();
        }

        let response;
        try {
            response = await fetch(`${apiBase}/api/cost-of-sales${queryParams}`);
            if (!response.ok && apiBase) {
                response = await fetch(`/api/cost-of-sales${queryParams}`);
            }
        } catch (e) {
            response = await fetch(`/api/cost-of-sales${queryParams}`);
        }

        const result = await response.json();
        
        if (result.success) {
            allCostSalesData = result.data || [];
            renderTable(allCostSalesData);
        } else {
            const tbody = document.getElementById('tableBody');
            if (tbody) tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: red;">Error loading data</td></tr>';
        }
    } catch (error) {
        console.error('Failed to fetch data:', error);
        const tbody = document.getElementById('tableBody');
        if (tbody) tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: red;">Failed to fetch data from server</td></tr>';
    }
}

function formatCurrency(amount) {
    const num = parseFloat(amount) || 0;
    return num.toLocaleString('en-US', {
        minimumFractionDigits: 3,
        maximumFractionDigits: 3
    });
}

function renderTable(data) {
    const tableHeader = document.getElementById('tableHeader');
    const tableBody = document.getElementById('tableBody');
    const tableFooter = document.getElementById('tableFooter');
    const overallSalesTotalEl = document.getElementById('overallSalesTotal');
    
    if (!tableHeader || !tableBody) return;

    // 1. Identify all unique charge descriptions across all invoices
    const chargeNamesSet = new Set();
    allCostSalesData.forEach(inv => {
        if (inv.charges) {
            Object.keys(inv.charges).forEach(chargeName => chargeNamesSet.add(chargeName));
        }
    });
    activeChargeNames = Array.from(chargeNamesSet).sort();

    // 2. Build Header (Col 1: Invoice NO, Col 2: Job Card)
    let headerHTML = `
        <th>Invoice NO</th>
        <th>Job Card</th>
        <th>Customer</th>
        <th>Shipper</th>
    `;
    
    activeChargeNames.forEach(chargeName => {
        headerHTML += `<th>${chargeName}</th>`;
    });
    
    headerHTML += `<th class="total-col">Total Amount</th>`;
    tableHeader.innerHTML = headerHTML;

    // Update Counts in footer if available
    const invoiceCountEl = document.getElementById('invoiceCount');
    if (invoiceCountEl) invoiceCountEl.textContent = data.length;

    // 3. Build Body rows & Totals Calculation
    if (data.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="${4 + activeChargeNames.length + 1}" style="text-align: center;">No invoices found</td></tr>`;
        if (tableFooter) tableFooter.innerHTML = '';
        if (overallSalesTotalEl) overallSalesTotalEl.textContent = 'KWD 0.000';
        return;
    }

    let grandTotal = 0;
    const chargeTotals = {};
    activeChargeNames.forEach(name => chargeTotals[name] = 0);

    let bodyHTML = '';
    data.forEach(inv => {
        const invTotal = parseFloat(inv.total) || 0;
        grandTotal += invTotal;

        bodyHTML += `<tr onclick="toggleRowHighlight(this)">
            <td>${inv.invoice_no || 'N/A'}</td>
            <td>${inv.job_no || 'N/A'}</td>
            <td>${inv.customer_name || 'N/A'}</td>
            <td>${inv.shipper_name || 'N/A'}</td>
        `;
        
        activeChargeNames.forEach(chargeName => {
            const amount = (inv.charges && parseFloat(inv.charges[chargeName])) || 0;
            chargeTotals[chargeName] += amount;
            bodyHTML += `<td class="charge-col">${amount > 0 ? formatCurrency(amount) : '-'}</td>`;
        });
        
        bodyHTML += `<td class="total-col">${formatCurrency(invTotal)}</td>
        </tr>`;
    });

    tableBody.innerHTML = bodyHTML;

    // Update Green Summary Metric Card
    if (overallSalesTotalEl) {
        overallSalesTotalEl.textContent = `KWD ${formatCurrency(grandTotal)}`;
    }

    // 4. Build Sticky Footer Row in Green Shade
    if (tableFooter) {
        let footerHTML = `
            <tr class="grand-total-row">
                <td style="font-weight: 700;">TOTAL SALES</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
        `;

        activeChargeNames.forEach(chargeName => {
            const sum = chargeTotals[chargeName] || 0;
            footerHTML += `<td class="charge-col" style="font-weight: 700;">${sum > 0 ? formatCurrency(sum) : '-'}</td>`;
        });

        footerHTML += `<td class="total-col-grand">KWD ${formatCurrency(grandTotal)}</td>
        </tr>`;

        tableFooter.innerHTML = footerHTML;
    }
}

// Row Highlight Overlay Functionality
function toggleRowHighlight(rowEl) {
    if (!rowEl) return;
    rowEl.classList.toggle('row-highlight');
}

// Search and Overlay functionality (same as customers.html panel)
function setupSearchAndOverlay() {
    const searchInput = document.getElementById('entitySearch');
    const searchOverlay = document.getElementById('searchOverlay');

    if (searchInput && searchOverlay) {
        searchInput.addEventListener('focus', () => {
            searchOverlay.classList.add('active');
        });

        searchOverlay.addEventListener('click', () => {
            searchOverlay.classList.remove('active');
            searchInput.blur();
        });

        searchInput.addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase().trim();
            if (!q) {
                renderTable(allCostSalesData);
                return;
            }

            const filtered = allCostSalesData.filter(inv => {
                const invoiceNo = (inv.invoice_no || '').toLowerCase();
                const jobNo = (inv.job_no || '').toLowerCase();
                const custName = (inv.customer_name || '').toLowerCase();
                const shipperName = (inv.shipper_name || '').toLowerCase();

                return invoiceNo.includes(q) || jobNo.includes(q) || custName.includes(q) || shipperName.includes(q);
            });

            renderTable(filtered);
        });
    }
}

// Date Filter & Action Controls
function setupDateAndActionControls() {
    const btnToggleFilter = document.getElementById('btnToggleFilter');
    const dateFilterPanel = document.getElementById('dateFilterPanel');
    const fromDateEl = document.getElementById('fromDate');
    const toDateEl = document.getElementById('toDate');
    const btnApplyDateFilter = document.getElementById('btnApplyDateFilter');
    const btnResetDateFilter = document.getElementById('btnResetDateFilter');
    const btnExportExcel = document.getElementById('btnExportExcel');
    const btnDirectSendMail = document.getElementById('btnDirectSendMail');

    // Toggle Date Filter Panel
    if (btnToggleFilter && dateFilterPanel) {
        btnToggleFilter.addEventListener('click', () => {
            dateFilterPanel.classList.toggle('active');
        });
    }

    // Apply Date Range Filter Click
    if (btnApplyDateFilter) {
        btnApplyDateFilter.addEventListener('click', () => {
            const startDate = fromDateEl ? fromDateEl.value : '';
            const endDate = toDateEl ? toDateEl.value : '';
            loadCostOfSalesData(startDate, endDate);
        });
    }

    // Reset Date Filters
    if (btnResetDateFilter) {
        btnResetDateFilter.addEventListener('click', () => {
            if (fromDateEl) fromDateEl.value = '';
            if (toDateEl) toDateEl.value = '';
            loadCostOfSalesData('', '');
        });
    }

    // Export Excel
    if (btnExportExcel) {
        btnExportExcel.addEventListener('click', () => {
            if (typeof XLSX === 'undefined') {
                alert('Excel library loading... Please try again in a moment.');
                return;
            }
            const table = document.getElementById('costSalesTable');
            const wb = XLSX.utils.table_to_book(table, { sheet: "Cost of Sales" });
            const todayStr = new Date().toISOString().split('T')[0];
            XLSX.writeFile(wb, `Al_Eid_Cost_Of_Sales_${todayStr}.xlsx`);
        });
    }

    // Direct Send Email to Admin from .env with .xlsx attachment
    if (btnDirectSendMail) {
        btnDirectSendMail.addEventListener('click', async () => {
            if (typeof XLSX === 'undefined') {
                alert('Excel generator loading... Please try again.');
                return;
            }

            const originalBtnHtml = btnDirectSendMail.innerHTML;
            btnDirectSendMail.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mailing Admin...';
            btnDirectSendMail.disabled = true;

            try {
                // Generate Excel file buffer as base64
                const table = document.getElementById('costSalesTable');
                const wb = XLSX.utils.table_to_book(table, { sheet: "Cost of Sales" });
                const excelBase64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });

                const startDate = fromDateEl ? fromDateEl.value : '';
                const endDate = toDateEl ? toDateEl.value : '';
                let customNote = '';
                if (startDate || endDate) {
                    customNote = `Filtered Date Range: ${startDate || 'Beginning'} to ${endDate || 'Today'}`;
                }

                let response;
                const endpoint = `${apiBase}/api/cost-of-sales/send-email`;
                try {
                    response = await fetch(endpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ excelBase64, customMessage: customNote })
                    });
                } catch (err) {
                    response = await fetch('/api/cost-of-sales/send-email', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ excelBase64, customMessage: customNote })
                    });
                }

                const resData = await response.json();
                if (resData.success) {
                    alert(`✅ Cost of Sales Excel report emailed directly to Admin (${resData.adminEmail})!`);
                } else {
                    alert('⚠️ Email sending failed: ' + (resData.message || 'Unknown error'));
                }
            } catch (error) {
                console.error('Direct email error:', error);
                alert('An error occurred while sending the email.');
            } finally {
                btnDirectSendMail.innerHTML = originalBtnHtml;
                btnDirectSendMail.disabled = false;
            }
        });
    }
}
