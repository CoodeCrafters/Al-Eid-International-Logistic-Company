// config.js
const CONFIG = {
    API_BASE_URL: 'http://192.168.0.127:5000'
};
window.CONFIG = CONFIG;
