let allJobCards = [];
let filteredJobCards = [];
let currentPage = 1;
const itemsPerPage = 12;
let currentJobCardForAction = null;
let currentView = 'card';

document.addEventListener('DOMContentLoaded', function() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    loadJobCards();
    startApiHealthCheck();
});

function updateDateTime() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour12: false });
    const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('systemTime').textContent = timeStr;
    document.getElementById('systemDate').textContent = dateStr;
}

function startApiHealthCheck() {
    checkApiHealth();
    setInterval(checkApiHealth, 15000);
}

function checkApiHealth() {
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    
    fetch('http://localhost:5000/api/jobcards', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(5000)
    })
    .then(() => {
        statusDot.classList.remove('inactive');
        statusDot.classList.add('active');
        statusText.textContent = 'Database Connected';
    })
    .catch(() => {
        statusDot.classList.remove('active');
        statusDot.classList.add('inactive');
        statusText.textContent = 'Database Disconnected';
    });
}

function toggleAdvancedFilters() {
    const filterSection = document.getElementById('advancedFilters');
    filterSection.classList.toggle('active');
}

async function loadJobCards() {
    try {
        const response = await fetch('http://localhost:5000/api/jobcards', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        if (response.ok) {
            const result = await response.json();
            if (result.success && result.data) {
                // Map backend response fields to what the UI expects
                allJobCards = result.data.map(item => ({
                    id: item.id,
                    jobNo: item.job_no,
                    customerName: item.customer_name || 'N/A',
                    bayanNo: item.bayan_no || 'N/A',
                    requesterName: item.requester_name || 'N/A',
                    departurePort: item.departure_location || 'N/A',
                    arrivalPort: item.arrival_location || 'N/A',
                    bayanDate: item.bayan_date || item.date || new Date().toISOString(),
                    status: item.status || 'pending',
                    grossWeight: item.gross_weight || 0,
                    packages: item.packages || 0,
                    modeOfTravel: item.modeOfTravel || 'N/A' 
                }));
            } else {
                allJobCards = [];
            }
        } else {
            allJobCards = [];
        }
    } catch (error) {
        console.error('Error fetching job cards:', error);
        allJobCards = [];
    }
    
    filteredJobCards = [...allJobCards];
    populateFilters();
    updateJobCardCount();
    displayJobCards();
}

function populateFilters() {
    const customers = [...new Set(allJobCards.map(c => c.customerName))].sort();
    const requesters = [...new Set(allJobCards.map(c => c.requesterName))].sort();
    const departurePorts = [...new Set(allJobCards.map(c => c.departurePort))].sort();
    const arrivalPorts = [...new Set(allJobCards.map(c => c.arrivalPort))].sort();

    document.getElementById('filterCustomerName').innerHTML += customers.map(c => `<option value="${c}">${c}</option>`).join('');
    document.getElementById('filterRequesterName').innerHTML += requesters.map(r => `<option value="${r}">${r}</option>`).join('');
    document.getElementById('filterDeparturePort').innerHTML += departurePorts.map(p => `<option value="${p}">${p}</option>`).join('');
    document.getElementById('filterArrivalPort').innerHTML += arrivalPorts.map(p => `<option value="${p}">${p}</option>`).join('');
}

function executeQuickSearch() {
    const val = document.getElementById('quickSearchInput').value.toLowerCase().trim();
    if (!val) { resetFilters(); return; }
    filteredJobCards = allJobCards.filter(card => 
        card.jobNo.toLowerCase().includes(val) || card.bayanNo.toLowerCase().includes(val)
    );
    currentPage = 1;
    displayJobCards();
}

function applyFilters() {
    const jobCardNo = document.getElementById('filterJobCardNo').value.toLowerCase();
    const customerName = document.getElementById('filterCustomerName').value.toLowerCase();
    const bayanNo = document.getElementById('filterBayanNo').value.toLowerCase();
    const requesterName = document.getElementById('filterRequesterName').value.toLowerCase();
    const departurePort = document.getElementById('filterDeparturePort').value.toLowerCase();
    const arrivalPort = document.getElementById('filterArrivalPort').value.toLowerCase();
    const bayanDateFrom = document.getElementById('filterBayanDateFrom').value;
    const bayanDateTo = document.getElementById('filterBayanDateTo').value;
    const status = document.getElementById('filterStatus').value;

    filteredJobCards = allJobCards.filter(card => {
        const matchJobNo = !jobCardNo || card.jobNo.toLowerCase().includes(jobCardNo);
        const matchCustomer = !customerName || card.customerName.toLowerCase() === customerName;
        const matchBayan = !bayanNo || card.bayanNo.toLowerCase().includes(bayanNo);
        const matchRequester = !requesterName || card.requesterName.toLowerCase() === requesterName;
        const matchDeparture = !departurePort || card.departurePort.toLowerCase() === departurePort;
        const matchArrival = !arrivalPort || card.arrivalPort.toLowerCase() === arrivalPort;
        const matchStatus = !status || card.status === status;
        let matchDateRange = true;
        if (bayanDateFrom || bayanDateTo) {
            const cardDate = new Date(card.bayanDate);
            if (bayanDateFrom && cardDate < new Date(bayanDateFrom)) matchDateRange = false;
            if (bayanDateTo && cardDate > new Date(bayanDateTo)) matchDateRange = false;
        }
        return matchJobNo && matchCustomer && matchBayan && matchRequester && matchDeparture && matchArrival && matchStatus && matchDateRange;
    });
    currentPage = 1;
    displayJobCards();
}

function resetFilters() {
    document.getElementById('quickSearchInput').value = '';
    document.getElementById('filterJobCardNo').value = '';
    document.getElementById('filterCustomerName').value = '';
    document.getElementById('filterBayanNo').value = '';
    document.getElementById('filterRequesterName').value = '';
    document.getElementById('filterDeparturePort').value = '';
    document.getElementById('filterArrivalPort').value = '';
    document.getElementById('filterBayanDateFrom').value = '';
    document.getElementById('filterBayanDateTo').value = '';
    document.getElementById('filterStatus').value = '';
    filteredJobCards = [...allJobCards];
    currentPage = 1;
    displayJobCards();
}

function switchView(view) {
    currentView = view;
    document.getElementById('btnCardView').classList.remove('active');
    document.getElementById('btnListView').classList.remove('active');
    if (view === 'card') {
        document.getElementById('btnCardView').classList.add('active');
        document.getElementById('tableViewContainer').classList.remove('active');
        document.getElementById('cardViewContainer').style.display = 'grid';
    } else {
        document.getElementById('btnListView').classList.add('active');
        document.getElementById('tableViewContainer').classList.add('active');
        document.getElementById('cardViewContainer').style.display = 'none';
    }
}

function displayJobCards() {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedCards = filteredJobCards.slice(startIndex, endIndex);

    if (paginatedCards.length === 0) {
        document.getElementById('cardViewContainer').innerHTML = `
            <div style="grid-column: 1 / -1;">
                <div class="empty-state">
                    <div class="empty-state-icon"><i class="fas fa-inbox"></i></div>
                    <h3>No Records Found</h3>
                </div>
            </div>
        `;
        document.getElementById('jobCardTableBody').innerHTML = '';
        document.getElementById('pagination').innerHTML = '';
        document.getElementById('displayCount').textContent = '0';
        document.getElementById('totalCount').textContent = '0';
        return;
    }

    document.getElementById('cardViewContainer').innerHTML = paginatedCards.map(card => `
        <div class="job-card-item">
            <div class="card-header-row">
                <div class="card-job-number" onclick="viewJobCard('${card.id}')">${card.jobNo}</div>
                <div class="card-date">${formatDate(card.bayanDate)}</div>
            </div>
            <div class="card-route">
                <i class="fas fa-route" style="font-size: 11px;"></i>
                ${card.departurePort.substring(0, 15)} → ${card.arrivalPort.substring(0, 15)}
            </div>
            <div class="card-info-row">
                <div class="card-info-label">Customer</div>
                <div class="card-info-value">${card.customerName}</div>
            </div>
            <div class="card-info-row">
                <div class="card-info-label">Bayan #</div>
                <div class="card-info-value">${card.bayanNo}</div>
            </div>
            <div class="card-info-row">
                <div class="card-info-label">Requester</div>
                <div class="card-info-value">${card.requesterName}</div>
            </div>
            <div class="card-footer">
                <span class="status-badge status-${card.status}">${card.status.charAt(0).toUpperCase() + card.status.slice(1).replace('-', ' ')}</span>
                <div class="card-actions">
                    <button class="action-btn-card action-btn-view" onclick="viewJobCard('${card.id}')" title="View">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn-card action-btn-edit" onclick="editJobCard('${card.id}')" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn-card action-btn-view" onclick="viewTimeline('${card.id}')" title="Timeline (Git)">
                        <i class="fas fa-code-branch"></i>
                    </button>
                    <button class="action-btn-card action-btn-delete" onclick="deleteJobCard('${card.id}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    document.getElementById('jobCardTableBody').innerHTML = paginatedCards.map(card => `
        <tr>
            <td><strong class="card-job-number" onclick="viewJobCard('${card.id}')" style="cursor: pointer;">${card.jobNo}</strong></td>
            <td>${card.customerName}</td>
            <td>${card.bayanNo}</td>
            <td>${card.requesterName}</td>
            <td>${card.departurePort}</td>
            <td>${card.arrivalPort}</td>
            <td>${formatDate(card.bayanDate)}</td>
            <td><span class="status-badge status-${card.status}">${card.status.charAt(0).toUpperCase() + card.status.slice(1).replace('-', ' ')}</span></td>
            <td>
                <button class="action-btn-card action-btn-view me-1" onclick="viewJobCard('${card.id}')"><i class="fas fa-eye"></i></button>
                <button class="action-btn-card action-btn-edit me-1" onclick="editJobCard('${card.id}')"><i class="fas fa-edit"></i></button>
                <button class="action-btn-card action-btn-view me-1" onclick="viewTimeline('${card.id}')"><i class="fas fa-code-branch"></i></button>
                <button class="action-btn-card action-btn-delete" onclick="deleteJobCard('${card.id}')"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');

    document.getElementById('displayCount').textContent = paginatedCards.length;
    document.getElementById('totalCount').textContent = filteredJobCards.length;
    displayPagination();
}

function displayPagination() {
    const pageCount = Math.ceil(filteredJobCards.length / itemsPerPage);
    const paginationDiv = document.getElementById('pagination');
    if (pageCount <= 1) { paginationDiv.innerHTML = ''; return; }
    let html = `<button onclick="previousPage()" ${currentPage === 1 ? 'disabled' : ''}><i class="fas fa-chevron-left"></i></button>`;
    for (let i = 1; i <= pageCount; i++) {
        html += i === currentPage ? `<span class="active">${i}</span>` : `<button onclick="goToPage(${i})">${i}</button>`;
    }
    html += `<button onclick="nextPage()" ${currentPage === pageCount ? 'disabled' : ''}>Next</button>`;
    paginationDiv.innerHTML = html;
}

function previousPage() { if (currentPage > 1) { currentPage--; displayJobCards(); } }
function nextPage() { const pageCount = Math.ceil(filteredJobCards.length / itemsPerPage); if (currentPage < pageCount) { currentPage++; displayJobCards(); } }
function goToPage(page) { currentPage = page; displayJobCards(); }

function viewJobCard(id) {
    const card = allJobCards.find(c => c.id === id || c.id === String(id));
    if (!card) return;
    currentJobCardForAction = card;
    const detailsHtml = `
        <div class="detail-row"><div class="detail-label">Job Card Number</div><div class="detail-value">${card.jobNo}</div></div>
        <div class="detail-row"><div class="detail-label">Customer Name</div><div class="detail-value">${card.customerName}</div></div>
        <div class="detail-row"><div class="detail-label">Bayan Number</div><div class="detail-value">${card.bayanNo}</div></div>
        <div class="detail-row"><div class="detail-label">Bayan Date</div><div class="detail-value">${formatDate(card.bayanDate)}</div></div>
        <div class="detail-row"><div class="detail-label">Requester Name</div><div class="detail-value">${card.requesterName}</div></div>
        <div class="detail-row"><div class="detail-label">Departure Port</div><div class="detail-value">${card.departurePort}</div></div>
        <div class="detail-row"><div class="detail-label">Arrival Port</div><div class="detail-value">${card.arrivalPort}</div></div>
        <div class="detail-row"><div class="detail-label">Mode of Travel</div><div class="detail-value">${card.modeOfTravel}</div></div>
        <div class="detail-row"><div class="detail-label">Gross Weight (KG)</div><div class="detail-value">${card.grossWeight}</div></div>
        <div class="detail-row"><div class="detail-label">Packages</div><div class="detail-value">${card.packages}</div></div>
        <div class="detail-row"><div class="detail-label">Status</div><div class="detail-value"><span class="status-badge status-${card.status}">${card.status.charAt(0).toUpperCase() + card.status.slice(1).replace('-', ' ')}</span></div></div>
    `;
    document.getElementById('detailsContent').innerHTML = detailsHtml;
    new bootstrap.Modal(document.getElementById('detailsModal')).show();
}

function editJobCard(id) {
    const card = currentJobCardForAction || allJobCards.find(c => c.id === id || c.id === String(id));
    if (!card) return;
    const instance = bootstrap.Modal.getInstance(document.getElementById('detailsModal'));
    if (instance) instance.hide();
    window.location.href = `jobcard-edit.html?edit=true&jobId=${card.id}`;
}


async function viewTimeline(id) {
    const card = allJobCards.find(c => c.id === id || c.id === String(id));
    if (!card) return;
    
    // Fetch timeline from backend
    try {
        let apiBaseUrl = 'http://localhost:5000';
        if (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) {
            apiBaseUrl = Utils.getApiBaseUrl();
        }
        
        const response = await fetch(`${apiBaseUrl}/api/jobcards/${id}/history`);
        const result = await response.json();
        
        let timelineHtml = '<div class="timeline-container" style="max-height: 400px; overflow-y: auto;">';
        
        if (result.success && result.data && result.data.length > 0) {
            timelineHtml += '<ul class="list-group">';
            result.data.forEach(historyRow => {
                const date = new Date(historyRow.version_timestamp).toLocaleString();
                timelineHtml += `
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong>Action:</strong> ${historyRow.action} <br>
                            <strong>Date:</strong> ${date} <br>
                            <strong>Status:</strong> <span class="badge bg-secondary">${historyRow.status}</span><br>
                            <em>Snapshot saved before edit</em>
                        </div>
                        <div>
                            <button class="btn btn-sm btn-outline-primary" onclick="window.location.href='jobcard-timeline-diff.html?jobId=${id}&historyId=${historyRow.history_id}'">
                                <i class="fas fa-code-compare me-1"></i> View Changes & Restore
                            </button>
                        </div>
                    </li>
                `;
            });
            timelineHtml += '</ul>';
        } else {
            timelineHtml += '<div class="alert alert-info">No previous versions found for this job card.</div>';
        }
        
        timelineHtml += '</div>';
        
        document.getElementById('timelineContent').innerHTML = timelineHtml;
        new bootstrap.Modal(document.getElementById('timelineModal')).show();
    } catch (error) {
        console.error('Error fetching timeline:', error);
        alert('Failed to load timeline history.');
    }
}

function deleteJobCard(id) {
    const card = allJobCards.find(c => c.id === id || c.id === String(id));
    if (!card) return;
    currentJobCardForAction = card;
    document.getElementById('deleteJobCardNo').textContent = card.jobNo;
    new bootstrap.Modal(document.getElementById('deleteConfirmModal')).show();
}

function confirmDelete() {
    if (!currentJobCardForAction) return;
    
    // Attempt deletion from backend first
    fetch('http://localhost:5000/api/jobcards/' + currentJobCardForAction.id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    }).then(response => {
        if (response.ok) {
            allJobCards = allJobCards.filter(c => c.id !== currentJobCardForAction.id);
            const instance = bootstrap.Modal.getInstance(document.getElementById('deleteConfirmModal'));
            if (instance) instance.hide();
            applyFilters();
            updateJobCardCount();
        } else {
            console.error("Failed to delete job card");
            alert("Failed to delete job card from the database.");
        }
    }).catch(error => {
        console.error("Error deleting job card", error);
        alert("Error deleting job card.");
    });
}

// ── Print from Modal (called by the modal's Print button) ────────────
function printJobCardFromModal() {
    if (!currentJobCardForAction) {
        showNotification('No job card selected.', 'error');
        return;
    }
    
    let apiBaseUrl = 'http://localhost:5000';
    if (typeof Utils !== 'undefined' && Utils.getApiBaseUrl) {
        apiBaseUrl = Utils.getApiBaseUrl();
    } else if (typeof window.CONFIG !== 'undefined' && window.CONFIG.API_BASE_URL) {
        apiBaseUrl = window.CONFIG.API_BASE_URL;
    }
    
    const pdfUrl = `${apiBaseUrl}/api/jobcards/${currentJobCardForAction.id}/pdf`;
    window.open(pdfUrl, '_blank');
    showNotification('Opening Job Card PDF...', 'info');
}



function exportToCSV() {
    if (filteredJobCards.length === 0) return;
    let csv = 'Job Card #,Customer,Bayan #,Requester,From Port,To Port,Date,Status\\n';
    filteredJobCards.forEach(card => {
        csv += `"${card.jobNo}","${card.customerName}","${card.bayanNo}","${card.requesterName}","${card.departurePort}","${card.arrivalPort}","${card.bayanDate}","${card.status}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `job-cards-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
}

function updateJobCardCount() {
    document.getElementById('jobcardCount').textContent = allJobCards.length;
}

function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateStr).toLocaleDateString('en-US', options);
}
