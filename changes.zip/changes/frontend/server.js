const https = require('http');  // Changed from 'http'
const fs = require('fs');
const os = require('os');
const path = require('path');
const { URL } = require('url');

const HOST = '0.0.0.0';
const PORT = 7000;
const ROOT = __dirname;

const contentTypes = {
    '.css': 'text/css; charset=utf-8',
    '.gif': 'image/gif',
    '.html': 'text/html; charset=utf-8',
    '.ico': 'image/x-icon',
    '.jpeg': 'image/jpeg',
    '.jpg': 'image/jpeg',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp'
};

// Create HTTPS server with SSL certificates
const server = https.createServer({
    key: fs.readFileSync('server.key'),    // Your private key
    cert: fs.readFileSync('server.cert')   // Your certificate
}, (request, response) => {
    const requestPath = decodeURIComponent(new URL(request.url, `https://${request.headers.host}`).pathname);
    const relativePath = requestPath === '/' ? '/index.html' : requestPath;
    const filePath = path.resolve(ROOT, `.${relativePath}`);

    if (!filePath.startsWith(ROOT + path.sep)) {
        response.writeHead(403);
        response.end('Forbidden');
        return;
    }

    fs.stat(filePath, (error, stats) => {
        if (!error && stats.isFile()) {
            const extension = path.extname(filePath).toLowerCase();
            response.writeHead(200, {
                'Content-Type': contentTypes[extension] || 'application/octet-stream'
            });
            fs.createReadStream(filePath).pipe(response);
            return;
        }

        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Not found');
    });
});

server.listen(PORT, HOST, () => {
    console.log(`Frontend running at https://localhost:${PORT}`);
    for (const interfaces of Object.values(os.networkInterfaces())) {
        for (const network of interfaces || []) {
            if (network.family === 'IPv4' && !network.internal) {
                console.log(`Network access: https://${network.address}:${PORT}`);
            }
        }
    }
    console.log('Your browser will show a security warning - this is normal for self-signed certificates');
    console.log('Click "Advanced" and "Proceed anyway" to continue');
});