// Mock Customer Data
let customers = [
    {
        id: 1,
        name: "Acme Corporation",
        phone: "+965 1234 5678",
        email: "contact@acmecorp.com",
        ref: "CUST-1001",
        ongoing: 3,
        completed: 12,
        remainingJobs: [
            { id: "AIR-I-2026-06850", status: "In Transit", route: "SIN → KWI" },
            { id: "SEA-E-2026-01234", status: "Customs", route: "KWI → DXB" },
            { id: "ROA-I-2026-00987", status: "Pending Delivery", route: "RUH → KWI" }
        ]
    },
    {
        id: 2,
        name: "Global Tech Solutions",
        phone: "+965 9876 5432",
        email: "logistics@globaltech.com",
        ref: "CUST-1002",
        ongoing: 1,
        completed: 5,
        remainingJobs: [
            { id: "AIR-E-2026-04421", status: "In Transit", route: "KWI → LHR" }
        ]
    },
    {
        id: 3,
        name: "Prime Retailers",
        phone: "+971 4 123 4567",
        email: "shipping@primeretail.ae",
        ref: "CUST-1003",
        ongoing: 0,
        completed: 8,
        remainingJobs: []
    }
];

let currentView = 'card'; // 'card' or 'table'

// DOM Elements
document.addEventListener('DOMContentLoaded', () => {
    // Set up view toggles
    const viewBtns = document.querySelectorAll('.view-btn');
    viewBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const view = btn.dataset.view;
            switchView(view);
            
            // Update active state
            viewBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // Initial Render
    renderCustomers(customers);

    // Setup Search Enter Key
    const searchInput = document.getElementById('customerSearch');
    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    // Reset customers on backspace/clear
    searchInput.addEventListener('input', function (e) {
        if (e.target.value.trim() === '') {
            renderCustomers(customers);
        }
    });
});

function switchView(view) {
    currentView = view;
    const cardView = document.getElementById('customersCardView');
    const tableView = document.getElementById('customersTableView');

    if (view === 'card') {
        cardView.style.display = 'grid';
        tableView.style.display = 'none';
    } else {
        cardView.style.display = 'none';
        tableView.style.display = 'block';
    }
}

function renderCustomers(data) {
    renderCardView(data);
    renderTableView(data);
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}

function renderCardView(data) {
    const container = document.getElementById('customersCardView');
    container.innerHTML = '';

    if (data.length === 0) {
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #7f8c8d;">No customers found.</div>';
        return;
    }

    data.forEach(cust => {
        const card = document.createElement('div');
        card.className = 'customer-card';
        card.onclick = (e) => {
            // Prevent opening details if clicking action buttons
            if(!e.target.closest('.customer-actions')) {
                openDetailsModal(cust.id);
            }
        };

        card.innerHTML = `
            <div class="customer-header">
                <div class="customer-avatar">${getInitials(cust.name)}</div>
                <div class="customer-info-top">
                    <h3 class="customer-name">${cust.name}</h3>
                    <span class="customer-ref">${cust.ref || 'No Ref'}</span>
                </div>
                <div class="customer-actions">
                    <button class="action-btn" title="Edit Customer" onclick="openEditCustomerModal(${cust.id})"><i class="fas fa-edit"></i></button>
                </div>
            </div>
            <div class="customer-details">
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-phone"></i></div>
                    <div class="detail-value">${cust.phone}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-icon"><i class="fas fa-envelope"></i></div>
                    <div class="detail-value">${cust.email}</div>
                </div>
            </div>
            <div class="job-stats">
                <div class="stat-header">Job Cards Overview</div>
                <div class="stat-grid">
                    <div class="stat-item">
                        <div class="stat-value ongoing">${cust.ongoing}</div>
                        <div class="stat-label">Ongoing</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value completed">${cust.completed}</div>
                        <div class="stat-label">Completed</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value remaining">${cust.remainingJobs.length}</div>
                        <div class="stat-label">Remaining</div>
                    </div>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

function renderTableView(data) {
    const tbody = document.getElementById('customersTableBody');
    tbody.innerHTML = '';

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #7f8c8d;">No customers found.</td></tr>';
        return;
    }

    data.forEach(cust => {
        const tr = document.createElement('tr');
        
        const ongoingBadge = cust.ongoing > 0 ? `<span class="status-badge badge-ongoing">${cust.ongoing} Ongoing</span>` : '';
        const completedBadge = `<span class="status-badge badge-completed">${cust.completed} Completed</span>`;
        
        tr.innerHTML = `
            <td>
                <div style="font-weight: 600; color: #2c3e50; margin-bottom: 4px;">${cust.name}</div>
                <div style="font-size: 12px; color: #7f8c8d;">Ref: ${cust.ref || 'N/A'}</div>
            </td>
            <td>
                <div style="margin-bottom: 4px;"><i class="fas fa-phone" style="color: #bdc3c7; width: 16px;"></i> ${cust.phone}</div>
                <div><i class="fas fa-envelope" style="color: #bdc3c7; width: 16px;"></i> ${cust.email}</div>
            </td>
            <td>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    ${ongoingBadge}
                    ${completedBadge}
                </div>
            </td>
            <td>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openDetailsModal(${cust.id})">Details</button>
                <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openEditCustomerModal(${cust.id})"><i class="fas fa-edit"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Search Logic
function performSearch() {
    const query = document.getElementById('customerSearch').value.toLowerCase();
    const loader = document.getElementById('searchLoader');
    
    // Show loading overlay
    loader.classList.add('active');
    
    // Simulate API delay
    setTimeout(() => {
        const filtered = customers.filter(c => 
            c.name.toLowerCase().includes(query) || 
            c.phone.toLowerCase().includes(query) || 
            c.email.toLowerCase().includes(query) || 
            (c.ref && c.ref.toLowerCase().includes(query))
        );
        
        renderCustomers(filtered);
        
        // Hide loader
        loader.classList.remove('active');
    }, 600); // Enhanced overlay shows for 600ms
}

// Modal Logic
function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function openAddCustomerModal() {
    document.getElementById('formModalTitle').innerText = 'Add New Customer';
    document.getElementById('customerForm').reset();
    document.getElementById('customerId').value = '';
    openModal('customerFormModal');
}

function openEditCustomerModal(id) {
    const cust = customers.find(c => c.id === id);
    if (cust) {
        document.getElementById('formModalTitle').innerText = 'Edit Customer';
        document.getElementById('customerId').value = cust.id;
        document.getElementById('formName').value = cust.name;
        document.getElementById('formPhone').value = cust.phone;
        document.getElementById('formEmail').value = cust.email;
        document.getElementById('formRef').value = cust.ref || '';
        openModal('customerFormModal');
    }
}

function saveCustomer() {
    const id = document.getElementById('customerId').value;
    const name = document.getElementById('formName').value;
    const phone = document.getElementById('formPhone').value;
    const email = document.getElementById('formEmail').value;
    const ref = document.getElementById('formRef').value;
    
    if(!name || !phone || !email || !ref) {
        alert("Please fill all required fields.");
        return;
    }

    if (id) {
        // Edit existing
        const idx = customers.findIndex(c => c.id == id);
        if (idx !== -1) {
            customers[idx].name = name;
            customers[idx].phone = phone;
            customers[idx].email = email;
            customers[idx].ref = ref;
        }
    } else {
        // Add new
        customers.push({
            id: Date.now(),
            name, phone, email, ref,
            ongoing: 0, completed: 0, remainingJobs: []
        });
    }

    renderCustomers(customers);
    closeModal('customerFormModal');
}

function openDetailsModal(id) {
    const cust = customers.find(c => c.id === id);
    if (!cust) return;

    document.getElementById('detName').innerText = cust.name;
    document.getElementById('detContact').innerText = cust.email + " | " + cust.phone;

    const list = document.getElementById('remainingJobsList');
    list.innerHTML = '';

    if (cust.remainingJobs.length === 0) {
        list.innerHTML = '<li style="color: #7f8c8d; font-size: 13px;">No remaining job cards.</li>';
    } else {
        cust.remainingJobs.forEach(job => {
            const li = document.createElement('li');
            li.className = 'job-detail-item';
            li.innerHTML = `
                <div class="job-detail-info">
                    <h4>${job.id}</h4>
                    <p>Route: ${job.route}</p>
                </div>
                <div>
                    <span style="background: #e8f4fd; color: #3498db; padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: 600;">${job.status}</span>
                </div>
            `;
            list.appendChild(li);
        });
    }

    openModal('customerDetailsModal');
}
